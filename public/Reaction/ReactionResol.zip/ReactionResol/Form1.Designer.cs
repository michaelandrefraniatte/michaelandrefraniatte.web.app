﻿namespace ReactionResol
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.tbxk = new System.Windows.Forms.TextBox();
            this.tbx1 = new System.Windows.Forms.TextBox();
            this.tbx2 = new System.Windows.Forms.TextBox();
            this.tbx3 = new System.Windows.Forms.TextBox();
            this.tbx4 = new System.Windows.Forms.TextBox();
            this.tbx5 = new System.Windows.Forms.TextBox();
            this.tbx6 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tbxka1 = new System.Windows.Forms.TextBox();
            this.tbxki1 = new System.Windows.Forms.TextBox();
            this.tbxka2 = new System.Windows.Forms.TextBox();
            this.tbxki2 = new System.Windows.Forms.TextBox();
            this.tbxka3 = new System.Windows.Forms.TextBox();
            this.tbxki3 = new System.Windows.Forms.TextBox();
            this.tbxka4 = new System.Windows.Forms.TextBox();
            this.tbxki4 = new System.Windows.Forms.TextBox();
            this.tbxka5 = new System.Windows.Forms.TextBox();
            this.tbxki5 = new System.Windows.Forms.TextBox();
            this.tbxka6 = new System.Windows.Forms.TextBox();
            this.tbxki6 = new System.Windows.Forms.TextBox();
            this.tbxka7 = new System.Windows.Forms.TextBox();
            this.tbxki7 = new System.Windows.Forms.TextBox();
            this.tbx1i7 = new System.Windows.Forms.TextBox();
            this.tbx1a7 = new System.Windows.Forms.TextBox();
            this.tbx1i6 = new System.Windows.Forms.TextBox();
            this.tbx1a6 = new System.Windows.Forms.TextBox();
            this.tbx1i5 = new System.Windows.Forms.TextBox();
            this.tbx1a5 = new System.Windows.Forms.TextBox();
            this.tbx1i4 = new System.Windows.Forms.TextBox();
            this.tbx1a4 = new System.Windows.Forms.TextBox();
            this.tbx1i3 = new System.Windows.Forms.TextBox();
            this.tbx1a3 = new System.Windows.Forms.TextBox();
            this.tbx1i2 = new System.Windows.Forms.TextBox();
            this.tbx1a2 = new System.Windows.Forms.TextBox();
            this.tbx1i1 = new System.Windows.Forms.TextBox();
            this.tbx1a1 = new System.Windows.Forms.TextBox();
            this.tbx2i7 = new System.Windows.Forms.TextBox();
            this.tbx2a7 = new System.Windows.Forms.TextBox();
            this.tbx2i6 = new System.Windows.Forms.TextBox();
            this.tbx2a6 = new System.Windows.Forms.TextBox();
            this.tbx2i5 = new System.Windows.Forms.TextBox();
            this.tbx2a5 = new System.Windows.Forms.TextBox();
            this.tbx2i4 = new System.Windows.Forms.TextBox();
            this.tbx2a4 = new System.Windows.Forms.TextBox();
            this.tbx2i3 = new System.Windows.Forms.TextBox();
            this.tbx2a3 = new System.Windows.Forms.TextBox();
            this.tbx2i2 = new System.Windows.Forms.TextBox();
            this.tbx2a2 = new System.Windows.Forms.TextBox();
            this.tbx2i1 = new System.Windows.Forms.TextBox();
            this.tbx2a1 = new System.Windows.Forms.TextBox();
            this.tbx3i7 = new System.Windows.Forms.TextBox();
            this.tbx3a7 = new System.Windows.Forms.TextBox();
            this.tbx3i6 = new System.Windows.Forms.TextBox();
            this.tbx3a6 = new System.Windows.Forms.TextBox();
            this.tbx3i5 = new System.Windows.Forms.TextBox();
            this.tbx3a5 = new System.Windows.Forms.TextBox();
            this.tbx3i4 = new System.Windows.Forms.TextBox();
            this.tbx3a4 = new System.Windows.Forms.TextBox();
            this.tbx3i3 = new System.Windows.Forms.TextBox();
            this.tbx3a3 = new System.Windows.Forms.TextBox();
            this.tbx3i2 = new System.Windows.Forms.TextBox();
            this.tbx3a2 = new System.Windows.Forms.TextBox();
            this.tbx3i1 = new System.Windows.Forms.TextBox();
            this.tbx3a1 = new System.Windows.Forms.TextBox();
            this.tbx4i7 = new System.Windows.Forms.TextBox();
            this.tbx4a7 = new System.Windows.Forms.TextBox();
            this.tbx4i6 = new System.Windows.Forms.TextBox();
            this.tbx4a6 = new System.Windows.Forms.TextBox();
            this.tbx4i5 = new System.Windows.Forms.TextBox();
            this.tbx4a5 = new System.Windows.Forms.TextBox();
            this.tbx4i4 = new System.Windows.Forms.TextBox();
            this.tbx4a4 = new System.Windows.Forms.TextBox();
            this.tbx4i3 = new System.Windows.Forms.TextBox();
            this.tbx4a3 = new System.Windows.Forms.TextBox();
            this.tbx4i2 = new System.Windows.Forms.TextBox();
            this.tbx4a2 = new System.Windows.Forms.TextBox();
            this.tbx4i1 = new System.Windows.Forms.TextBox();
            this.tbx4a1 = new System.Windows.Forms.TextBox();
            this.tbx5i7 = new System.Windows.Forms.TextBox();
            this.tbx5a7 = new System.Windows.Forms.TextBox();
            this.tbx5i6 = new System.Windows.Forms.TextBox();
            this.tbx5a6 = new System.Windows.Forms.TextBox();
            this.tbx5i5 = new System.Windows.Forms.TextBox();
            this.tbx5a5 = new System.Windows.Forms.TextBox();
            this.tbx5i4 = new System.Windows.Forms.TextBox();
            this.tbx5a4 = new System.Windows.Forms.TextBox();
            this.tbx5i3 = new System.Windows.Forms.TextBox();
            this.tbx5a3 = new System.Windows.Forms.TextBox();
            this.tbx5i2 = new System.Windows.Forms.TextBox();
            this.tbx5a2 = new System.Windows.Forms.TextBox();
            this.tbx5i1 = new System.Windows.Forms.TextBox();
            this.tbx5a1 = new System.Windows.Forms.TextBox();
            this.tbx6i7 = new System.Windows.Forms.TextBox();
            this.tbx6a7 = new System.Windows.Forms.TextBox();
            this.tbx6i6 = new System.Windows.Forms.TextBox();
            this.tbx6a6 = new System.Windows.Forms.TextBox();
            this.tbx6i5 = new System.Windows.Forms.TextBox();
            this.tbx6a5 = new System.Windows.Forms.TextBox();
            this.tbx6i4 = new System.Windows.Forms.TextBox();
            this.tbx6a4 = new System.Windows.Forms.TextBox();
            this.tbx6i3 = new System.Windows.Forms.TextBox();
            this.tbx6a3 = new System.Windows.Forms.TextBox();
            this.tbx6i2 = new System.Windows.Forms.TextBox();
            this.tbx6a2 = new System.Windows.Forms.TextBox();
            this.tbx6i1 = new System.Windows.Forms.TextBox();
            this.tbx6a1 = new System.Windows.Forms.TextBox();
            this.tbx7i7 = new System.Windows.Forms.TextBox();
            this.tbx7a7 = new System.Windows.Forms.TextBox();
            this.tbx7i6 = new System.Windows.Forms.TextBox();
            this.tbx7a6 = new System.Windows.Forms.TextBox();
            this.tbx7i5 = new System.Windows.Forms.TextBox();
            this.tbx7a5 = new System.Windows.Forms.TextBox();
            this.tbx7i4 = new System.Windows.Forms.TextBox();
            this.tbx7a4 = new System.Windows.Forms.TextBox();
            this.tbx7i3 = new System.Windows.Forms.TextBox();
            this.tbx7a3 = new System.Windows.Forms.TextBox();
            this.tbx7i2 = new System.Windows.Forms.TextBox();
            this.tbx7a2 = new System.Windows.Forms.TextBox();
            this.tbx7i1 = new System.Windows.Forms.TextBox();
            this.tbx7a1 = new System.Windows.Forms.TextBox();
            this.tbx7 = new System.Windows.Forms.TextBox();
            this.tbx8i7 = new System.Windows.Forms.TextBox();
            this.tbx8a7 = new System.Windows.Forms.TextBox();
            this.tbx8i6 = new System.Windows.Forms.TextBox();
            this.tbx8a6 = new System.Windows.Forms.TextBox();
            this.tbx8i5 = new System.Windows.Forms.TextBox();
            this.tbx8a5 = new System.Windows.Forms.TextBox();
            this.tbx8i4 = new System.Windows.Forms.TextBox();
            this.tbx8a4 = new System.Windows.Forms.TextBox();
            this.tbx8i3 = new System.Windows.Forms.TextBox();
            this.tbx8a3 = new System.Windows.Forms.TextBox();
            this.tbx8i2 = new System.Windows.Forms.TextBox();
            this.tbx8a2 = new System.Windows.Forms.TextBox();
            this.tbx8i1 = new System.Windows.Forms.TextBox();
            this.tbx8a1 = new System.Windows.Forms.TextBox();
            this.tbx8 = new System.Windows.Forms.TextBox();
            this.tbxki9 = new System.Windows.Forms.TextBox();
            this.tbxka9 = new System.Windows.Forms.TextBox();
            this.tbxki8 = new System.Windows.Forms.TextBox();
            this.tbxka8 = new System.Windows.Forms.TextBox();
            this.tbx1i9 = new System.Windows.Forms.TextBox();
            this.tbx1a9 = new System.Windows.Forms.TextBox();
            this.tbx1i8 = new System.Windows.Forms.TextBox();
            this.tbx1a8 = new System.Windows.Forms.TextBox();
            this.tbx2i9 = new System.Windows.Forms.TextBox();
            this.tbx2a9 = new System.Windows.Forms.TextBox();
            this.tbx2i8 = new System.Windows.Forms.TextBox();
            this.tbx2a8 = new System.Windows.Forms.TextBox();
            this.tbx3i9 = new System.Windows.Forms.TextBox();
            this.tbx3a9 = new System.Windows.Forms.TextBox();
            this.tbx3i8 = new System.Windows.Forms.TextBox();
            this.tbx3a8 = new System.Windows.Forms.TextBox();
            this.tbx4i9 = new System.Windows.Forms.TextBox();
            this.tbx4a9 = new System.Windows.Forms.TextBox();
            this.tbx4i8 = new System.Windows.Forms.TextBox();
            this.tbx4a8 = new System.Windows.Forms.TextBox();
            this.tbx5i9 = new System.Windows.Forms.TextBox();
            this.tbx5a9 = new System.Windows.Forms.TextBox();
            this.tbx5i8 = new System.Windows.Forms.TextBox();
            this.tbx5a8 = new System.Windows.Forms.TextBox();
            this.tbx6i9 = new System.Windows.Forms.TextBox();
            this.tbx6a9 = new System.Windows.Forms.TextBox();
            this.tbx6i8 = new System.Windows.Forms.TextBox();
            this.tbx6a8 = new System.Windows.Forms.TextBox();
            this.tbx7i9 = new System.Windows.Forms.TextBox();
            this.tbx7a9 = new System.Windows.Forms.TextBox();
            this.tbx7i8 = new System.Windows.Forms.TextBox();
            this.tbx7a8 = new System.Windows.Forms.TextBox();
            this.tbx8i9 = new System.Windows.Forms.TextBox();
            this.tbx8a9 = new System.Windows.Forms.TextBox();
            this.tbx8i8 = new System.Windows.Forms.TextBox();
            this.tbx8a8 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(438, 556);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(74, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Equilibrate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbxk
            // 
            this.tbxk.Location = new System.Drawing.Point(115, 30);
            this.tbxk.Name = "tbxk";
            this.tbxk.Size = new System.Drawing.Size(72, 20);
            this.tbxk.TabIndex = 12;
            this.tbxk.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbx1
            // 
            this.tbx1.Location = new System.Drawing.Point(115, 78);
            this.tbx1.Name = "tbx1";
            this.tbx1.Size = new System.Drawing.Size(72, 20);
            this.tbx1.TabIndex = 13;
            this.tbx1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbx2
            // 
            this.tbx2.Location = new System.Drawing.Point(116, 128);
            this.tbx2.Name = "tbx2";
            this.tbx2.Size = new System.Drawing.Size(71, 20);
            this.tbx2.TabIndex = 14;
            this.tbx2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbx3
            // 
            this.tbx3.Location = new System.Drawing.Point(116, 180);
            this.tbx3.Name = "tbx3";
            this.tbx3.Size = new System.Drawing.Size(71, 20);
            this.tbx3.TabIndex = 15;
            this.tbx3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbx4
            // 
            this.tbx4.Location = new System.Drawing.Point(115, 235);
            this.tbx4.Name = "tbx4";
            this.tbx4.Size = new System.Drawing.Size(72, 20);
            this.tbx4.TabIndex = 16;
            this.tbx4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbx5
            // 
            this.tbx5.Location = new System.Drawing.Point(115, 328);
            this.tbx5.Name = "tbx5";
            this.tbx5.Size = new System.Drawing.Size(72, 20);
            this.tbx5.TabIndex = 17;
            this.tbx5.Text = "1";
            this.tbx5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbx6
            // 
            this.tbx6.Location = new System.Drawing.Point(116, 382);
            this.tbx6.Name = "tbx6";
            this.tbx6.Size = new System.Drawing.Size(71, 20);
            this.tbx6.TabIndex = 18;
            this.tbx6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(470, 288);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(31, 20);
            this.textBox1.TabIndex = 19;
            this.textBox1.Text = "=";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbxka1
            // 
            this.tbxka1.Location = new System.Drawing.Point(193, 30);
            this.tbxka1.Name = "tbxka1";
            this.tbxka1.Size = new System.Drawing.Size(29, 20);
            this.tbxka1.TabIndex = 20;
            this.tbxka1.Text = "C";
            // 
            // tbxki1
            // 
            this.tbxki1.Location = new System.Drawing.Point(228, 39);
            this.tbxki1.Name = "tbxki1";
            this.tbxki1.Size = new System.Drawing.Size(29, 20);
            this.tbxki1.TabIndex = 21;
            this.tbxki1.Text = "1";
            // 
            // tbxka2
            // 
            this.tbxka2.Location = new System.Drawing.Point(263, 30);
            this.tbxka2.Name = "tbxka2";
            this.tbxka2.Size = new System.Drawing.Size(29, 20);
            this.tbxka2.TabIndex = 22;
            this.tbxka2.Text = "O";
            // 
            // tbxki2
            // 
            this.tbxki2.Location = new System.Drawing.Point(298, 39);
            this.tbxki2.Name = "tbxki2";
            this.tbxki2.Size = new System.Drawing.Size(29, 20);
            this.tbxki2.TabIndex = 23;
            this.tbxki2.Text = "2";
            // 
            // tbxka3
            // 
            this.tbxka3.Location = new System.Drawing.Point(333, 30);
            this.tbxka3.Name = "tbxka3";
            this.tbxka3.Size = new System.Drawing.Size(29, 20);
            this.tbxka3.TabIndex = 24;
            // 
            // tbxki3
            // 
            this.tbxki3.Location = new System.Drawing.Point(368, 39);
            this.tbxki3.Name = "tbxki3";
            this.tbxki3.Size = new System.Drawing.Size(29, 20);
            this.tbxki3.TabIndex = 25;
            // 
            // tbxka4
            // 
            this.tbxka4.Location = new System.Drawing.Point(403, 30);
            this.tbxka4.Name = "tbxka4";
            this.tbxka4.Size = new System.Drawing.Size(29, 20);
            this.tbxka4.TabIndex = 26;
            // 
            // tbxki4
            // 
            this.tbxki4.Location = new System.Drawing.Point(438, 39);
            this.tbxki4.Name = "tbxki4";
            this.tbxki4.Size = new System.Drawing.Size(29, 20);
            this.tbxki4.TabIndex = 27;
            // 
            // tbxka5
            // 
            this.tbxka5.Location = new System.Drawing.Point(473, 30);
            this.tbxka5.Name = "tbxka5";
            this.tbxka5.Size = new System.Drawing.Size(29, 20);
            this.tbxka5.TabIndex = 28;
            // 
            // tbxki5
            // 
            this.tbxki5.Location = new System.Drawing.Point(508, 39);
            this.tbxki5.Name = "tbxki5";
            this.tbxki5.Size = new System.Drawing.Size(29, 20);
            this.tbxki5.TabIndex = 29;
            // 
            // tbxka6
            // 
            this.tbxka6.Location = new System.Drawing.Point(545, 30);
            this.tbxka6.Name = "tbxka6";
            this.tbxka6.Size = new System.Drawing.Size(29, 20);
            this.tbxka6.TabIndex = 30;
            // 
            // tbxki6
            // 
            this.tbxki6.Location = new System.Drawing.Point(580, 39);
            this.tbxki6.Name = "tbxki6";
            this.tbxki6.Size = new System.Drawing.Size(29, 20);
            this.tbxki6.TabIndex = 31;
            // 
            // tbxka7
            // 
            this.tbxka7.Location = new System.Drawing.Point(615, 30);
            this.tbxka7.Name = "tbxka7";
            this.tbxka7.Size = new System.Drawing.Size(29, 20);
            this.tbxka7.TabIndex = 32;
            // 
            // tbxki7
            // 
            this.tbxki7.Location = new System.Drawing.Point(650, 39);
            this.tbxki7.Name = "tbxki7";
            this.tbxki7.Size = new System.Drawing.Size(29, 20);
            this.tbxki7.TabIndex = 33;
            // 
            // tbx1i7
            // 
            this.tbx1i7.Location = new System.Drawing.Point(650, 87);
            this.tbx1i7.Name = "tbx1i7";
            this.tbx1i7.Size = new System.Drawing.Size(29, 20);
            this.tbx1i7.TabIndex = 47;
            // 
            // tbx1a7
            // 
            this.tbx1a7.Location = new System.Drawing.Point(615, 78);
            this.tbx1a7.Name = "tbx1a7";
            this.tbx1a7.Size = new System.Drawing.Size(29, 20);
            this.tbx1a7.TabIndex = 46;
            // 
            // tbx1i6
            // 
            this.tbx1i6.Location = new System.Drawing.Point(580, 87);
            this.tbx1i6.Name = "tbx1i6";
            this.tbx1i6.Size = new System.Drawing.Size(29, 20);
            this.tbx1i6.TabIndex = 45;
            // 
            // tbx1a6
            // 
            this.tbx1a6.Location = new System.Drawing.Point(545, 78);
            this.tbx1a6.Name = "tbx1a6";
            this.tbx1a6.Size = new System.Drawing.Size(29, 20);
            this.tbx1a6.TabIndex = 44;
            // 
            // tbx1i5
            // 
            this.tbx1i5.Location = new System.Drawing.Point(508, 87);
            this.tbx1i5.Name = "tbx1i5";
            this.tbx1i5.Size = new System.Drawing.Size(29, 20);
            this.tbx1i5.TabIndex = 43;
            // 
            // tbx1a5
            // 
            this.tbx1a5.Location = new System.Drawing.Point(473, 78);
            this.tbx1a5.Name = "tbx1a5";
            this.tbx1a5.Size = new System.Drawing.Size(29, 20);
            this.tbx1a5.TabIndex = 42;
            // 
            // tbx1i4
            // 
            this.tbx1i4.Location = new System.Drawing.Point(438, 87);
            this.tbx1i4.Name = "tbx1i4";
            this.tbx1i4.Size = new System.Drawing.Size(29, 20);
            this.tbx1i4.TabIndex = 41;
            // 
            // tbx1a4
            // 
            this.tbx1a4.Location = new System.Drawing.Point(403, 78);
            this.tbx1a4.Name = "tbx1a4";
            this.tbx1a4.Size = new System.Drawing.Size(29, 20);
            this.tbx1a4.TabIndex = 40;
            // 
            // tbx1i3
            // 
            this.tbx1i3.Location = new System.Drawing.Point(368, 87);
            this.tbx1i3.Name = "tbx1i3";
            this.tbx1i3.Size = new System.Drawing.Size(29, 20);
            this.tbx1i3.TabIndex = 39;
            // 
            // tbx1a3
            // 
            this.tbx1a3.Location = new System.Drawing.Point(333, 78);
            this.tbx1a3.Name = "tbx1a3";
            this.tbx1a3.Size = new System.Drawing.Size(29, 20);
            this.tbx1a3.TabIndex = 38;
            // 
            // tbx1i2
            // 
            this.tbx1i2.Location = new System.Drawing.Point(298, 87);
            this.tbx1i2.Name = "tbx1i2";
            this.tbx1i2.Size = new System.Drawing.Size(29, 20);
            this.tbx1i2.TabIndex = 37;
            // 
            // tbx1a2
            // 
            this.tbx1a2.Location = new System.Drawing.Point(263, 78);
            this.tbx1a2.Name = "tbx1a2";
            this.tbx1a2.Size = new System.Drawing.Size(29, 20);
            this.tbx1a2.TabIndex = 36;
            // 
            // tbx1i1
            // 
            this.tbx1i1.Location = new System.Drawing.Point(228, 87);
            this.tbx1i1.Name = "tbx1i1";
            this.tbx1i1.Size = new System.Drawing.Size(29, 20);
            this.tbx1i1.TabIndex = 35;
            this.tbx1i1.Text = "2";
            // 
            // tbx1a1
            // 
            this.tbx1a1.Location = new System.Drawing.Point(193, 78);
            this.tbx1a1.Name = "tbx1a1";
            this.tbx1a1.Size = new System.Drawing.Size(29, 20);
            this.tbx1a1.TabIndex = 34;
            this.tbx1a1.Text = "N";
            // 
            // tbx2i7
            // 
            this.tbx2i7.Location = new System.Drawing.Point(650, 137);
            this.tbx2i7.Name = "tbx2i7";
            this.tbx2i7.Size = new System.Drawing.Size(29, 20);
            this.tbx2i7.TabIndex = 61;
            // 
            // tbx2a7
            // 
            this.tbx2a7.Location = new System.Drawing.Point(615, 128);
            this.tbx2a7.Name = "tbx2a7";
            this.tbx2a7.Size = new System.Drawing.Size(29, 20);
            this.tbx2a7.TabIndex = 60;
            // 
            // tbx2i6
            // 
            this.tbx2i6.Location = new System.Drawing.Point(580, 137);
            this.tbx2i6.Name = "tbx2i6";
            this.tbx2i6.Size = new System.Drawing.Size(29, 20);
            this.tbx2i6.TabIndex = 59;
            // 
            // tbx2a6
            // 
            this.tbx2a6.Location = new System.Drawing.Point(545, 128);
            this.tbx2a6.Name = "tbx2a6";
            this.tbx2a6.Size = new System.Drawing.Size(29, 20);
            this.tbx2a6.TabIndex = 58;
            // 
            // tbx2i5
            // 
            this.tbx2i5.Location = new System.Drawing.Point(508, 137);
            this.tbx2i5.Name = "tbx2i5";
            this.tbx2i5.Size = new System.Drawing.Size(29, 20);
            this.tbx2i5.TabIndex = 57;
            // 
            // tbx2a5
            // 
            this.tbx2a5.Location = new System.Drawing.Point(473, 128);
            this.tbx2a5.Name = "tbx2a5";
            this.tbx2a5.Size = new System.Drawing.Size(29, 20);
            this.tbx2a5.TabIndex = 56;
            // 
            // tbx2i4
            // 
            this.tbx2i4.Location = new System.Drawing.Point(438, 137);
            this.tbx2i4.Name = "tbx2i4";
            this.tbx2i4.Size = new System.Drawing.Size(29, 20);
            this.tbx2i4.TabIndex = 55;
            // 
            // tbx2a4
            // 
            this.tbx2a4.Location = new System.Drawing.Point(403, 128);
            this.tbx2a4.Name = "tbx2a4";
            this.tbx2a4.Size = new System.Drawing.Size(29, 20);
            this.tbx2a4.TabIndex = 54;
            // 
            // tbx2i3
            // 
            this.tbx2i3.Location = new System.Drawing.Point(368, 137);
            this.tbx2i3.Name = "tbx2i3";
            this.tbx2i3.Size = new System.Drawing.Size(29, 20);
            this.tbx2i3.TabIndex = 53;
            // 
            // tbx2a3
            // 
            this.tbx2a3.Location = new System.Drawing.Point(333, 128);
            this.tbx2a3.Name = "tbx2a3";
            this.tbx2a3.Size = new System.Drawing.Size(29, 20);
            this.tbx2a3.TabIndex = 52;
            // 
            // tbx2i2
            // 
            this.tbx2i2.Location = new System.Drawing.Point(298, 137);
            this.tbx2i2.Name = "tbx2i2";
            this.tbx2i2.Size = new System.Drawing.Size(29, 20);
            this.tbx2i2.TabIndex = 51;
            this.tbx2i2.Text = "1";
            // 
            // tbx2a2
            // 
            this.tbx2a2.Location = new System.Drawing.Point(263, 128);
            this.tbx2a2.Name = "tbx2a2";
            this.tbx2a2.Size = new System.Drawing.Size(29, 20);
            this.tbx2a2.TabIndex = 50;
            this.tbx2a2.Text = "O";
            // 
            // tbx2i1
            // 
            this.tbx2i1.Location = new System.Drawing.Point(228, 137);
            this.tbx2i1.Name = "tbx2i1";
            this.tbx2i1.Size = new System.Drawing.Size(29, 20);
            this.tbx2i1.TabIndex = 49;
            this.tbx2i1.Text = "2";
            // 
            // tbx2a1
            // 
            this.tbx2a1.Location = new System.Drawing.Point(193, 128);
            this.tbx2a1.Name = "tbx2a1";
            this.tbx2a1.Size = new System.Drawing.Size(29, 20);
            this.tbx2a1.TabIndex = 48;
            this.tbx2a1.Text = "H";
            // 
            // tbx3i7
            // 
            this.tbx3i7.Location = new System.Drawing.Point(650, 189);
            this.tbx3i7.Name = "tbx3i7";
            this.tbx3i7.Size = new System.Drawing.Size(29, 20);
            this.tbx3i7.TabIndex = 75;
            // 
            // tbx3a7
            // 
            this.tbx3a7.Location = new System.Drawing.Point(615, 180);
            this.tbx3a7.Name = "tbx3a7";
            this.tbx3a7.Size = new System.Drawing.Size(29, 20);
            this.tbx3a7.TabIndex = 74;
            // 
            // tbx3i6
            // 
            this.tbx3i6.Location = new System.Drawing.Point(580, 189);
            this.tbx3i6.Name = "tbx3i6";
            this.tbx3i6.Size = new System.Drawing.Size(29, 20);
            this.tbx3i6.TabIndex = 73;
            // 
            // tbx3a6
            // 
            this.tbx3a6.Location = new System.Drawing.Point(545, 180);
            this.tbx3a6.Name = "tbx3a6";
            this.tbx3a6.Size = new System.Drawing.Size(29, 20);
            this.tbx3a6.TabIndex = 72;
            // 
            // tbx3i5
            // 
            this.tbx3i5.Location = new System.Drawing.Point(508, 189);
            this.tbx3i5.Name = "tbx3i5";
            this.tbx3i5.Size = new System.Drawing.Size(29, 20);
            this.tbx3i5.TabIndex = 71;
            // 
            // tbx3a5
            // 
            this.tbx3a5.Location = new System.Drawing.Point(473, 180);
            this.tbx3a5.Name = "tbx3a5";
            this.tbx3a5.Size = new System.Drawing.Size(29, 20);
            this.tbx3a5.TabIndex = 70;
            // 
            // tbx3i4
            // 
            this.tbx3i4.Location = new System.Drawing.Point(438, 189);
            this.tbx3i4.Name = "tbx3i4";
            this.tbx3i4.Size = new System.Drawing.Size(29, 20);
            this.tbx3i4.TabIndex = 69;
            // 
            // tbx3a4
            // 
            this.tbx3a4.Location = new System.Drawing.Point(403, 180);
            this.tbx3a4.Name = "tbx3a4";
            this.tbx3a4.Size = new System.Drawing.Size(29, 20);
            this.tbx3a4.TabIndex = 68;
            // 
            // tbx3i3
            // 
            this.tbx3i3.Location = new System.Drawing.Point(368, 189);
            this.tbx3i3.Name = "tbx3i3";
            this.tbx3i3.Size = new System.Drawing.Size(29, 20);
            this.tbx3i3.TabIndex = 67;
            // 
            // tbx3a3
            // 
            this.tbx3a3.Location = new System.Drawing.Point(333, 180);
            this.tbx3a3.Name = "tbx3a3";
            this.tbx3a3.Size = new System.Drawing.Size(29, 20);
            this.tbx3a3.TabIndex = 66;
            // 
            // tbx3i2
            // 
            this.tbx3i2.Location = new System.Drawing.Point(298, 189);
            this.tbx3i2.Name = "tbx3i2";
            this.tbx3i2.Size = new System.Drawing.Size(29, 20);
            this.tbx3i2.TabIndex = 65;
            // 
            // tbx3a2
            // 
            this.tbx3a2.Location = new System.Drawing.Point(263, 180);
            this.tbx3a2.Name = "tbx3a2";
            this.tbx3a2.Size = new System.Drawing.Size(29, 20);
            this.tbx3a2.TabIndex = 64;
            // 
            // tbx3i1
            // 
            this.tbx3i1.Location = new System.Drawing.Point(228, 189);
            this.tbx3i1.Name = "tbx3i1";
            this.tbx3i1.Size = new System.Drawing.Size(29, 20);
            this.tbx3i1.TabIndex = 63;
            // 
            // tbx3a1
            // 
            this.tbx3a1.Location = new System.Drawing.Point(193, 180);
            this.tbx3a1.Name = "tbx3a1";
            this.tbx3a1.Size = new System.Drawing.Size(29, 20);
            this.tbx3a1.TabIndex = 62;
            // 
            // tbx4i7
            // 
            this.tbx4i7.Location = new System.Drawing.Point(650, 244);
            this.tbx4i7.Name = "tbx4i7";
            this.tbx4i7.Size = new System.Drawing.Size(29, 20);
            this.tbx4i7.TabIndex = 89;
            // 
            // tbx4a7
            // 
            this.tbx4a7.Location = new System.Drawing.Point(615, 235);
            this.tbx4a7.Name = "tbx4a7";
            this.tbx4a7.Size = new System.Drawing.Size(29, 20);
            this.tbx4a7.TabIndex = 88;
            // 
            // tbx4i6
            // 
            this.tbx4i6.Location = new System.Drawing.Point(580, 244);
            this.tbx4i6.Name = "tbx4i6";
            this.tbx4i6.Size = new System.Drawing.Size(29, 20);
            this.tbx4i6.TabIndex = 87;
            // 
            // tbx4a6
            // 
            this.tbx4a6.Location = new System.Drawing.Point(545, 235);
            this.tbx4a6.Name = "tbx4a6";
            this.tbx4a6.Size = new System.Drawing.Size(29, 20);
            this.tbx4a6.TabIndex = 86;
            // 
            // tbx4i5
            // 
            this.tbx4i5.Location = new System.Drawing.Point(508, 244);
            this.tbx4i5.Name = "tbx4i5";
            this.tbx4i5.Size = new System.Drawing.Size(29, 20);
            this.tbx4i5.TabIndex = 85;
            // 
            // tbx4a5
            // 
            this.tbx4a5.Location = new System.Drawing.Point(473, 235);
            this.tbx4a5.Name = "tbx4a5";
            this.tbx4a5.Size = new System.Drawing.Size(29, 20);
            this.tbx4a5.TabIndex = 84;
            // 
            // tbx4i4
            // 
            this.tbx4i4.Location = new System.Drawing.Point(438, 244);
            this.tbx4i4.Name = "tbx4i4";
            this.tbx4i4.Size = new System.Drawing.Size(29, 20);
            this.tbx4i4.TabIndex = 83;
            // 
            // tbx4a4
            // 
            this.tbx4a4.Location = new System.Drawing.Point(403, 235);
            this.tbx4a4.Name = "tbx4a4";
            this.tbx4a4.Size = new System.Drawing.Size(29, 20);
            this.tbx4a4.TabIndex = 82;
            // 
            // tbx4i3
            // 
            this.tbx4i3.Location = new System.Drawing.Point(368, 244);
            this.tbx4i3.Name = "tbx4i3";
            this.tbx4i3.Size = new System.Drawing.Size(29, 20);
            this.tbx4i3.TabIndex = 81;
            // 
            // tbx4a3
            // 
            this.tbx4a3.Location = new System.Drawing.Point(333, 235);
            this.tbx4a3.Name = "tbx4a3";
            this.tbx4a3.Size = new System.Drawing.Size(29, 20);
            this.tbx4a3.TabIndex = 80;
            // 
            // tbx4i2
            // 
            this.tbx4i2.Location = new System.Drawing.Point(298, 244);
            this.tbx4i2.Name = "tbx4i2";
            this.tbx4i2.Size = new System.Drawing.Size(29, 20);
            this.tbx4i2.TabIndex = 79;
            // 
            // tbx4a2
            // 
            this.tbx4a2.Location = new System.Drawing.Point(263, 235);
            this.tbx4a2.Name = "tbx4a2";
            this.tbx4a2.Size = new System.Drawing.Size(29, 20);
            this.tbx4a2.TabIndex = 78;
            // 
            // tbx4i1
            // 
            this.tbx4i1.Location = new System.Drawing.Point(228, 244);
            this.tbx4i1.Name = "tbx4i1";
            this.tbx4i1.Size = new System.Drawing.Size(29, 20);
            this.tbx4i1.TabIndex = 77;
            // 
            // tbx4a1
            // 
            this.tbx4a1.Location = new System.Drawing.Point(193, 235);
            this.tbx4a1.Name = "tbx4a1";
            this.tbx4a1.Size = new System.Drawing.Size(29, 20);
            this.tbx4a1.TabIndex = 76;
            // 
            // tbx5i7
            // 
            this.tbx5i7.Location = new System.Drawing.Point(650, 339);
            this.tbx5i7.Name = "tbx5i7";
            this.tbx5i7.Size = new System.Drawing.Size(29, 20);
            this.tbx5i7.TabIndex = 103;
            // 
            // tbx5a7
            // 
            this.tbx5a7.Location = new System.Drawing.Point(615, 330);
            this.tbx5a7.Name = "tbx5a7";
            this.tbx5a7.Size = new System.Drawing.Size(29, 20);
            this.tbx5a7.TabIndex = 102;
            // 
            // tbx5i6
            // 
            this.tbx5i6.Location = new System.Drawing.Point(580, 339);
            this.tbx5i6.Name = "tbx5i6";
            this.tbx5i6.Size = new System.Drawing.Size(29, 20);
            this.tbx5i6.TabIndex = 101;
            // 
            // tbx5a6
            // 
            this.tbx5a6.Location = new System.Drawing.Point(545, 330);
            this.tbx5a6.Name = "tbx5a6";
            this.tbx5a6.Size = new System.Drawing.Size(29, 20);
            this.tbx5a6.TabIndex = 100;
            // 
            // tbx5i5
            // 
            this.tbx5i5.Location = new System.Drawing.Point(508, 339);
            this.tbx5i5.Name = "tbx5i5";
            this.tbx5i5.Size = new System.Drawing.Size(29, 20);
            this.tbx5i5.TabIndex = 99;
            // 
            // tbx5a5
            // 
            this.tbx5a5.Location = new System.Drawing.Point(473, 330);
            this.tbx5a5.Name = "tbx5a5";
            this.tbx5a5.Size = new System.Drawing.Size(29, 20);
            this.tbx5a5.TabIndex = 98;
            // 
            // tbx5i4
            // 
            this.tbx5i4.Location = new System.Drawing.Point(438, 339);
            this.tbx5i4.Name = "tbx5i4";
            this.tbx5i4.Size = new System.Drawing.Size(29, 20);
            this.tbx5i4.TabIndex = 97;
            // 
            // tbx5a4
            // 
            this.tbx5a4.Location = new System.Drawing.Point(403, 330);
            this.tbx5a4.Name = "tbx5a4";
            this.tbx5a4.Size = new System.Drawing.Size(29, 20);
            this.tbx5a4.TabIndex = 96;
            // 
            // tbx5i3
            // 
            this.tbx5i3.Location = new System.Drawing.Point(368, 339);
            this.tbx5i3.Name = "tbx5i3";
            this.tbx5i3.Size = new System.Drawing.Size(29, 20);
            this.tbx5i3.TabIndex = 95;
            this.tbx5i3.Text = "1";
            // 
            // tbx5a3
            // 
            this.tbx5a3.Location = new System.Drawing.Point(333, 330);
            this.tbx5a3.Name = "tbx5a3";
            this.tbx5a3.Size = new System.Drawing.Size(29, 20);
            this.tbx5a3.TabIndex = 94;
            this.tbx5a3.Text = "N";
            // 
            // tbx5i2
            // 
            this.tbx5i2.Location = new System.Drawing.Point(298, 339);
            this.tbx5i2.Name = "tbx5i2";
            this.tbx5i2.Size = new System.Drawing.Size(29, 20);
            this.tbx5i2.TabIndex = 93;
            this.tbx5i2.Text = "9";
            // 
            // tbx5a2
            // 
            this.tbx5a2.Location = new System.Drawing.Point(263, 330);
            this.tbx5a2.Name = "tbx5a2";
            this.tbx5a2.Size = new System.Drawing.Size(29, 20);
            this.tbx5a2.TabIndex = 92;
            this.tbx5a2.Text = "H";
            // 
            // tbx5i1
            // 
            this.tbx5i1.Location = new System.Drawing.Point(228, 339);
            this.tbx5i1.Name = "tbx5i1";
            this.tbx5i1.Size = new System.Drawing.Size(29, 20);
            this.tbx5i1.TabIndex = 91;
            this.tbx5i1.Text = "13";
            // 
            // tbx5a1
            // 
            this.tbx5a1.Location = new System.Drawing.Point(193, 330);
            this.tbx5a1.Name = "tbx5a1";
            this.tbx5a1.Size = new System.Drawing.Size(29, 20);
            this.tbx5a1.TabIndex = 90;
            this.tbx5a1.Text = "C";
            // 
            // tbx6i7
            // 
            this.tbx6i7.Location = new System.Drawing.Point(650, 391);
            this.tbx6i7.Name = "tbx6i7";
            this.tbx6i7.Size = new System.Drawing.Size(29, 20);
            this.tbx6i7.TabIndex = 117;
            // 
            // tbx6a7
            // 
            this.tbx6a7.Location = new System.Drawing.Point(615, 382);
            this.tbx6a7.Name = "tbx6a7";
            this.tbx6a7.Size = new System.Drawing.Size(29, 20);
            this.tbx6a7.TabIndex = 116;
            // 
            // tbx6i6
            // 
            this.tbx6i6.Location = new System.Drawing.Point(580, 391);
            this.tbx6i6.Name = "tbx6i6";
            this.tbx6i6.Size = new System.Drawing.Size(29, 20);
            this.tbx6i6.TabIndex = 115;
            // 
            // tbx6a6
            // 
            this.tbx6a6.Location = new System.Drawing.Point(545, 382);
            this.tbx6a6.Name = "tbx6a6";
            this.tbx6a6.Size = new System.Drawing.Size(29, 20);
            this.tbx6a6.TabIndex = 114;
            // 
            // tbx6i5
            // 
            this.tbx6i5.Location = new System.Drawing.Point(508, 391);
            this.tbx6i5.Name = "tbx6i5";
            this.tbx6i5.Size = new System.Drawing.Size(29, 20);
            this.tbx6i5.TabIndex = 113;
            // 
            // tbx6a5
            // 
            this.tbx6a5.Location = new System.Drawing.Point(473, 382);
            this.tbx6a5.Name = "tbx6a5";
            this.tbx6a5.Size = new System.Drawing.Size(29, 20);
            this.tbx6a5.TabIndex = 112;
            // 
            // tbx6i4
            // 
            this.tbx6i4.Location = new System.Drawing.Point(438, 391);
            this.tbx6i4.Name = "tbx6i4";
            this.tbx6i4.Size = new System.Drawing.Size(29, 20);
            this.tbx6i4.TabIndex = 111;
            // 
            // tbx6a4
            // 
            this.tbx6a4.Location = new System.Drawing.Point(403, 382);
            this.tbx6a4.Name = "tbx6a4";
            this.tbx6a4.Size = new System.Drawing.Size(29, 20);
            this.tbx6a4.TabIndex = 110;
            // 
            // tbx6i3
            // 
            this.tbx6i3.Location = new System.Drawing.Point(368, 391);
            this.tbx6i3.Name = "tbx6i3";
            this.tbx6i3.Size = new System.Drawing.Size(29, 20);
            this.tbx6i3.TabIndex = 109;
            // 
            // tbx6a3
            // 
            this.tbx6a3.Location = new System.Drawing.Point(333, 382);
            this.tbx6a3.Name = "tbx6a3";
            this.tbx6a3.Size = new System.Drawing.Size(29, 20);
            this.tbx6a3.TabIndex = 108;
            // 
            // tbx6i2
            // 
            this.tbx6i2.Location = new System.Drawing.Point(298, 391);
            this.tbx6i2.Name = "tbx6i2";
            this.tbx6i2.Size = new System.Drawing.Size(29, 20);
            this.tbx6i2.TabIndex = 107;
            // 
            // tbx6a2
            // 
            this.tbx6a2.Location = new System.Drawing.Point(263, 382);
            this.tbx6a2.Name = "tbx6a2";
            this.tbx6a2.Size = new System.Drawing.Size(29, 20);
            this.tbx6a2.TabIndex = 106;
            // 
            // tbx6i1
            // 
            this.tbx6i1.Location = new System.Drawing.Point(228, 391);
            this.tbx6i1.Name = "tbx6i1";
            this.tbx6i1.Size = new System.Drawing.Size(29, 20);
            this.tbx6i1.TabIndex = 105;
            this.tbx6i1.Text = "2";
            // 
            // tbx6a1
            // 
            this.tbx6a1.Location = new System.Drawing.Point(193, 382);
            this.tbx6a1.Name = "tbx6a1";
            this.tbx6a1.Size = new System.Drawing.Size(29, 20);
            this.tbx6a1.TabIndex = 104;
            this.tbx6a1.Text = "O";
            // 
            // tbx7i7
            // 
            this.tbx7i7.Location = new System.Drawing.Point(649, 446);
            this.tbx7i7.Name = "tbx7i7";
            this.tbx7i7.Size = new System.Drawing.Size(29, 20);
            this.tbx7i7.TabIndex = 132;
            // 
            // tbx7a7
            // 
            this.tbx7a7.Location = new System.Drawing.Point(614, 437);
            this.tbx7a7.Name = "tbx7a7";
            this.tbx7a7.Size = new System.Drawing.Size(29, 20);
            this.tbx7a7.TabIndex = 131;
            // 
            // tbx7i6
            // 
            this.tbx7i6.Location = new System.Drawing.Point(579, 446);
            this.tbx7i6.Name = "tbx7i6";
            this.tbx7i6.Size = new System.Drawing.Size(29, 20);
            this.tbx7i6.TabIndex = 130;
            // 
            // tbx7a6
            // 
            this.tbx7a6.Location = new System.Drawing.Point(544, 437);
            this.tbx7a6.Name = "tbx7a6";
            this.tbx7a6.Size = new System.Drawing.Size(29, 20);
            this.tbx7a6.TabIndex = 129;
            // 
            // tbx7i5
            // 
            this.tbx7i5.Location = new System.Drawing.Point(507, 446);
            this.tbx7i5.Name = "tbx7i5";
            this.tbx7i5.Size = new System.Drawing.Size(29, 20);
            this.tbx7i5.TabIndex = 128;
            // 
            // tbx7a5
            // 
            this.tbx7a5.Location = new System.Drawing.Point(472, 437);
            this.tbx7a5.Name = "tbx7a5";
            this.tbx7a5.Size = new System.Drawing.Size(29, 20);
            this.tbx7a5.TabIndex = 127;
            // 
            // tbx7i4
            // 
            this.tbx7i4.Location = new System.Drawing.Point(437, 446);
            this.tbx7i4.Name = "tbx7i4";
            this.tbx7i4.Size = new System.Drawing.Size(29, 20);
            this.tbx7i4.TabIndex = 126;
            // 
            // tbx7a4
            // 
            this.tbx7a4.Location = new System.Drawing.Point(402, 437);
            this.tbx7a4.Name = "tbx7a4";
            this.tbx7a4.Size = new System.Drawing.Size(29, 20);
            this.tbx7a4.TabIndex = 125;
            // 
            // tbx7i3
            // 
            this.tbx7i3.Location = new System.Drawing.Point(367, 446);
            this.tbx7i3.Name = "tbx7i3";
            this.tbx7i3.Size = new System.Drawing.Size(29, 20);
            this.tbx7i3.TabIndex = 124;
            // 
            // tbx7a3
            // 
            this.tbx7a3.Location = new System.Drawing.Point(332, 437);
            this.tbx7a3.Name = "tbx7a3";
            this.tbx7a3.Size = new System.Drawing.Size(29, 20);
            this.tbx7a3.TabIndex = 123;
            // 
            // tbx7i2
            // 
            this.tbx7i2.Location = new System.Drawing.Point(297, 446);
            this.tbx7i2.Name = "tbx7i2";
            this.tbx7i2.Size = new System.Drawing.Size(29, 20);
            this.tbx7i2.TabIndex = 122;
            // 
            // tbx7a2
            // 
            this.tbx7a2.Location = new System.Drawing.Point(262, 437);
            this.tbx7a2.Name = "tbx7a2";
            this.tbx7a2.Size = new System.Drawing.Size(29, 20);
            this.tbx7a2.TabIndex = 121;
            // 
            // tbx7i1
            // 
            this.tbx7i1.Location = new System.Drawing.Point(227, 446);
            this.tbx7i1.Name = "tbx7i1";
            this.tbx7i1.Size = new System.Drawing.Size(29, 20);
            this.tbx7i1.TabIndex = 120;
            // 
            // tbx7a1
            // 
            this.tbx7a1.Location = new System.Drawing.Point(192, 437);
            this.tbx7a1.Name = "tbx7a1";
            this.tbx7a1.Size = new System.Drawing.Size(29, 20);
            this.tbx7a1.TabIndex = 119;
            // 
            // tbx7
            // 
            this.tbx7.Location = new System.Drawing.Point(115, 437);
            this.tbx7.Name = "tbx7";
            this.tbx7.Size = new System.Drawing.Size(71, 20);
            this.tbx7.TabIndex = 118;
            this.tbx7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbx8i7
            // 
            this.tbx8i7.Location = new System.Drawing.Point(650, 503);
            this.tbx8i7.Name = "tbx8i7";
            this.tbx8i7.Size = new System.Drawing.Size(29, 20);
            this.tbx8i7.TabIndex = 147;
            // 
            // tbx8a7
            // 
            this.tbx8a7.Location = new System.Drawing.Point(615, 494);
            this.tbx8a7.Name = "tbx8a7";
            this.tbx8a7.Size = new System.Drawing.Size(29, 20);
            this.tbx8a7.TabIndex = 146;
            // 
            // tbx8i6
            // 
            this.tbx8i6.Location = new System.Drawing.Point(580, 503);
            this.tbx8i6.Name = "tbx8i6";
            this.tbx8i6.Size = new System.Drawing.Size(29, 20);
            this.tbx8i6.TabIndex = 145;
            // 
            // tbx8a6
            // 
            this.tbx8a6.Location = new System.Drawing.Point(545, 494);
            this.tbx8a6.Name = "tbx8a6";
            this.tbx8a6.Size = new System.Drawing.Size(29, 20);
            this.tbx8a6.TabIndex = 144;
            // 
            // tbx8i5
            // 
            this.tbx8i5.Location = new System.Drawing.Point(508, 503);
            this.tbx8i5.Name = "tbx8i5";
            this.tbx8i5.Size = new System.Drawing.Size(29, 20);
            this.tbx8i5.TabIndex = 143;
            // 
            // tbx8a5
            // 
            this.tbx8a5.Location = new System.Drawing.Point(473, 494);
            this.tbx8a5.Name = "tbx8a5";
            this.tbx8a5.Size = new System.Drawing.Size(29, 20);
            this.tbx8a5.TabIndex = 142;
            // 
            // tbx8i4
            // 
            this.tbx8i4.Location = new System.Drawing.Point(438, 503);
            this.tbx8i4.Name = "tbx8i4";
            this.tbx8i4.Size = new System.Drawing.Size(29, 20);
            this.tbx8i4.TabIndex = 141;
            // 
            // tbx8a4
            // 
            this.tbx8a4.Location = new System.Drawing.Point(403, 494);
            this.tbx8a4.Name = "tbx8a4";
            this.tbx8a4.Size = new System.Drawing.Size(29, 20);
            this.tbx8a4.TabIndex = 140;
            // 
            // tbx8i3
            // 
            this.tbx8i3.Location = new System.Drawing.Point(368, 503);
            this.tbx8i3.Name = "tbx8i3";
            this.tbx8i3.Size = new System.Drawing.Size(29, 20);
            this.tbx8i3.TabIndex = 139;
            // 
            // tbx8a3
            // 
            this.tbx8a3.Location = new System.Drawing.Point(333, 494);
            this.tbx8a3.Name = "tbx8a3";
            this.tbx8a3.Size = new System.Drawing.Size(29, 20);
            this.tbx8a3.TabIndex = 138;
            // 
            // tbx8i2
            // 
            this.tbx8i2.Location = new System.Drawing.Point(298, 503);
            this.tbx8i2.Name = "tbx8i2";
            this.tbx8i2.Size = new System.Drawing.Size(29, 20);
            this.tbx8i2.TabIndex = 137;
            // 
            // tbx8a2
            // 
            this.tbx8a2.Location = new System.Drawing.Point(263, 494);
            this.tbx8a2.Name = "tbx8a2";
            this.tbx8a2.Size = new System.Drawing.Size(29, 20);
            this.tbx8a2.TabIndex = 136;
            // 
            // tbx8i1
            // 
            this.tbx8i1.Location = new System.Drawing.Point(228, 503);
            this.tbx8i1.Name = "tbx8i1";
            this.tbx8i1.Size = new System.Drawing.Size(29, 20);
            this.tbx8i1.TabIndex = 135;
            // 
            // tbx8a1
            // 
            this.tbx8a1.Location = new System.Drawing.Point(193, 494);
            this.tbx8a1.Name = "tbx8a1";
            this.tbx8a1.Size = new System.Drawing.Size(29, 20);
            this.tbx8a1.TabIndex = 134;
            // 
            // tbx8
            // 
            this.tbx8.Location = new System.Drawing.Point(116, 494);
            this.tbx8.Name = "tbx8";
            this.tbx8.Size = new System.Drawing.Size(71, 20);
            this.tbx8.TabIndex = 133;
            this.tbx8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbxki9
            // 
            this.tbxki9.Location = new System.Drawing.Point(790, 39);
            this.tbxki9.Name = "tbxki9";
            this.tbxki9.Size = new System.Drawing.Size(29, 20);
            this.tbxki9.TabIndex = 151;
            // 
            // tbxka9
            // 
            this.tbxka9.Location = new System.Drawing.Point(755, 30);
            this.tbxka9.Name = "tbxka9";
            this.tbxka9.Size = new System.Drawing.Size(29, 20);
            this.tbxka9.TabIndex = 150;
            // 
            // tbxki8
            // 
            this.tbxki8.Location = new System.Drawing.Point(720, 39);
            this.tbxki8.Name = "tbxki8";
            this.tbxki8.Size = new System.Drawing.Size(29, 20);
            this.tbxki8.TabIndex = 149;
            // 
            // tbxka8
            // 
            this.tbxka8.Location = new System.Drawing.Point(685, 30);
            this.tbxka8.Name = "tbxka8";
            this.tbxka8.Size = new System.Drawing.Size(29, 20);
            this.tbxka8.TabIndex = 148;
            // 
            // tbx1i9
            // 
            this.tbx1i9.Location = new System.Drawing.Point(790, 87);
            this.tbx1i9.Name = "tbx1i9";
            this.tbx1i9.Size = new System.Drawing.Size(29, 20);
            this.tbx1i9.TabIndex = 155;
            // 
            // tbx1a9
            // 
            this.tbx1a9.Location = new System.Drawing.Point(755, 78);
            this.tbx1a9.Name = "tbx1a9";
            this.tbx1a9.Size = new System.Drawing.Size(29, 20);
            this.tbx1a9.TabIndex = 154;
            // 
            // tbx1i8
            // 
            this.tbx1i8.Location = new System.Drawing.Point(720, 87);
            this.tbx1i8.Name = "tbx1i8";
            this.tbx1i8.Size = new System.Drawing.Size(29, 20);
            this.tbx1i8.TabIndex = 153;
            // 
            // tbx1a8
            // 
            this.tbx1a8.Location = new System.Drawing.Point(685, 78);
            this.tbx1a8.Name = "tbx1a8";
            this.tbx1a8.Size = new System.Drawing.Size(29, 20);
            this.tbx1a8.TabIndex = 152;
            // 
            // tbx2i9
            // 
            this.tbx2i9.Location = new System.Drawing.Point(790, 137);
            this.tbx2i9.Name = "tbx2i9";
            this.tbx2i9.Size = new System.Drawing.Size(29, 20);
            this.tbx2i9.TabIndex = 159;
            // 
            // tbx2a9
            // 
            this.tbx2a9.Location = new System.Drawing.Point(755, 128);
            this.tbx2a9.Name = "tbx2a9";
            this.tbx2a9.Size = new System.Drawing.Size(29, 20);
            this.tbx2a9.TabIndex = 158;
            // 
            // tbx2i8
            // 
            this.tbx2i8.Location = new System.Drawing.Point(720, 137);
            this.tbx2i8.Name = "tbx2i8";
            this.tbx2i8.Size = new System.Drawing.Size(29, 20);
            this.tbx2i8.TabIndex = 157;
            // 
            // tbx2a8
            // 
            this.tbx2a8.Location = new System.Drawing.Point(685, 128);
            this.tbx2a8.Name = "tbx2a8";
            this.tbx2a8.Size = new System.Drawing.Size(29, 20);
            this.tbx2a8.TabIndex = 156;
            // 
            // tbx3i9
            // 
            this.tbx3i9.Location = new System.Drawing.Point(790, 189);
            this.tbx3i9.Name = "tbx3i9";
            this.tbx3i9.Size = new System.Drawing.Size(29, 20);
            this.tbx3i9.TabIndex = 163;
            // 
            // tbx3a9
            // 
            this.tbx3a9.Location = new System.Drawing.Point(755, 180);
            this.tbx3a9.Name = "tbx3a9";
            this.tbx3a9.Size = new System.Drawing.Size(29, 20);
            this.tbx3a9.TabIndex = 162;
            // 
            // tbx3i8
            // 
            this.tbx3i8.Location = new System.Drawing.Point(720, 189);
            this.tbx3i8.Name = "tbx3i8";
            this.tbx3i8.Size = new System.Drawing.Size(29, 20);
            this.tbx3i8.TabIndex = 161;
            // 
            // tbx3a8
            // 
            this.tbx3a8.Location = new System.Drawing.Point(685, 180);
            this.tbx3a8.Name = "tbx3a8";
            this.tbx3a8.Size = new System.Drawing.Size(29, 20);
            this.tbx3a8.TabIndex = 160;
            // 
            // tbx4i9
            // 
            this.tbx4i9.Location = new System.Drawing.Point(790, 244);
            this.tbx4i9.Name = "tbx4i9";
            this.tbx4i9.Size = new System.Drawing.Size(29, 20);
            this.tbx4i9.TabIndex = 167;
            // 
            // tbx4a9
            // 
            this.tbx4a9.Location = new System.Drawing.Point(755, 235);
            this.tbx4a9.Name = "tbx4a9";
            this.tbx4a9.Size = new System.Drawing.Size(29, 20);
            this.tbx4a9.TabIndex = 166;
            // 
            // tbx4i8
            // 
            this.tbx4i8.Location = new System.Drawing.Point(720, 244);
            this.tbx4i8.Name = "tbx4i8";
            this.tbx4i8.Size = new System.Drawing.Size(29, 20);
            this.tbx4i8.TabIndex = 165;
            // 
            // tbx4a8
            // 
            this.tbx4a8.Location = new System.Drawing.Point(685, 235);
            this.tbx4a8.Name = "tbx4a8";
            this.tbx4a8.Size = new System.Drawing.Size(29, 20);
            this.tbx4a8.TabIndex = 164;
            // 
            // tbx5i9
            // 
            this.tbx5i9.Location = new System.Drawing.Point(790, 339);
            this.tbx5i9.Name = "tbx5i9";
            this.tbx5i9.Size = new System.Drawing.Size(29, 20);
            this.tbx5i9.TabIndex = 171;
            // 
            // tbx5a9
            // 
            this.tbx5a9.Location = new System.Drawing.Point(755, 330);
            this.tbx5a9.Name = "tbx5a9";
            this.tbx5a9.Size = new System.Drawing.Size(29, 20);
            this.tbx5a9.TabIndex = 170;
            // 
            // tbx5i8
            // 
            this.tbx5i8.Location = new System.Drawing.Point(720, 339);
            this.tbx5i8.Name = "tbx5i8";
            this.tbx5i8.Size = new System.Drawing.Size(29, 20);
            this.tbx5i8.TabIndex = 169;
            // 
            // tbx5a8
            // 
            this.tbx5a8.Location = new System.Drawing.Point(685, 330);
            this.tbx5a8.Name = "tbx5a8";
            this.tbx5a8.Size = new System.Drawing.Size(29, 20);
            this.tbx5a8.TabIndex = 168;
            // 
            // tbx6i9
            // 
            this.tbx6i9.Location = new System.Drawing.Point(790, 391);
            this.tbx6i9.Name = "tbx6i9";
            this.tbx6i9.Size = new System.Drawing.Size(29, 20);
            this.tbx6i9.TabIndex = 175;
            // 
            // tbx6a9
            // 
            this.tbx6a9.Location = new System.Drawing.Point(755, 382);
            this.tbx6a9.Name = "tbx6a9";
            this.tbx6a9.Size = new System.Drawing.Size(29, 20);
            this.tbx6a9.TabIndex = 174;
            // 
            // tbx6i8
            // 
            this.tbx6i8.Location = new System.Drawing.Point(720, 391);
            this.tbx6i8.Name = "tbx6i8";
            this.tbx6i8.Size = new System.Drawing.Size(29, 20);
            this.tbx6i8.TabIndex = 173;
            // 
            // tbx6a8
            // 
            this.tbx6a8.Location = new System.Drawing.Point(685, 382);
            this.tbx6a8.Name = "tbx6a8";
            this.tbx6a8.Size = new System.Drawing.Size(29, 20);
            this.tbx6a8.TabIndex = 172;
            // 
            // tbx7i9
            // 
            this.tbx7i9.Location = new System.Drawing.Point(790, 446);
            this.tbx7i9.Name = "tbx7i9";
            this.tbx7i9.Size = new System.Drawing.Size(29, 20);
            this.tbx7i9.TabIndex = 179;
            // 
            // tbx7a9
            // 
            this.tbx7a9.Location = new System.Drawing.Point(755, 437);
            this.tbx7a9.Name = "tbx7a9";
            this.tbx7a9.Size = new System.Drawing.Size(29, 20);
            this.tbx7a9.TabIndex = 178;
            // 
            // tbx7i8
            // 
            this.tbx7i8.Location = new System.Drawing.Point(720, 446);
            this.tbx7i8.Name = "tbx7i8";
            this.tbx7i8.Size = new System.Drawing.Size(29, 20);
            this.tbx7i8.TabIndex = 177;
            // 
            // tbx7a8
            // 
            this.tbx7a8.Location = new System.Drawing.Point(685, 437);
            this.tbx7a8.Name = "tbx7a8";
            this.tbx7a8.Size = new System.Drawing.Size(29, 20);
            this.tbx7a8.TabIndex = 176;
            // 
            // tbx8i9
            // 
            this.tbx8i9.Location = new System.Drawing.Point(790, 503);
            this.tbx8i9.Name = "tbx8i9";
            this.tbx8i9.Size = new System.Drawing.Size(29, 20);
            this.tbx8i9.TabIndex = 183;
            // 
            // tbx8a9
            // 
            this.tbx8a9.Location = new System.Drawing.Point(755, 494);
            this.tbx8a9.Name = "tbx8a9";
            this.tbx8a9.Size = new System.Drawing.Size(29, 20);
            this.tbx8a9.TabIndex = 182;
            // 
            // tbx8i8
            // 
            this.tbx8i8.Location = new System.Drawing.Point(720, 503);
            this.tbx8i8.Name = "tbx8i8";
            this.tbx8i8.Size = new System.Drawing.Size(29, 20);
            this.tbx8i8.TabIndex = 181;
            // 
            // tbx8a8
            // 
            this.tbx8a8.Location = new System.Drawing.Point(685, 494);
            this.tbx8a8.Name = "tbx8a8";
            this.tbx8a8.Size = new System.Drawing.Size(29, 20);
            this.tbx8a8.TabIndex = 180;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(941, 591);
            this.Controls.Add(this.tbx8i9);
            this.Controls.Add(this.tbx8a9);
            this.Controls.Add(this.tbx8i8);
            this.Controls.Add(this.tbx8a8);
            this.Controls.Add(this.tbx7i9);
            this.Controls.Add(this.tbx7a9);
            this.Controls.Add(this.tbx7i8);
            this.Controls.Add(this.tbx7a8);
            this.Controls.Add(this.tbx6i9);
            this.Controls.Add(this.tbx6a9);
            this.Controls.Add(this.tbx6i8);
            this.Controls.Add(this.tbx6a8);
            this.Controls.Add(this.tbx5i9);
            this.Controls.Add(this.tbx5a9);
            this.Controls.Add(this.tbx5i8);
            this.Controls.Add(this.tbx5a8);
            this.Controls.Add(this.tbx4i9);
            this.Controls.Add(this.tbx4a9);
            this.Controls.Add(this.tbx4i8);
            this.Controls.Add(this.tbx4a8);
            this.Controls.Add(this.tbx3i9);
            this.Controls.Add(this.tbx3a9);
            this.Controls.Add(this.tbx3i8);
            this.Controls.Add(this.tbx3a8);
            this.Controls.Add(this.tbx2i9);
            this.Controls.Add(this.tbx2a9);
            this.Controls.Add(this.tbx2i8);
            this.Controls.Add(this.tbx2a8);
            this.Controls.Add(this.tbx1i9);
            this.Controls.Add(this.tbx1a9);
            this.Controls.Add(this.tbx1i8);
            this.Controls.Add(this.tbx1a8);
            this.Controls.Add(this.tbxki9);
            this.Controls.Add(this.tbxka9);
            this.Controls.Add(this.tbxki8);
            this.Controls.Add(this.tbxka8);
            this.Controls.Add(this.tbx8i7);
            this.Controls.Add(this.tbx8a7);
            this.Controls.Add(this.tbx8i6);
            this.Controls.Add(this.tbx8a6);
            this.Controls.Add(this.tbx8i5);
            this.Controls.Add(this.tbx8a5);
            this.Controls.Add(this.tbx8i4);
            this.Controls.Add(this.tbx8a4);
            this.Controls.Add(this.tbx8i3);
            this.Controls.Add(this.tbx8a3);
            this.Controls.Add(this.tbx8i2);
            this.Controls.Add(this.tbx8a2);
            this.Controls.Add(this.tbx8i1);
            this.Controls.Add(this.tbx8a1);
            this.Controls.Add(this.tbx8);
            this.Controls.Add(this.tbx7i7);
            this.Controls.Add(this.tbx7a7);
            this.Controls.Add(this.tbx7i6);
            this.Controls.Add(this.tbx7a6);
            this.Controls.Add(this.tbx7i5);
            this.Controls.Add(this.tbx7a5);
            this.Controls.Add(this.tbx7i4);
            this.Controls.Add(this.tbx7a4);
            this.Controls.Add(this.tbx7i3);
            this.Controls.Add(this.tbx7a3);
            this.Controls.Add(this.tbx7i2);
            this.Controls.Add(this.tbx7a2);
            this.Controls.Add(this.tbx7i1);
            this.Controls.Add(this.tbx7a1);
            this.Controls.Add(this.tbx7);
            this.Controls.Add(this.tbx6i7);
            this.Controls.Add(this.tbx6a7);
            this.Controls.Add(this.tbx6i6);
            this.Controls.Add(this.tbx6a6);
            this.Controls.Add(this.tbx6i5);
            this.Controls.Add(this.tbx6a5);
            this.Controls.Add(this.tbx6i4);
            this.Controls.Add(this.tbx6a4);
            this.Controls.Add(this.tbx6i3);
            this.Controls.Add(this.tbx6a3);
            this.Controls.Add(this.tbx6i2);
            this.Controls.Add(this.tbx6a2);
            this.Controls.Add(this.tbx6i1);
            this.Controls.Add(this.tbx6a1);
            this.Controls.Add(this.tbx5i7);
            this.Controls.Add(this.tbx5a7);
            this.Controls.Add(this.tbx5i6);
            this.Controls.Add(this.tbx5a6);
            this.Controls.Add(this.tbx5i5);
            this.Controls.Add(this.tbx5a5);
            this.Controls.Add(this.tbx5i4);
            this.Controls.Add(this.tbx5a4);
            this.Controls.Add(this.tbx5i3);
            this.Controls.Add(this.tbx5a3);
            this.Controls.Add(this.tbx5i2);
            this.Controls.Add(this.tbx5a2);
            this.Controls.Add(this.tbx5i1);
            this.Controls.Add(this.tbx5a1);
            this.Controls.Add(this.tbx4i7);
            this.Controls.Add(this.tbx4a7);
            this.Controls.Add(this.tbx4i6);
            this.Controls.Add(this.tbx4a6);
            this.Controls.Add(this.tbx4i5);
            this.Controls.Add(this.tbx4a5);
            this.Controls.Add(this.tbx4i4);
            this.Controls.Add(this.tbx4a4);
            this.Controls.Add(this.tbx4i3);
            this.Controls.Add(this.tbx4a3);
            this.Controls.Add(this.tbx4i2);
            this.Controls.Add(this.tbx4a2);
            this.Controls.Add(this.tbx4i1);
            this.Controls.Add(this.tbx4a1);
            this.Controls.Add(this.tbx3i7);
            this.Controls.Add(this.tbx3a7);
            this.Controls.Add(this.tbx3i6);
            this.Controls.Add(this.tbx3a6);
            this.Controls.Add(this.tbx3i5);
            this.Controls.Add(this.tbx3a5);
            this.Controls.Add(this.tbx3i4);
            this.Controls.Add(this.tbx3a4);
            this.Controls.Add(this.tbx3i3);
            this.Controls.Add(this.tbx3a3);
            this.Controls.Add(this.tbx3i2);
            this.Controls.Add(this.tbx3a2);
            this.Controls.Add(this.tbx3i1);
            this.Controls.Add(this.tbx3a1);
            this.Controls.Add(this.tbx2i7);
            this.Controls.Add(this.tbx2a7);
            this.Controls.Add(this.tbx2i6);
            this.Controls.Add(this.tbx2a6);
            this.Controls.Add(this.tbx2i5);
            this.Controls.Add(this.tbx2a5);
            this.Controls.Add(this.tbx2i4);
            this.Controls.Add(this.tbx2a4);
            this.Controls.Add(this.tbx2i3);
            this.Controls.Add(this.tbx2a3);
            this.Controls.Add(this.tbx2i2);
            this.Controls.Add(this.tbx2a2);
            this.Controls.Add(this.tbx2i1);
            this.Controls.Add(this.tbx2a1);
            this.Controls.Add(this.tbx1i7);
            this.Controls.Add(this.tbx1a7);
            this.Controls.Add(this.tbx1i6);
            this.Controls.Add(this.tbx1a6);
            this.Controls.Add(this.tbx1i5);
            this.Controls.Add(this.tbx1a5);
            this.Controls.Add(this.tbx1i4);
            this.Controls.Add(this.tbx1a4);
            this.Controls.Add(this.tbx1i3);
            this.Controls.Add(this.tbx1a3);
            this.Controls.Add(this.tbx1i2);
            this.Controls.Add(this.tbx1a2);
            this.Controls.Add(this.tbx1i1);
            this.Controls.Add(this.tbx1a1);
            this.Controls.Add(this.tbxki7);
            this.Controls.Add(this.tbxka7);
            this.Controls.Add(this.tbxki6);
            this.Controls.Add(this.tbxka6);
            this.Controls.Add(this.tbxki5);
            this.Controls.Add(this.tbxka5);
            this.Controls.Add(this.tbxki4);
            this.Controls.Add(this.tbxka4);
            this.Controls.Add(this.tbxki3);
            this.Controls.Add(this.tbxka3);
            this.Controls.Add(this.tbxki2);
            this.Controls.Add(this.tbxka2);
            this.Controls.Add(this.tbxki1);
            this.Controls.Add(this.tbxka1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.tbx6);
            this.Controls.Add(this.tbx5);
            this.Controls.Add(this.tbx4);
            this.Controls.Add(this.tbx3);
            this.Controls.Add(this.tbx2);
            this.Controls.Add(this.tbx1);
            this.Controls.Add(this.tbxk);
            this.Controls.Add(this.button1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ReactionResol";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbxk;
        private System.Windows.Forms.TextBox tbx1;
        private System.Windows.Forms.TextBox tbx2;
        private System.Windows.Forms.TextBox tbx3;
        private System.Windows.Forms.TextBox tbx4;
        private System.Windows.Forms.TextBox tbx5;
        private System.Windows.Forms.TextBox tbx6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox tbxka1;
        private System.Windows.Forms.TextBox tbxki1;
        private System.Windows.Forms.TextBox tbxka2;
        private System.Windows.Forms.TextBox tbxki2;
        private System.Windows.Forms.TextBox tbxka3;
        private System.Windows.Forms.TextBox tbxki3;
        private System.Windows.Forms.TextBox tbxka4;
        private System.Windows.Forms.TextBox tbxki4;
        private System.Windows.Forms.TextBox tbxka5;
        private System.Windows.Forms.TextBox tbxki5;
        private System.Windows.Forms.TextBox tbxka6;
        private System.Windows.Forms.TextBox tbxki6;
        private System.Windows.Forms.TextBox tbxka7;
        private System.Windows.Forms.TextBox tbxki7;
        private System.Windows.Forms.TextBox tbx1i7;
        private System.Windows.Forms.TextBox tbx1a7;
        private System.Windows.Forms.TextBox tbx1i6;
        private System.Windows.Forms.TextBox tbx1a6;
        private System.Windows.Forms.TextBox tbx1i5;
        private System.Windows.Forms.TextBox tbx1a5;
        private System.Windows.Forms.TextBox tbx1i4;
        private System.Windows.Forms.TextBox tbx1a4;
        private System.Windows.Forms.TextBox tbx1i3;
        private System.Windows.Forms.TextBox tbx1a3;
        private System.Windows.Forms.TextBox tbx1i2;
        private System.Windows.Forms.TextBox tbx1a2;
        private System.Windows.Forms.TextBox tbx1i1;
        private System.Windows.Forms.TextBox tbx1a1;
        private System.Windows.Forms.TextBox tbx2i7;
        private System.Windows.Forms.TextBox tbx2a7;
        private System.Windows.Forms.TextBox tbx2i6;
        private System.Windows.Forms.TextBox tbx2a6;
        private System.Windows.Forms.TextBox tbx2i5;
        private System.Windows.Forms.TextBox tbx2a5;
        private System.Windows.Forms.TextBox tbx2i4;
        private System.Windows.Forms.TextBox tbx2a4;
        private System.Windows.Forms.TextBox tbx2i3;
        private System.Windows.Forms.TextBox tbx2a3;
        private System.Windows.Forms.TextBox tbx2i2;
        private System.Windows.Forms.TextBox tbx2a2;
        private System.Windows.Forms.TextBox tbx2i1;
        private System.Windows.Forms.TextBox tbx2a1;
        private System.Windows.Forms.TextBox tbx3i7;
        private System.Windows.Forms.TextBox tbx3a7;
        private System.Windows.Forms.TextBox tbx3i6;
        private System.Windows.Forms.TextBox tbx3a6;
        private System.Windows.Forms.TextBox tbx3i5;
        private System.Windows.Forms.TextBox tbx3a5;
        private System.Windows.Forms.TextBox tbx3i4;
        private System.Windows.Forms.TextBox tbx3a4;
        private System.Windows.Forms.TextBox tbx3i3;
        private System.Windows.Forms.TextBox tbx3a3;
        private System.Windows.Forms.TextBox tbx3i2;
        private System.Windows.Forms.TextBox tbx3a2;
        private System.Windows.Forms.TextBox tbx3i1;
        private System.Windows.Forms.TextBox tbx3a1;
        private System.Windows.Forms.TextBox tbx4i7;
        private System.Windows.Forms.TextBox tbx4a7;
        private System.Windows.Forms.TextBox tbx4i6;
        private System.Windows.Forms.TextBox tbx4a6;
        private System.Windows.Forms.TextBox tbx4i5;
        private System.Windows.Forms.TextBox tbx4a5;
        private System.Windows.Forms.TextBox tbx4i4;
        private System.Windows.Forms.TextBox tbx4a4;
        private System.Windows.Forms.TextBox tbx4i3;
        private System.Windows.Forms.TextBox tbx4a3;
        private System.Windows.Forms.TextBox tbx4i2;
        private System.Windows.Forms.TextBox tbx4a2;
        private System.Windows.Forms.TextBox tbx4i1;
        private System.Windows.Forms.TextBox tbx4a1;
        private System.Windows.Forms.TextBox tbx5i7;
        private System.Windows.Forms.TextBox tbx5a7;
        private System.Windows.Forms.TextBox tbx5i6;
        private System.Windows.Forms.TextBox tbx5a6;
        private System.Windows.Forms.TextBox tbx5i5;
        private System.Windows.Forms.TextBox tbx5a5;
        private System.Windows.Forms.TextBox tbx5i4;
        private System.Windows.Forms.TextBox tbx5a4;
        private System.Windows.Forms.TextBox tbx5i3;
        private System.Windows.Forms.TextBox tbx5a3;
        private System.Windows.Forms.TextBox tbx5i2;
        private System.Windows.Forms.TextBox tbx5a2;
        private System.Windows.Forms.TextBox tbx5i1;
        private System.Windows.Forms.TextBox tbx5a1;
        private System.Windows.Forms.TextBox tbx6i7;
        private System.Windows.Forms.TextBox tbx6a7;
        private System.Windows.Forms.TextBox tbx6i6;
        private System.Windows.Forms.TextBox tbx6a6;
        private System.Windows.Forms.TextBox tbx6i5;
        private System.Windows.Forms.TextBox tbx6a5;
        private System.Windows.Forms.TextBox tbx6i4;
        private System.Windows.Forms.TextBox tbx6a4;
        private System.Windows.Forms.TextBox tbx6i3;
        private System.Windows.Forms.TextBox tbx6a3;
        private System.Windows.Forms.TextBox tbx6i2;
        private System.Windows.Forms.TextBox tbx6a2;
        private System.Windows.Forms.TextBox tbx6i1;
        private System.Windows.Forms.TextBox tbx6a1;
        private System.Windows.Forms.TextBox tbx7i7;
        private System.Windows.Forms.TextBox tbx7a7;
        private System.Windows.Forms.TextBox tbx7i6;
        private System.Windows.Forms.TextBox tbx7a6;
        private System.Windows.Forms.TextBox tbx7i5;
        private System.Windows.Forms.TextBox tbx7a5;
        private System.Windows.Forms.TextBox tbx7i4;
        private System.Windows.Forms.TextBox tbx7a4;
        private System.Windows.Forms.TextBox tbx7i3;
        private System.Windows.Forms.TextBox tbx7a3;
        private System.Windows.Forms.TextBox tbx7i2;
        private System.Windows.Forms.TextBox tbx7a2;
        private System.Windows.Forms.TextBox tbx7i1;
        private System.Windows.Forms.TextBox tbx7a1;
        private System.Windows.Forms.TextBox tbx7;
        private System.Windows.Forms.TextBox tbx8i7;
        private System.Windows.Forms.TextBox tbx8a7;
        private System.Windows.Forms.TextBox tbx8i6;
        private System.Windows.Forms.TextBox tbx8a6;
        private System.Windows.Forms.TextBox tbx8i5;
        private System.Windows.Forms.TextBox tbx8a5;
        private System.Windows.Forms.TextBox tbx8i4;
        private System.Windows.Forms.TextBox tbx8a4;
        private System.Windows.Forms.TextBox tbx8i3;
        private System.Windows.Forms.TextBox tbx8a3;
        private System.Windows.Forms.TextBox tbx8i2;
        private System.Windows.Forms.TextBox tbx8a2;
        private System.Windows.Forms.TextBox tbx8i1;
        private System.Windows.Forms.TextBox tbx8a1;
        private System.Windows.Forms.TextBox tbx8;
        private System.Windows.Forms.TextBox tbxki9;
        private System.Windows.Forms.TextBox tbxka9;
        private System.Windows.Forms.TextBox tbxki8;
        private System.Windows.Forms.TextBox tbxka8;
        private System.Windows.Forms.TextBox tbx1i9;
        private System.Windows.Forms.TextBox tbx1a9;
        private System.Windows.Forms.TextBox tbx1i8;
        private System.Windows.Forms.TextBox tbx1a8;
        private System.Windows.Forms.TextBox tbx2i9;
        private System.Windows.Forms.TextBox tbx2a9;
        private System.Windows.Forms.TextBox tbx2i8;
        private System.Windows.Forms.TextBox tbx2a8;
        private System.Windows.Forms.TextBox tbx3i9;
        private System.Windows.Forms.TextBox tbx3a9;
        private System.Windows.Forms.TextBox tbx3i8;
        private System.Windows.Forms.TextBox tbx3a8;
        private System.Windows.Forms.TextBox tbx4i9;
        private System.Windows.Forms.TextBox tbx4a9;
        private System.Windows.Forms.TextBox tbx4i8;
        private System.Windows.Forms.TextBox tbx4a8;
        private System.Windows.Forms.TextBox tbx5i9;
        private System.Windows.Forms.TextBox tbx5a9;
        private System.Windows.Forms.TextBox tbx5i8;
        private System.Windows.Forms.TextBox tbx5a8;
        private System.Windows.Forms.TextBox tbx6i9;
        private System.Windows.Forms.TextBox tbx6a9;
        private System.Windows.Forms.TextBox tbx6i8;
        private System.Windows.Forms.TextBox tbx6a8;
        private System.Windows.Forms.TextBox tbx7i9;
        private System.Windows.Forms.TextBox tbx7a9;
        private System.Windows.Forms.TextBox tbx7i8;
        private System.Windows.Forms.TextBox tbx7a8;
        private System.Windows.Forms.TextBox tbx8i9;
        private System.Windows.Forms.TextBox tbx8a9;
        private System.Windows.Forms.TextBox tbx8i8;
        private System.Windows.Forms.TextBox tbx8a8;
    }
}

