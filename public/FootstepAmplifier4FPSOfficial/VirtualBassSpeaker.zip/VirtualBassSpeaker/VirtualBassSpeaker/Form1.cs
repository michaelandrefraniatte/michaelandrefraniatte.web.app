﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using CSCore.SoundIn;
using CSCore.Streams;
using NAudio.Wave;
using NAudio.Extras;

namespace VirtualBassSpeaker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        [DllImport("winmm.dll", EntryPoint = "timeBeginPeriod")]
        public static extern uint TimeBeginPeriod(uint ms);
        [DllImport("winmm.dll", EntryPoint = "timeEndPeriod")]
        public static extern uint TimeEndPeriod(uint ms);
        [DllImport("ntdll.dll", EntryPoint = "NtSetTimerResolution")]
        public static extern void NtSetTimerResolution(uint DesiredResolution, bool SetResolution, ref uint CurrentResolution);
        public static uint CurrentResolution = 0;
        private static WasapiCapture soundInEq;
        private static NAudio.Wave.WaveOut soundOutEq;
        private NAudio.Extras.Equalizer equalizer;
        private EqualizerBand[] bands;
        public static float volumeleft, volumeright;
        public static BufferedWaveProvider src = new BufferedWaveProvider(NAudio.Wave.WaveFormat.CreateIeeeFloatWaveFormat(48000, 2));
        private bool startstopbool = false;
        private void Form1_Shown(object sender, EventArgs e)
        {
            TimeBeginPeriod(1);
            NtSetTimerResolution(1, true, ref CurrentResolution);
            for (int i = 0; i < NAudio.Wave.WaveOut.DeviceCount; i++)
            {
                WaveOutCapabilities waveoutCapabilities = NAudio.Wave.WaveOut.GetCapabilities(i);
                comboBox1.Items.Add(waveoutCapabilities.ProductName);
            }
            try
            {
                if (System.IO.File.Exists("tempsave"))
                {
                    using (System.IO.StreamReader file = new System.IO.StreamReader("tempsave"))
                    {
                        trackBar2.Value = Convert.ToInt32(file.ReadLine());
                        trackBar3.Value = Convert.ToInt32(file.ReadLine());
                        trackBar4.Value = Convert.ToInt32(file.ReadLine());
                        trackBar5.Value = Convert.ToInt32(file.ReadLine());
                        trackBar6.Value = Convert.ToInt32(file.ReadLine());
                        trackBar7.Value = Convert.ToInt32(file.ReadLine());
                        trackBar8.Value = Convert.ToInt32(file.ReadLine());
                        trackBar9.Value = Convert.ToInt32(file.ReadLine());
                        comboBox1.SelectedIndex = Convert.ToInt32(file.ReadLine());
                    }
                }
            }
            catch { }
        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                soundOutEq.Stop();
            }
            catch { }
            try
            {
                soundInEq.Stop();
            }
            catch { }
            using (System.IO.StreamWriter createdfile = new System.IO.StreamWriter("tempsave"))
            {
                createdfile.WriteLine(trackBar2.Value);
                createdfile.WriteLine(trackBar3.Value);
                createdfile.WriteLine(trackBar4.Value);
                createdfile.WriteLine(trackBar5.Value);
                createdfile.WriteLine(trackBar6.Value);
                createdfile.WriteLine(trackBar7.Value);
                createdfile.WriteLine(trackBar8.Value);
                createdfile.WriteLine(trackBar9.Value);
                createdfile.WriteLine(comboBox1.SelectedIndex);
            }
        }
        private void SetRec()
        {
            soundInEq = new CSCore.SoundIn.WasapiLoopbackCapture();
            soundInEq.Initialize();
            soundInEq.DataAvailable += (sound, card) =>
            {
                Task.Run(() => src.AddSamples(card.Data, card.Offset, card.ByteCount));
            };
        }
        private void SetEq()
        {
            bands = new EqualizerBand[]
                    {
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 100, Gain = trackBar2.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 200, Gain = trackBar3.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 400, Gain = trackBar4.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 800, Gain = trackBar5.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 1200, Gain = trackBar6.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 2400, Gain = trackBar7.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 4800, Gain = trackBar8.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 9600, Gain = trackBar9.Value},
                    };
            soundOutEq = new NAudio.Wave.WaveOut();
            equalizer = new Equalizer(src.ToSampleProvider(), bands);
            soundOutEq.DeviceNumber = comboBox1.SelectedIndex;
            soundOutEq.Init(equalizer);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (!startstopbool)
            {
                SetRec();
                SetEq();
                Task.Run(() => soundOutEq.Play());
                Task.Run(() => soundInEq.Start());
                button1.Text = "Stop";
                startstopbool = true;
            }
            else
            {
                try
                {
                    soundOutEq.Stop();
                }
                catch { }
                try
                {
                    soundInEq.Stop();
                }
                catch { }
                button1.Text = "Start";
                startstopbool = false;
            }
        }
    }
}