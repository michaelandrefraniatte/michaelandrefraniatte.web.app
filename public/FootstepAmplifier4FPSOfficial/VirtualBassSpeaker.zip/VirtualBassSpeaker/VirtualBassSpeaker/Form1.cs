﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using CSCore.SoundIn;
using CSCore.Streams;
using NAudio.Wave;
using NAudio.Extras;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace VirtualBassSpeaker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        [DllImport("winmm.dll", EntryPoint = "timeBeginPeriod")]
        public static extern uint TimeBeginPeriod(uint ms);
        [DllImport("winmm.dll", EntryPoint = "timeEndPeriod")]
        public static extern uint TimeEndPeriod(uint ms);
        [DllImport("ntdll.dll", EntryPoint = "NtSetTimerResolution")]
        public static extern void NtSetTimerResolution(uint DesiredResolution, bool SetResolution, ref uint CurrentResolution);
        public static uint CurrentResolution = 0;
        private static WasapiCapture soundInEq;
        private static NAudio.Wave.WaveOut soundOutEq;
        private NAudio.Extras.Equalizer equalizer;
        private EqualizerBand[] bands;
        private static MediaFoundationReader audioFileReader;
        public static float volumeleft, volumeright;
        private static VolumeStereoSampleProvider stereo;
        public static byte[] rawdata;
        public static BufferedWaveProvider src;
        private bool startstopbool = false;
        private void Form1_Shown(object sender, EventArgs e)
        {
            TimeBeginPeriod(1);
            NtSetTimerResolution(1, true, ref CurrentResolution);
            Task.Run(() => InitSoundPlay());
        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Stop();
            using (System.IO.StreamWriter createdfile = new System.IO.StreamWriter("tempsave"))
            {
                createdfile.WriteLine(trackBar1.Value);
                createdfile.WriteLine(trackBar2.Value);
                createdfile.WriteLine(trackBar3.Value);
                createdfile.WriteLine(trackBar4.Value);
                createdfile.WriteLine(trackBar5.Value);
                createdfile.WriteLine(trackBar6.Value);
                createdfile.WriteLine(trackBar7.Value);
                createdfile.WriteLine(trackBar8.Value);
                createdfile.WriteLine(trackBar9.Value);
                createdfile.WriteLine(trackBar10.Value);
                createdfile.WriteLine(comboBox1.SelectedIndex);
            }
        }
        private void SetEq()
        {
            SetEqualizerBand();
            src = new BufferedWaveProvider(NAudio.Wave.WaveFormat.CreateIeeeFloatWaveFormat(48000, 2));
            soundOutEq = new NAudio.Wave.WaveOut();
            stereo = new VolumeStereoSampleProvider(src.ToSampleProvider());
            equalizer = new Equalizer(stereo, bands);
            soundOutEq.DeviceNumber = comboBox1.SelectedIndex;
            soundOutEq.Init(equalizer);
            soundOutEq.Play();
            soundInEq = new CSCore.SoundIn.WasapiLoopbackCapture();
            soundInEq.Initialize();
            SoundInSource soundInSource = new SoundInSource(soundInEq) { FillWithZeros = true };
            soundInSource.DataAvailable += (sound, card) =>
            {
                rawdata = new byte[card.ByteCount];
                Array.Copy(card.Data, card.Offset, rawdata, 0, card.ByteCount);
                Task.Run(() => Play());
            };
            soundInEq.Start();
        }
        private void Play()
        {
            try
            {
                src.AddSamples(rawdata, 0, rawdata.Length);
            }
            catch { }
        }
        private void InitSoundPlay()
        {
            for (int i = 0; i < NAudio.Wave.WaveOut.DeviceCount; i++)
            {
                WaveOutCapabilities waveoutCapabilities = NAudio.Wave.WaveOut.GetCapabilities(i);
                comboBox1.Items.Add(waveoutCapabilities.ProductName);
            }
            try
            {
                if (System.IO.File.Exists("tempsave"))
                {
                    using (System.IO.StreamReader file = new System.IO.StreamReader("tempsave"))
                    {
                        trackBar1.Value = Convert.ToInt32(file.ReadLine());
                        trackBar2.Value = Convert.ToInt32(file.ReadLine());
                        trackBar3.Value = Convert.ToInt32(file.ReadLine());
                        trackBar4.Value = Convert.ToInt32(file.ReadLine());
                        trackBar5.Value = Convert.ToInt32(file.ReadLine());
                        trackBar6.Value = Convert.ToInt32(file.ReadLine());
                        trackBar7.Value = Convert.ToInt32(file.ReadLine());
                        trackBar8.Value = Convert.ToInt32(file.ReadLine());
                        trackBar9.Value = Convert.ToInt32(file.ReadLine());
                        trackBar10.Value = Convert.ToInt32(file.ReadLine());
                        comboBox1.SelectedIndex = Convert.ToInt32(file.ReadLine());
                    }
                }
            }
            catch { }
            SetEqualizerBand();
            audioFileReader = new MediaFoundationReader("silence.mp3");
            stereo = new VolumeStereoSampleProvider(audioFileReader.ToSampleProvider());
            equalizer = new Equalizer(stereo, bands);
            soundOutEq = new NAudio.Wave.WaveOut();
            soundOutEq.DeviceNumber = comboBox1.SelectedIndex;
            soundOutEq.Init(equalizer);
            soundOutEq.Play();
        }
        private void SetEqualizerBand()
        {
            bands = new EqualizerBand[]
                    {
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 100, Gain = trackBar2.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 200, Gain = trackBar3.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 400, Gain = trackBar4.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 800, Gain = trackBar5.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 1200, Gain = trackBar6.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 2400, Gain = trackBar7.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 4800, Gain = trackBar8.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 9600, Gain = trackBar9.Value},
                    };
            volumeleft = trackBar1.Value / 100f;
            volumeright = trackBar10.Value / 100f;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (!startstopbool)
            {
                SetEq();
                button1.Text = "Stop";
                startstopbool = true;
            }
            else
            {
                Stop();
                button1.Text = "Start";
                startstopbool = false;
            }
        }
        private static void Stop()
        {
            try
            {
                soundOutEq.Stop();
            }
            catch { }
            try
            {
                soundInEq.Stop();
            }
            catch { }
        }
    }
    /// <summary>
    /// Very simple sample provider supporting adjustable gain
    /// </summary>
    public class VolumeStereoSampleProvider : ISampleProvider
    {
        private readonly ISampleProvider source;

        /// <summary>
        /// Allows adjusting the volume left channel, 1.0f = full volume
        /// </summary>
        public float VolumeLeft { get; set; }

        /// <summary>
        /// Allows adjusting the volume right channel, 1.0f = full volume
        /// </summary>
        public float VolumeRight { get; set; }

        /// <summary>
        /// Initializes a new instance of VolumeStereoSampleProvider
        /// </summary>
        /// <param name="source">Source sample provider, must be stereo</param>
        public VolumeStereoSampleProvider(ISampleProvider source)
        {
            this.source = source;
            VolumeLeft = Form1.volumeleft;
            VolumeRight = Form1.volumeright;
        }

        /// <summary>
        /// WaveFormat
        /// </summary>
        public NAudio.Wave.WaveFormat WaveFormat => source.WaveFormat;

        /// <summary>
        /// Reads samples from this sample provider
        /// </summary>
        /// <param name="buffer">Sample buffer</param>
        /// <param name="offset">Offset into sample buffer</param>
        /// <param name="sampleCount">Number of samples desired</param>
        /// <returns>Number of samples read</returns>
        public int Read(float[] buffer, int offset, int sampleCount)
        {
            int samplesRead = source.Read(buffer, offset, sampleCount);

            for (int n = 0; n < sampleCount; n += 2)
            {
                buffer[offset + n] *= VolumeLeft;
                buffer[offset + n + 1] *= VolumeRight;
            }

            return samplesRead;
        }
    }
}
