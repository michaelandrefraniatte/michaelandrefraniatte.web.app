chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {

removeAds();

function removeAds() {
	try {
                    var els = document.getElementsByClassName("video-ads ytp-ad-module");
                    for (var i=0;i<els.length; i++) {
                        els[i].click();
                    }
                    document.cookie = "VISITOR_INFO1_LIVE = oKckVSqvaGw; path =/; domain =.youtube.com";
                    var cookies = document.cookie.split("; ");
                    for (var i = 0; i < cookies.length; i++)
                    {
                        var cookie = cookies[i];
                        var eqPos = cookie.indexOf("=");
                        var name = eqPos > -1 ? cookie.substr(0, eqPos) : cookie;
                        document.cookie = name + "=;expires=Thu, 01 Jan 1970 00:00:00 GMT";
                    }
                    var el = document.getElementsByClassName("ytp-ad-skip-button");
                    for (var i=0;i<el.length; i++) {
                        el[i].click();
                    }
                    var element = document.getElementsByClassName("ytp-ad-overlay-close-button");
                    for (var i=0;i<element.length; i++) {
                        element[i].click();
                    }
                    var scripts = document.getElementsByTagName("script");
                    for (let i = 0; i < scripts.length; i++)
                    {
                        var content = scripts[i].innerHTML;
                        if (content.indexOf("ytp-ad") > -1) {
                            scripts[i].innerHTML = "";
                        }
                        var src = scripts[i].getAttribute("src");
                        if (src.indexOf("ytp-ad") > -1) {
                            scripts[i].setAttribute("src", "");
                        }
                    }
                    var iframes = document.getElementsByTagName("iframe");
                    for (let i = 0; i < iframes.length; i++)
                    {
                        var content = iframes[i].innerHTML;
                        if (content.indexOf("ytp-ad") > -1) {
                            iframes[i].innerHTML = "";
                        }
                        var src = iframes[i].getAttribute("src");
                        if (src.indexOf("ytp-ad") > -1) {
                            iframes[i].setAttribute("src", "");
                        }
                    }
                    var allelements = document.querySelectorAll("*");
                    for (var i = 0; i < allelements.length; i++) {
	                    var classname = allelements[i].className;
                        if (classname.indexOf("ytp-ad") > -1)  {
                                allelements[i].innerHTML = "";
			            }
                    }
	}
	catch { }
	setTimeout(removeAds, 3000);
}

  sendResponse({ fromcontent: "This message is from content.js" });
});
