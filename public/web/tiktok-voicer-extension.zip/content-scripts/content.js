chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {

    (function () {
        getScript('https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js', function () {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            if (SpeechRecognition !== undefined) {
                let recognition = new SpeechRecognition();
                recognition.onstart = () => {
                    console.warn("voice recognition supported");
                };
                recognition.onspeechend = () => {
                    recognition.stop();
                    setTimeout(() => { recognition.start() }, 1000);
                };
                recognition.onresult = (result) => {
                    console.warn(result.results[0][0].transcript);
                    if (result.results[0][0].transcript == "Next.") {
                        try {
                            var element = $(".tiktok-1nncbiz-DivItemContainer:visible");
                            $("html, body").animate({ scrollTop: element.next().offset().top }, 'slow');
                        }
                        catch {}
                        var element = $("#navigation-button-down ytd-button-renderer yt-button-shape button");
                        element.click();
                        console.warn("next video");
                    }
                    if (result.results[0][0].transcript == "Previous.") {
                        try {
                            var element = $(".tiktok-1nncbiz-DivItemContainer:visible");
                            $("html, body").animate({ scrollTop: element.prev().offset().top }, 'slow');
                        }
                        catch {}
                        var element = $("#navigation-button-up ytd-button-renderer yt-button-shape button");
                        element.click();
                        console.warn("previous video");
                    }
                    if (result.results[0][0].transcript == "Like.") {
                        try {
                            var element = $(".tiktok-1ok4pbl-ButtonActionItem:visible");
                            element.click();
                        }
                        catch {}
                        var element = $("#like-button yt-button-shape label button");
                        element.click();
                        console.warn("like video");
                    }
                };
                recognition.start();
            } 
            else {
                console.warn("voice recognition not supported");
            }
        });
        function getScript(url, success) {
            var script = document.createElement('script');
            script.src = url;
            var head = document.getElementsByTagName('head')[0],
                done = false;
            script.onload = script.onreadystatechange = function () {
                if (!done && (!this.readyState
                    || this.readyState == 'loaded'
                    || this.readyState == 'complete')) {
                    done = true;
                    success();
                    script.onload = script.onreadystatechange = null;
                    head.removeChild(script);
                }
            };
            head.appendChild(script);
        }
    })();

    sendResponse({ fromcontent: "This message is from content.js" });
    
});