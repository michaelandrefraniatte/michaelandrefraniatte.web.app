chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {

    (function () {
        getScript('https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js', function () {
            $(document).ready(function () {
                const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
                if (SpeechRecognition !== undefined) {
                        let recognition = new SpeechRecognition();
                        recognition.onstart = () => {
                            console.warn('supported 😭');
                        };
                        recognition.onspeechend = () => {
                            console.warn('stopped 😭');
                            recognition.stop();
                            setTimeout(() => { recognition.start() }, 1000);
                        };
                        recognition.onresult = (result) => {
                            console.log(result.results[0][0].transcript);
                        };
                        recognition.start();
                  } 
                  else {
                        console.warn('not supported 😭');
                  }
            });
        });
        function getScript(url, success) {
            var script = document.createElement('script');
            script.src = url;
            var head = document.getElementsByTagName('head')[0],
                done = false;
            script.onload = script.onreadystatechange = function () {
                if (!done && (!this.readyState
                    || this.readyState == 'loaded'
                    || this.readyState == 'complete')) {
                    done = true;
                    success();
                    script.onload = script.onreadystatechange = null;
                    head.removeChild(script);
                }
            };
            head.appendChild(script);
        }
    })();

    sendResponse({ fromcontent: "This message is from content.js" });
    
});