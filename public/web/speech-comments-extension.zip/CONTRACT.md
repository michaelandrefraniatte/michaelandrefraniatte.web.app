
Use and Agreement Contract for Using Works of Owner

Owner: Michael Andre Franiatte.

Contact: michael.franiatte@gmail.com.

Proof of Owning: Works published, and writings/speakings all over.

Subjects of Claims: Works published by the owner on different platforms in different ways, partially or not, deliberate or not.

Owning: All works from scratch of the owner, near 100% of published works, near 100% of creativity impact.

Concerning Author Rights: Equations and codes from scratch of the owner, softwares built from it, all things of people arising from it.

Availability of Works: Only under the shapes of the owner built, only for personal use.

Requirements of Use: Contact the owner, pay the owner, quote the owner, have agreement of the owner.

End User License Agreement: A commercial license is required to use in personal manner. Do not redistributing in any manner, including by computer media, a file server, an email attachment, etc. Do not embedding in or linking it to another programs, source codes and assistances including internal applications, scripts, batch files, etc. Do not use for any kind of technical support including on customer or retailer computer, hardware or software development, research, discovery, teachery, talk, speech, write, etc. Do not use for win money or for commercialisation of any products arising from owner programs, source codes and assistances. Do not use and do not copy the way it run in other programs, source codes and assistances. Do not use without pay, quote and agreement of the owner. Do not steal or copy or reproduce or modify or peer or share. Do not use in other manner than personal. It stand for owner programs, source codes and assistances or programs, source codes and assistances stealing or copying or reproducing or modifying or peering or sharing owner programs, source codes, and assistances. Who is not agree shall not use, and shall pay the price of disagreements.

Terms of License and Price: The present contract acceptance is required to use works of the owner and built from it in all kind of manner. The price for each user shall be defined with the owner by contacting him and this for each subject of works the owner claims. Each user shall contact the owner for asking his agreement. It can be refused by the owner depending who asking and the price defined. People don’t respecting the present contract shall not use the works of the owner, and shall pay the use already done, up to the price defined by owner alone.

