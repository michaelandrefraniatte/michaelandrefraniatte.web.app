chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {

    (function () {
        getScript('https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js', function () {
            $(".ytp-large-play-button").click();
        });
        function getScript(url, success) {
            var script = document.createElement('script');
            script.src = url;
            var head = document.getElementsByTagName('head')[0],
                done = false;
            script.onload = script.onreadystatechange = function () {
                if (!done && (!this.readyState
                    || this.readyState == 'loaded'
                    || this.readyState == 'complete')) {
                    done = true;
                    success();
                    script.onload = script.onreadystatechange = null;
                    head.removeChild(script);
                }
            };
            head.appendChild(script);
        }
    })();
    
    var elements = document.getElementsByClassName("style-scope yt-formatted-string");

    for (i = 0; i < elements.length; i++) {
        var str = elements[i].innerHTML;
        wrapper(str);
    }

    async function wrapper(str) {
        var result = str.match( /[^\.!\?]+[\.!\?]+/g );
        var ssu = new SpeechSynthesisUtterance();
        for(var i = 0; i < result.length; i++) {
            sentence = result[i];
            ssu.text = sentence;
            await new Promise(function(resolve) {
                ssu.onend = resolve;
                window.speechSynthesis.speak(ssu);
            });
        }
    }

    sendResponse({ fromcontent: "This message is from content.js" });
    
});