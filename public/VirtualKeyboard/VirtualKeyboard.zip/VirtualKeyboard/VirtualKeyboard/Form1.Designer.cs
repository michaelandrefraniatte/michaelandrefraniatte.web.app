﻿namespace VirtualKeyboard
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pbescape = new System.Windows.Forms.PictureBox();
            this.pbleftcontrol = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pbq = new System.Windows.Forms.PictureBox();
            this.pbtab = new System.Windows.Forms.PictureBox();
            this.pbcapslock = new System.Windows.Forms.PictureBox();
            this.pbleftshift = new System.Windows.Forms.PictureBox();
            this.pbwindows = new System.Windows.Forms.PictureBox();
            this.pbleftmenu = new System.Windows.Forms.PictureBox();
            this.pbspace = new System.Windows.Forms.PictureBox();
            this.pbrightmenu = new System.Windows.Forms.PictureBox();
            this.pbfn = new System.Windows.Forms.PictureBox();
            this.pbleft = new System.Windows.Forms.PictureBox();
            this.pbright = new System.Windows.Forms.PictureBox();
            this.pbdown = new System.Windows.Forms.PictureBox();
            this.pbup = new System.Windows.Forms.PictureBox();
            this.pbrightshift = new System.Windows.Forms.PictureBox();
            this.pbend = new System.Windows.Forms.PictureBox();
            this.pbpagedown = new System.Windows.Forms.PictureBox();
            this.pbpageup = new System.Windows.Forms.PictureBox();
            this.pbdelete = new System.Windows.Forms.PictureBox();
            this.pbascend = new System.Windows.Forms.PictureBox();
            this.pbbackspace = new System.Windows.Forms.PictureBox();
            this.pbw = new System.Windows.Forms.PictureBox();
            this.pbe = new System.Windows.Forms.PictureBox();
            this.pbr = new System.Windows.Forms.PictureBox();
            this.pbt = new System.Windows.Forms.PictureBox();
            this.pby = new System.Windows.Forms.PictureBox();
            this.pbu = new System.Windows.Forms.PictureBox();
            this.pbi = new System.Windows.Forms.PictureBox();
            this.pbo = new System.Windows.Forms.PictureBox();
            this.pbp = new System.Windows.Forms.PictureBox();
            this.pba = new System.Windows.Forms.PictureBox();
            this.pbs = new System.Windows.Forms.PictureBox();
            this.pbd = new System.Windows.Forms.PictureBox();
            this.pbf = new System.Windows.Forms.PictureBox();
            this.pbg = new System.Windows.Forms.PictureBox();
            this.pbh = new System.Windows.Forms.PictureBox();
            this.pbj = new System.Windows.Forms.PictureBox();
            this.pbk = new System.Windows.Forms.PictureBox();
            this.pbl = new System.Windows.Forms.PictureBox();
            this.pbz = new System.Windows.Forms.PictureBox();
            this.pbx = new System.Windows.Forms.PictureBox();
            this.pbc = new System.Windows.Forms.PictureBox();
            this.pbv = new System.Windows.Forms.PictureBox();
            this.pbb = new System.Windows.Forms.PictureBox();
            this.pbn = new System.Windows.Forms.PictureBox();
            this.pbm = new System.Windows.Forms.PictureBox();
            this.pb1 = new System.Windows.Forms.PictureBox();
            this.pb2 = new System.Windows.Forms.PictureBox();
            this.pb3 = new System.Windows.Forms.PictureBox();
            this.pb4 = new System.Windows.Forms.PictureBox();
            this.pb5 = new System.Windows.Forms.PictureBox();
            this.pb6 = new System.Windows.Forms.PictureBox();
            this.pb7 = new System.Windows.Forms.PictureBox();
            this.pb8 = new System.Windows.Forms.PictureBox();
            this.pb9 = new System.Windows.Forms.PictureBox();
            this.pb0 = new System.Windows.Forms.PictureBox();
            this.pbminus = new System.Windows.Forms.PictureBox();
            this.pbequal = new System.Windows.Forms.PictureBox();
            this.pbhookright = new System.Windows.Forms.PictureBox();
            this.phookleft = new System.Windows.Forms.PictureBox();
            this.pbbackslash = new System.Windows.Forms.PictureBox();
            this.pbdotcomma = new System.Windows.Forms.PictureBox();
            this.pbquote = new System.Windows.Forms.PictureBox();
            this.pbcomma = new System.Windows.Forms.PictureBox();
            this.pbdot = new System.Windows.Forms.PictureBox();
            this.pbslash = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbescape)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbleftcontrol)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbq)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbtab)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcapslock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbleftshift)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbwindows)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbleftmenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbspace)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbrightmenu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbfn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbleft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbright)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbdown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbrightshift)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbend)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbpagedown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbpageup)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbdelete)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbascend)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbbackspace)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbw)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pby)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pba)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbg)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbh)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbj)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbl)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbz)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbm)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbminus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbequal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbhookright)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.phookleft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbbackslash)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbdotcomma)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbquote)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcomma)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbdot)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbslash)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::VirtualKeyboard.Properties.Resources.vk1;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1047, 311);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pbescape
            // 
            this.pbescape.BackColor = System.Drawing.Color.Transparent;
            this.pbescape.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbescape.Location = new System.Drawing.Point(15, 18);
            this.pbescape.Name = "pbescape";
            this.pbescape.Size = new System.Drawing.Size(52, 50);
            this.pbescape.TabIndex = 2;
            this.pbescape.TabStop = false;
            this.pbescape.Click += new System.EventHandler(this.pbescape_Click);
            // 
            // pbleftcontrol
            // 
            this.pbleftcontrol.BackColor = System.Drawing.Color.Transparent;
            this.pbleftcontrol.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbleftcontrol.Location = new System.Drawing.Point(24, 252);
            this.pbleftcontrol.Name = "pbleftcontrol";
            this.pbleftcontrol.Size = new System.Drawing.Size(56, 38);
            this.pbleftcontrol.TabIndex = 3;
            this.pbleftcontrol.TabStop = false;
            this.pbleftcontrol.Click += new System.EventHandler(this.pbleftcontrol_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(1047, 20);
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Location = new System.Drawing.Point(0, 296);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(1047, 15);
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Location = new System.Drawing.Point(0, 18);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(18, 272);
            this.pictureBox4.TabIndex = 6;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Location = new System.Drawing.Point(1029, 18);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(18, 272);
            this.pictureBox5.TabIndex = 7;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // pbq
            // 
            this.pbq.BackColor = System.Drawing.Color.Transparent;
            this.pbq.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbq.Location = new System.Drawing.Point(115, 77);
            this.pbq.Name = "pbq";
            this.pbq.Size = new System.Drawing.Size(47, 45);
            this.pbq.TabIndex = 8;
            this.pbq.TabStop = false;
            this.pbq.Click += new System.EventHandler(this.pbq_Click);
            // 
            // pbtab
            // 
            this.pbtab.BackColor = System.Drawing.Color.Transparent;
            this.pbtab.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbtab.Location = new System.Drawing.Point(24, 77);
            this.pbtab.Name = "pbtab";
            this.pbtab.Size = new System.Drawing.Size(72, 45);
            this.pbtab.TabIndex = 9;
            this.pbtab.TabStop = false;
            this.pbtab.Click += new System.EventHandler(this.pbtab_Click);
            // 
            // pbcapslock
            // 
            this.pbcapslock.BackColor = System.Drawing.Color.Transparent;
            this.pbcapslock.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbcapslock.Location = new System.Drawing.Point(15, 135);
            this.pbcapslock.Name = "pbcapslock";
            this.pbcapslock.Size = new System.Drawing.Size(98, 45);
            this.pbcapslock.TabIndex = 10;
            this.pbcapslock.TabStop = false;
            this.pbcapslock.Click += new System.EventHandler(this.pbcapslock_Click);
            // 
            // pbleftshift
            // 
            this.pbleftshift.BackColor = System.Drawing.Color.Transparent;
            this.pbleftshift.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbleftshift.Location = new System.Drawing.Point(21, 190);
            this.pbleftshift.Name = "pbleftshift";
            this.pbleftshift.Size = new System.Drawing.Size(126, 45);
            this.pbleftshift.TabIndex = 11;
            this.pbleftshift.TabStop = false;
            this.pbleftshift.Click += new System.EventHandler(this.pbleftshift_Click);
            // 
            // pbwindows
            // 
            this.pbwindows.BackColor = System.Drawing.Color.Transparent;
            this.pbwindows.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbwindows.Location = new System.Drawing.Point(106, 252);
            this.pbwindows.Name = "pbwindows";
            this.pbwindows.Size = new System.Drawing.Size(56, 38);
            this.pbwindows.TabIndex = 12;
            this.pbwindows.TabStop = false;
            this.pbwindows.Click += new System.EventHandler(this.pbwindows_Click);
            // 
            // pbleftmenu
            // 
            this.pbleftmenu.BackColor = System.Drawing.Color.Transparent;
            this.pbleftmenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbleftmenu.Location = new System.Drawing.Point(181, 252);
            this.pbleftmenu.Name = "pbleftmenu";
            this.pbleftmenu.Size = new System.Drawing.Size(60, 38);
            this.pbleftmenu.TabIndex = 13;
            this.pbleftmenu.TabStop = false;
            this.pbleftmenu.Click += new System.EventHandler(this.pbleftmenu_Click);
            // 
            // pbspace
            // 
            this.pbspace.BackColor = System.Drawing.Color.Transparent;
            this.pbspace.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbspace.Location = new System.Drawing.Point(258, 252);
            this.pbspace.Name = "pbspace";
            this.pbspace.Size = new System.Drawing.Size(385, 38);
            this.pbspace.TabIndex = 14;
            this.pbspace.TabStop = false;
            this.pbspace.Click += new System.EventHandler(this.pbspace_Click);
            // 
            // pbrightmenu
            // 
            this.pbrightmenu.BackColor = System.Drawing.Color.Transparent;
            this.pbrightmenu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbrightmenu.Location = new System.Drawing.Point(660, 252);
            this.pbrightmenu.Name = "pbrightmenu";
            this.pbrightmenu.Size = new System.Drawing.Size(60, 38);
            this.pbrightmenu.TabIndex = 15;
            this.pbrightmenu.TabStop = false;
            this.pbrightmenu.Click += new System.EventHandler(this.pbrightmenu_Click);
            // 
            // pbfn
            // 
            this.pbfn.BackColor = System.Drawing.Color.Transparent;
            this.pbfn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbfn.Location = new System.Drawing.Point(741, 252);
            this.pbfn.Name = "pbfn";
            this.pbfn.Size = new System.Drawing.Size(60, 38);
            this.pbfn.TabIndex = 16;
            this.pbfn.TabStop = false;
            this.pbfn.Click += new System.EventHandler(this.pbfn_Click);
            // 
            // pbleft
            // 
            this.pbleft.BackColor = System.Drawing.Color.Transparent;
            this.pbleft.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbleft.Location = new System.Drawing.Point(852, 252);
            this.pbleft.Name = "pbleft";
            this.pbleft.Size = new System.Drawing.Size(48, 38);
            this.pbleft.TabIndex = 17;
            this.pbleft.TabStop = false;
            this.pbleft.Click += new System.EventHandler(this.pbleft_Click);
            // 
            // pbright
            // 
            this.pbright.BackColor = System.Drawing.Color.Transparent;
            this.pbright.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbright.Location = new System.Drawing.Point(979, 252);
            this.pbright.Name = "pbright";
            this.pbright.Size = new System.Drawing.Size(48, 38);
            this.pbright.TabIndex = 18;
            this.pbright.TabStop = false;
            this.pbright.Click += new System.EventHandler(this.pbright_Click);
            // 
            // pbdown
            // 
            this.pbdown.BackColor = System.Drawing.Color.Transparent;
            this.pbdown.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbdown.Location = new System.Drawing.Point(915, 252);
            this.pbdown.Name = "pbdown";
            this.pbdown.Size = new System.Drawing.Size(48, 38);
            this.pbdown.TabIndex = 19;
            this.pbdown.TabStop = false;
            this.pbdown.Click += new System.EventHandler(this.pbdown_Click);
            // 
            // pbup
            // 
            this.pbup.BackColor = System.Drawing.Color.Transparent;
            this.pbup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbup.Location = new System.Drawing.Point(915, 190);
            this.pbup.Name = "pbup";
            this.pbup.Size = new System.Drawing.Size(48, 45);
            this.pbup.TabIndex = 20;
            this.pbup.TabStop = false;
            this.pbup.Click += new System.EventHandler(this.pbup_Click);
            // 
            // pbrightshift
            // 
            this.pbrightshift.BackColor = System.Drawing.Color.Transparent;
            this.pbrightshift.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbrightshift.Location = new System.Drawing.Point(804, 190);
            this.pbrightshift.Name = "pbrightshift";
            this.pbrightshift.Size = new System.Drawing.Size(96, 45);
            this.pbrightshift.TabIndex = 21;
            this.pbrightshift.TabStop = false;
            this.pbrightshift.Click += new System.EventHandler(this.pbrightshift_Click);
            // 
            // pbend
            // 
            this.pbend.BackColor = System.Drawing.Color.Transparent;
            this.pbend.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbend.Location = new System.Drawing.Point(979, 190);
            this.pbend.Name = "pbend";
            this.pbend.Size = new System.Drawing.Size(48, 45);
            this.pbend.TabIndex = 22;
            this.pbend.TabStop = false;
            this.pbend.Click += new System.EventHandler(this.pbend_Click);
            // 
            // pbpagedown
            // 
            this.pbpagedown.BackColor = System.Drawing.Color.Transparent;
            this.pbpagedown.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbpagedown.Location = new System.Drawing.Point(979, 135);
            this.pbpagedown.Name = "pbpagedown";
            this.pbpagedown.Size = new System.Drawing.Size(48, 45);
            this.pbpagedown.TabIndex = 23;
            this.pbpagedown.TabStop = false;
            this.pbpagedown.Click += new System.EventHandler(this.pbpagedown_Click);
            // 
            // pbpageup
            // 
            this.pbpageup.BackColor = System.Drawing.Color.Transparent;
            this.pbpageup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbpageup.Location = new System.Drawing.Point(979, 77);
            this.pbpageup.Name = "pbpageup";
            this.pbpageup.Size = new System.Drawing.Size(48, 45);
            this.pbpageup.TabIndex = 24;
            this.pbpageup.TabStop = false;
            this.pbpageup.Click += new System.EventHandler(this.pbpageup_Click);
            // 
            // pbdelete
            // 
            this.pbdelete.BackColor = System.Drawing.Color.Transparent;
            this.pbdelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbdelete.Location = new System.Drawing.Point(979, 18);
            this.pbdelete.Name = "pbdelete";
            this.pbdelete.Size = new System.Drawing.Size(48, 45);
            this.pbdelete.TabIndex = 25;
            this.pbdelete.TabStop = false;
            this.pbdelete.Click += new System.EventHandler(this.pbdelete_Click);
            // 
            // pbascend
            // 
            this.pbascend.BackColor = System.Drawing.Color.Transparent;
            this.pbascend.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbascend.Location = new System.Drawing.Point(837, 135);
            this.pbascend.Name = "pbascend";
            this.pbascend.Size = new System.Drawing.Size(126, 45);
            this.pbascend.TabIndex = 26;
            this.pbascend.TabStop = false;
            this.pbascend.Click += new System.EventHandler(this.pbascend_Click);
            // 
            // pbbackspace
            // 
            this.pbbackspace.BackColor = System.Drawing.Color.Transparent;
            this.pbbackspace.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbbackspace.Location = new System.Drawing.Point(852, 18);
            this.pbbackspace.Name = "pbbackspace";
            this.pbbackspace.Size = new System.Drawing.Size(111, 45);
            this.pbbackspace.TabIndex = 27;
            this.pbbackspace.TabStop = false;
            this.pbbackspace.Click += new System.EventHandler(this.pbbackspace_Click);
            // 
            // pbw
            // 
            this.pbw.BackColor = System.Drawing.Color.Transparent;
            this.pbw.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbw.Location = new System.Drawing.Point(181, 77);
            this.pbw.Name = "pbw";
            this.pbw.Size = new System.Drawing.Size(44, 45);
            this.pbw.TabIndex = 28;
            this.pbw.TabStop = false;
            this.pbw.Click += new System.EventHandler(this.pbw_Click);
            // 
            // pbe
            // 
            this.pbe.BackColor = System.Drawing.Color.Transparent;
            this.pbe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbe.Location = new System.Drawing.Point(245, 77);
            this.pbe.Name = "pbe";
            this.pbe.Size = new System.Drawing.Size(44, 45);
            this.pbe.TabIndex = 29;
            this.pbe.TabStop = false;
            this.pbe.Click += new System.EventHandler(this.pbe_Click);
            // 
            // pbr
            // 
            this.pbr.BackColor = System.Drawing.Color.Transparent;
            this.pbr.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbr.Location = new System.Drawing.Point(311, 77);
            this.pbr.Name = "pbr";
            this.pbr.Size = new System.Drawing.Size(44, 45);
            this.pbr.TabIndex = 30;
            this.pbr.TabStop = false;
            this.pbr.Click += new System.EventHandler(this.pbr_Click);
            // 
            // pbt
            // 
            this.pbt.BackColor = System.Drawing.Color.Transparent;
            this.pbt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbt.Location = new System.Drawing.Point(374, 77);
            this.pbt.Name = "pbt";
            this.pbt.Size = new System.Drawing.Size(44, 45);
            this.pbt.TabIndex = 31;
            this.pbt.TabStop = false;
            this.pbt.Click += new System.EventHandler(this.pbt_Click);
            // 
            // pby
            // 
            this.pby.BackColor = System.Drawing.Color.Transparent;
            this.pby.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pby.Location = new System.Drawing.Point(438, 77);
            this.pby.Name = "pby";
            this.pby.Size = new System.Drawing.Size(44, 45);
            this.pby.TabIndex = 32;
            this.pby.TabStop = false;
            this.pby.Click += new System.EventHandler(this.pby_Click);
            // 
            // pbu
            // 
            this.pbu.BackColor = System.Drawing.Color.Transparent;
            this.pbu.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbu.Location = new System.Drawing.Point(502, 77);
            this.pbu.Name = "pbu";
            this.pbu.Size = new System.Drawing.Size(44, 45);
            this.pbu.TabIndex = 33;
            this.pbu.TabStop = false;
            this.pbu.Click += new System.EventHandler(this.pbu_Click);
            // 
            // pbi
            // 
            this.pbi.BackColor = System.Drawing.Color.Transparent;
            this.pbi.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbi.Location = new System.Drawing.Point(566, 77);
            this.pbi.Name = "pbi";
            this.pbi.Size = new System.Drawing.Size(44, 45);
            this.pbi.TabIndex = 34;
            this.pbi.TabStop = false;
            this.pbi.Click += new System.EventHandler(this.pbi_Click);
            // 
            // pbo
            // 
            this.pbo.BackColor = System.Drawing.Color.Transparent;
            this.pbo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbo.Location = new System.Drawing.Point(630, 77);
            this.pbo.Name = "pbo";
            this.pbo.Size = new System.Drawing.Size(44, 45);
            this.pbo.TabIndex = 35;
            this.pbo.TabStop = false;
            this.pbo.Click += new System.EventHandler(this.pbo_Click);
            // 
            // pbp
            // 
            this.pbp.BackColor = System.Drawing.Color.Transparent;
            this.pbp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbp.Location = new System.Drawing.Point(694, 77);
            this.pbp.Name = "pbp";
            this.pbp.Size = new System.Drawing.Size(44, 45);
            this.pbp.TabIndex = 36;
            this.pbp.TabStop = false;
            this.pbp.Click += new System.EventHandler(this.pbp_Click);
            // 
            // pba
            // 
            this.pba.BackColor = System.Drawing.Color.Transparent;
            this.pba.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pba.Location = new System.Drawing.Point(133, 135);
            this.pba.Name = "pba";
            this.pba.Size = new System.Drawing.Size(44, 45);
            this.pba.TabIndex = 37;
            this.pba.TabStop = false;
            this.pba.Click += new System.EventHandler(this.pba_Click);
            // 
            // pbs
            // 
            this.pbs.BackColor = System.Drawing.Color.Transparent;
            this.pbs.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbs.Location = new System.Drawing.Point(196, 135);
            this.pbs.Name = "pbs";
            this.pbs.Size = new System.Drawing.Size(44, 45);
            this.pbs.TabIndex = 38;
            this.pbs.TabStop = false;
            this.pbs.Click += new System.EventHandler(this.pbs_Click);
            // 
            // pbd
            // 
            this.pbd.BackColor = System.Drawing.Color.Transparent;
            this.pbd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbd.Location = new System.Drawing.Point(258, 135);
            this.pbd.Name = "pbd";
            this.pbd.Size = new System.Drawing.Size(44, 45);
            this.pbd.TabIndex = 39;
            this.pbd.TabStop = false;
            this.pbd.Click += new System.EventHandler(this.pbd_Click);
            // 
            // pbf
            // 
            this.pbf.BackColor = System.Drawing.Color.Transparent;
            this.pbf.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbf.Location = new System.Drawing.Point(325, 135);
            this.pbf.Name = "pbf";
            this.pbf.Size = new System.Drawing.Size(44, 45);
            this.pbf.TabIndex = 40;
            this.pbf.TabStop = false;
            this.pbf.Click += new System.EventHandler(this.pbf_Click);
            // 
            // pbg
            // 
            this.pbg.BackColor = System.Drawing.Color.Transparent;
            this.pbg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbg.Location = new System.Drawing.Point(387, 135);
            this.pbg.Name = "pbg";
            this.pbg.Size = new System.Drawing.Size(48, 45);
            this.pbg.TabIndex = 41;
            this.pbg.TabStop = false;
            this.pbg.Click += new System.EventHandler(this.pbg_Click);
            // 
            // pbh
            // 
            this.pbh.BackColor = System.Drawing.Color.Transparent;
            this.pbh.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbh.Location = new System.Drawing.Point(451, 135);
            this.pbh.Name = "pbh";
            this.pbh.Size = new System.Drawing.Size(48, 45);
            this.pbh.TabIndex = 42;
            this.pbh.TabStop = false;
            this.pbh.Click += new System.EventHandler(this.pbh_Click);
            // 
            // pbj
            // 
            this.pbj.BackColor = System.Drawing.Color.Transparent;
            this.pbj.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbj.Location = new System.Drawing.Point(515, 135);
            this.pbj.Name = "pbj";
            this.pbj.Size = new System.Drawing.Size(49, 45);
            this.pbj.TabIndex = 43;
            this.pbj.TabStop = false;
            this.pbj.Click += new System.EventHandler(this.pbj_Click);
            // 
            // pbk
            // 
            this.pbk.BackColor = System.Drawing.Color.Transparent;
            this.pbk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbk.Location = new System.Drawing.Point(580, 135);
            this.pbk.Name = "pbk";
            this.pbk.Size = new System.Drawing.Size(46, 45);
            this.pbk.TabIndex = 44;
            this.pbk.TabStop = false;
            this.pbk.Click += new System.EventHandler(this.pbk_Click);
            // 
            // pbl
            // 
            this.pbl.BackColor = System.Drawing.Color.Transparent;
            this.pbl.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbl.Location = new System.Drawing.Point(643, 135);
            this.pbl.Name = "pbl";
            this.pbl.Size = new System.Drawing.Size(48, 45);
            this.pbl.TabIndex = 45;
            this.pbl.TabStop = false;
            this.pbl.Click += new System.EventHandler(this.pbl_Click);
            // 
            // pbz
            // 
            this.pbz.BackColor = System.Drawing.Color.Transparent;
            this.pbz.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbz.Location = new System.Drawing.Point(166, 190);
            this.pbz.Name = "pbz";
            this.pbz.Size = new System.Drawing.Size(44, 45);
            this.pbz.TabIndex = 46;
            this.pbz.TabStop = false;
            this.pbz.Click += new System.EventHandler(this.pbz_Click);
            // 
            // pbx
            // 
            this.pbx.BackColor = System.Drawing.Color.Transparent;
            this.pbx.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbx.Location = new System.Drawing.Point(230, 190);
            this.pbx.Name = "pbx";
            this.pbx.Size = new System.Drawing.Size(44, 45);
            this.pbx.TabIndex = 47;
            this.pbx.TabStop = false;
            this.pbx.Click += new System.EventHandler(this.pbx_Click);
            // 
            // pbc
            // 
            this.pbc.BackColor = System.Drawing.Color.Transparent;
            this.pbc.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbc.Location = new System.Drawing.Point(294, 190);
            this.pbc.Name = "pbc";
            this.pbc.Size = new System.Drawing.Size(44, 45);
            this.pbc.TabIndex = 48;
            this.pbc.TabStop = false;
            this.pbc.Click += new System.EventHandler(this.pbc_Click);
            // 
            // pbv
            // 
            this.pbv.BackColor = System.Drawing.Color.Transparent;
            this.pbv.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbv.Location = new System.Drawing.Point(358, 190);
            this.pbv.Name = "pbv";
            this.pbv.Size = new System.Drawing.Size(44, 45);
            this.pbv.TabIndex = 49;
            this.pbv.TabStop = false;
            this.pbv.Click += new System.EventHandler(this.pbv_Click);
            // 
            // pbb
            // 
            this.pbb.BackColor = System.Drawing.Color.Transparent;
            this.pbb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbb.Location = new System.Drawing.Point(422, 190);
            this.pbb.Name = "pbb";
            this.pbb.Size = new System.Drawing.Size(44, 45);
            this.pbb.TabIndex = 50;
            this.pbb.TabStop = false;
            this.pbb.Click += new System.EventHandler(this.pbb_Click);
            // 
            // pbn
            // 
            this.pbn.BackColor = System.Drawing.Color.Transparent;
            this.pbn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbn.Location = new System.Drawing.Point(487, 190);
            this.pbn.Name = "pbn";
            this.pbn.Size = new System.Drawing.Size(44, 45);
            this.pbn.TabIndex = 51;
            this.pbn.TabStop = false;
            this.pbn.Click += new System.EventHandler(this.pbn_Click);
            // 
            // pbm
            // 
            this.pbm.BackColor = System.Drawing.Color.Transparent;
            this.pbm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbm.Location = new System.Drawing.Point(550, 190);
            this.pbm.Name = "pbm";
            this.pbm.Size = new System.Drawing.Size(44, 45);
            this.pbm.TabIndex = 52;
            this.pbm.TabStop = false;
            this.pbm.Click += new System.EventHandler(this.pbm_Click);
            // 
            // pb1
            // 
            this.pb1.BackColor = System.Drawing.Color.Transparent;
            this.pb1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb1.Location = new System.Drawing.Point(84, 18);
            this.pb1.Name = "pb1";
            this.pb1.Size = new System.Drawing.Size(47, 45);
            this.pb1.TabIndex = 53;
            this.pb1.TabStop = false;
            this.pb1.Click += new System.EventHandler(this.pb1_Click);
            // 
            // pb2
            // 
            this.pb2.BackColor = System.Drawing.Color.Transparent;
            this.pb2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb2.Location = new System.Drawing.Point(148, 18);
            this.pb2.Name = "pb2";
            this.pb2.Size = new System.Drawing.Size(47, 45);
            this.pb2.TabIndex = 54;
            this.pb2.TabStop = false;
            this.pb2.Click += new System.EventHandler(this.pb2_Click);
            // 
            // pb3
            // 
            this.pb3.BackColor = System.Drawing.Color.Transparent;
            this.pb3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb3.Location = new System.Drawing.Point(211, 18);
            this.pb3.Name = "pb3";
            this.pb3.Size = new System.Drawing.Size(47, 45);
            this.pb3.TabIndex = 55;
            this.pb3.TabStop = false;
            this.pb3.Click += new System.EventHandler(this.pb3_Click);
            // 
            // pb4
            // 
            this.pb4.BackColor = System.Drawing.Color.Transparent;
            this.pb4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb4.Location = new System.Drawing.Point(276, 18);
            this.pb4.Name = "pb4";
            this.pb4.Size = new System.Drawing.Size(47, 45);
            this.pb4.TabIndex = 56;
            this.pb4.TabStop = false;
            this.pb4.Click += new System.EventHandler(this.pb4_Click);
            // 
            // pb5
            // 
            this.pb5.BackColor = System.Drawing.Color.Transparent;
            this.pb5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb5.Location = new System.Drawing.Point(341, 18);
            this.pb5.Name = "pb5";
            this.pb5.Size = new System.Drawing.Size(47, 45);
            this.pb5.TabIndex = 57;
            this.pb5.TabStop = false;
            this.pb5.Click += new System.EventHandler(this.pb5_Click);
            // 
            // pb6
            // 
            this.pb6.BackColor = System.Drawing.Color.Transparent;
            this.pb6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb6.Location = new System.Drawing.Point(403, 18);
            this.pb6.Name = "pb6";
            this.pb6.Size = new System.Drawing.Size(47, 45);
            this.pb6.TabIndex = 58;
            this.pb6.TabStop = false;
            this.pb6.Click += new System.EventHandler(this.pb6_Click);
            // 
            // pb7
            // 
            this.pb7.BackColor = System.Drawing.Color.Transparent;
            this.pb7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb7.Location = new System.Drawing.Point(469, 18);
            this.pb7.Name = "pb7";
            this.pb7.Size = new System.Drawing.Size(47, 45);
            this.pb7.TabIndex = 59;
            this.pb7.TabStop = false;
            this.pb7.Click += new System.EventHandler(this.pb7_Click);
            // 
            // pb8
            // 
            this.pb8.BackColor = System.Drawing.Color.Transparent;
            this.pb8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb8.Location = new System.Drawing.Point(533, 18);
            this.pb8.Name = "pb8";
            this.pb8.Size = new System.Drawing.Size(47, 45);
            this.pb8.TabIndex = 60;
            this.pb8.TabStop = false;
            this.pb8.Click += new System.EventHandler(this.pb8_Click);
            // 
            // pb9
            // 
            this.pb9.BackColor = System.Drawing.Color.Transparent;
            this.pb9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb9.Location = new System.Drawing.Point(596, 18);
            this.pb9.Name = "pb9";
            this.pb9.Size = new System.Drawing.Size(47, 45);
            this.pb9.TabIndex = 61;
            this.pb9.TabStop = false;
            this.pb9.Click += new System.EventHandler(this.pb9_Click);
            // 
            // pb0
            // 
            this.pb0.BackColor = System.Drawing.Color.Transparent;
            this.pb0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb0.Location = new System.Drawing.Point(660, 18);
            this.pb0.Name = "pb0";
            this.pb0.Size = new System.Drawing.Size(47, 45);
            this.pb0.TabIndex = 62;
            this.pb0.TabStop = false;
            this.pb0.Click += new System.EventHandler(this.pb0_Click);
            // 
            // pbminus
            // 
            this.pbminus.BackColor = System.Drawing.Color.Transparent;
            this.pbminus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbminus.Location = new System.Drawing.Point(725, 18);
            this.pbminus.Name = "pbminus";
            this.pbminus.Size = new System.Drawing.Size(47, 45);
            this.pbminus.TabIndex = 63;
            this.pbminus.TabStop = false;
            this.pbminus.Click += new System.EventHandler(this.pbminus_Click);
            // 
            // pbequal
            // 
            this.pbequal.BackColor = System.Drawing.Color.Transparent;
            this.pbequal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbequal.Location = new System.Drawing.Point(790, 18);
            this.pbequal.Name = "pbequal";
            this.pbequal.Size = new System.Drawing.Size(47, 45);
            this.pbequal.TabIndex = 64;
            this.pbequal.TabStop = false;
            this.pbequal.Click += new System.EventHandler(this.pbequal_Click);
            // 
            // pbhookright
            // 
            this.pbhookright.BackColor = System.Drawing.Color.Transparent;
            this.pbhookright.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbhookright.Location = new System.Drawing.Point(821, 77);
            this.pbhookright.Name = "pbhookright";
            this.pbhookright.Size = new System.Drawing.Size(47, 45);
            this.pbhookright.TabIndex = 65;
            this.pbhookright.TabStop = false;
            this.pbhookright.Click += new System.EventHandler(this.pbhookright_Click);
            // 
            // phookleft
            // 
            this.phookleft.BackColor = System.Drawing.Color.Transparent;
            this.phookleft.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.phookleft.Location = new System.Drawing.Point(754, 77);
            this.phookleft.Name = "phookleft";
            this.phookleft.Size = new System.Drawing.Size(47, 45);
            this.phookleft.TabIndex = 66;
            this.phookleft.TabStop = false;
            this.phookleft.Click += new System.EventHandler(this.phookleft_Click);
            // 
            // pbbackslash
            // 
            this.pbbackslash.BackColor = System.Drawing.Color.Transparent;
            this.pbbackslash.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbbackslash.Location = new System.Drawing.Point(884, 77);
            this.pbbackslash.Name = "pbbackslash";
            this.pbbackslash.Size = new System.Drawing.Size(79, 45);
            this.pbbackslash.TabIndex = 67;
            this.pbbackslash.TabStop = false;
            this.pbbackslash.Click += new System.EventHandler(this.pbbackslash_Click);
            // 
            // pbdotcomma
            // 
            this.pbdotcomma.BackColor = System.Drawing.Color.Transparent;
            this.pbdotcomma.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbdotcomma.Location = new System.Drawing.Point(707, 135);
            this.pbdotcomma.Name = "pbdotcomma";
            this.pbdotcomma.Size = new System.Drawing.Size(47, 45);
            this.pbdotcomma.TabIndex = 68;
            this.pbdotcomma.TabStop = false;
            this.pbdotcomma.Click += new System.EventHandler(this.pbdotcomma_Click);
            // 
            // pbquote
            // 
            this.pbquote.BackColor = System.Drawing.Color.Transparent;
            this.pbquote.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbquote.Location = new System.Drawing.Point(770, 135);
            this.pbquote.Name = "pbquote";
            this.pbquote.Size = new System.Drawing.Size(47, 45);
            this.pbquote.TabIndex = 69;
            this.pbquote.TabStop = false;
            this.pbquote.Click += new System.EventHandler(this.pbquote_Click);
            // 
            // pbcomma
            // 
            this.pbcomma.BackColor = System.Drawing.Color.Transparent;
            this.pbcomma.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbcomma.Location = new System.Drawing.Point(613, 190);
            this.pbcomma.Name = "pbcomma";
            this.pbcomma.Size = new System.Drawing.Size(47, 45);
            this.pbcomma.TabIndex = 70;
            this.pbcomma.TabStop = false;
            this.pbcomma.Click += new System.EventHandler(this.pbcomma_Click);
            // 
            // pbdot
            // 
            this.pbdot.BackColor = System.Drawing.Color.Transparent;
            this.pbdot.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbdot.Location = new System.Drawing.Point(677, 190);
            this.pbdot.Name = "pbdot";
            this.pbdot.Size = new System.Drawing.Size(47, 45);
            this.pbdot.TabIndex = 71;
            this.pbdot.TabStop = false;
            this.pbdot.Click += new System.EventHandler(this.pbdot_Click);
            // 
            // pbslash
            // 
            this.pbslash.BackColor = System.Drawing.Color.Transparent;
            this.pbslash.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbslash.Location = new System.Drawing.Point(741, 190);
            this.pbslash.Name = "pbslash";
            this.pbslash.Size = new System.Drawing.Size(47, 45);
            this.pbslash.TabIndex = 72;
            this.pbslash.TabStop = false;
            this.pbslash.Click += new System.EventHandler(this.pbslash_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::VirtualKeyboard.Properties.Resources.vk1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1047, 311);
            this.Controls.Add(this.pbslash);
            this.Controls.Add(this.pbdot);
            this.Controls.Add(this.pbcomma);
            this.Controls.Add(this.pbquote);
            this.Controls.Add(this.pbdotcomma);
            this.Controls.Add(this.pbbackslash);
            this.Controls.Add(this.phookleft);
            this.Controls.Add(this.pbhookright);
            this.Controls.Add(this.pbequal);
            this.Controls.Add(this.pbminus);
            this.Controls.Add(this.pb0);
            this.Controls.Add(this.pb9);
            this.Controls.Add(this.pb8);
            this.Controls.Add(this.pb7);
            this.Controls.Add(this.pb6);
            this.Controls.Add(this.pb5);
            this.Controls.Add(this.pb4);
            this.Controls.Add(this.pb3);
            this.Controls.Add(this.pb2);
            this.Controls.Add(this.pb1);
            this.Controls.Add(this.pbm);
            this.Controls.Add(this.pbn);
            this.Controls.Add(this.pbb);
            this.Controls.Add(this.pbv);
            this.Controls.Add(this.pbc);
            this.Controls.Add(this.pbx);
            this.Controls.Add(this.pbz);
            this.Controls.Add(this.pbl);
            this.Controls.Add(this.pbk);
            this.Controls.Add(this.pbj);
            this.Controls.Add(this.pbh);
            this.Controls.Add(this.pbg);
            this.Controls.Add(this.pbf);
            this.Controls.Add(this.pbd);
            this.Controls.Add(this.pbs);
            this.Controls.Add(this.pba);
            this.Controls.Add(this.pbp);
            this.Controls.Add(this.pbo);
            this.Controls.Add(this.pbi);
            this.Controls.Add(this.pbu);
            this.Controls.Add(this.pby);
            this.Controls.Add(this.pbt);
            this.Controls.Add(this.pbr);
            this.Controls.Add(this.pbe);
            this.Controls.Add(this.pbw);
            this.Controls.Add(this.pbbackspace);
            this.Controls.Add(this.pbascend);
            this.Controls.Add(this.pbdelete);
            this.Controls.Add(this.pbpageup);
            this.Controls.Add(this.pbpagedown);
            this.Controls.Add(this.pbend);
            this.Controls.Add(this.pbrightshift);
            this.Controls.Add(this.pbup);
            this.Controls.Add(this.pbdown);
            this.Controls.Add(this.pbright);
            this.Controls.Add(this.pbleft);
            this.Controls.Add(this.pbfn);
            this.Controls.Add(this.pbrightmenu);
            this.Controls.Add(this.pbspace);
            this.Controls.Add(this.pbleftmenu);
            this.Controls.Add(this.pbwindows);
            this.Controls.Add(this.pbleftshift);
            this.Controls.Add(this.pbcapslock);
            this.Controls.Add(this.pbtab);
            this.Controls.Add(this.pbq);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pbleftcontrol);
            this.Controls.Add(this.pbescape);
            this.Controls.Add(this.pictureBox1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "VirtualKeyboard";
            this.TopMost = true;
            this.Deactivate += new System.EventHandler(this.Form1_Deactivate);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbescape)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbleftcontrol)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbq)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbtab)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcapslock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbleftshift)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbwindows)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbleftmenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbspace)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbrightmenu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbfn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbleft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbright)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbdown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbrightshift)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbend)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbpagedown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbpageup)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbdelete)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbascend)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbbackspace)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbw)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pby)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pba)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbg)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbh)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbj)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbl)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbz)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbm)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbminus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbequal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbhookright)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.phookleft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbbackslash)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbdotcomma)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbquote)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcomma)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbdot)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbslash)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pbescape;
        private System.Windows.Forms.PictureBox pbleftcontrol;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pbq;
        private System.Windows.Forms.PictureBox pbtab;
        private System.Windows.Forms.PictureBox pbcapslock;
        private System.Windows.Forms.PictureBox pbleftshift;
        private System.Windows.Forms.PictureBox pbwindows;
        private System.Windows.Forms.PictureBox pbleftmenu;
        private System.Windows.Forms.PictureBox pbspace;
        private System.Windows.Forms.PictureBox pbrightmenu;
        private System.Windows.Forms.PictureBox pbfn;
        private System.Windows.Forms.PictureBox pbleft;
        private System.Windows.Forms.PictureBox pbright;
        private System.Windows.Forms.PictureBox pbdown;
        private System.Windows.Forms.PictureBox pbup;
        private System.Windows.Forms.PictureBox pbrightshift;
        private System.Windows.Forms.PictureBox pbend;
        private System.Windows.Forms.PictureBox pbpagedown;
        private System.Windows.Forms.PictureBox pbpageup;
        private System.Windows.Forms.PictureBox pbdelete;
        private System.Windows.Forms.PictureBox pbascend;
        private System.Windows.Forms.PictureBox pbbackspace;
        private System.Windows.Forms.PictureBox pbw;
        private System.Windows.Forms.PictureBox pbe;
        private System.Windows.Forms.PictureBox pbr;
        private System.Windows.Forms.PictureBox pbt;
        private System.Windows.Forms.PictureBox pby;
        private System.Windows.Forms.PictureBox pbu;
        private System.Windows.Forms.PictureBox pbi;
        private System.Windows.Forms.PictureBox pbo;
        private System.Windows.Forms.PictureBox pbp;
        private System.Windows.Forms.PictureBox pba;
        private System.Windows.Forms.PictureBox pbs;
        private System.Windows.Forms.PictureBox pbd;
        private System.Windows.Forms.PictureBox pbf;
        private System.Windows.Forms.PictureBox pbg;
        private System.Windows.Forms.PictureBox pbh;
        private System.Windows.Forms.PictureBox pbj;
        private System.Windows.Forms.PictureBox pbk;
        private System.Windows.Forms.PictureBox pbl;
        private System.Windows.Forms.PictureBox pbz;
        private System.Windows.Forms.PictureBox pbx;
        private System.Windows.Forms.PictureBox pbc;
        private System.Windows.Forms.PictureBox pbv;
        private System.Windows.Forms.PictureBox pbb;
        private System.Windows.Forms.PictureBox pbn;
        private System.Windows.Forms.PictureBox pbm;
        private System.Windows.Forms.PictureBox pb1;
        private System.Windows.Forms.PictureBox pb2;
        private System.Windows.Forms.PictureBox pb3;
        private System.Windows.Forms.PictureBox pb4;
        private System.Windows.Forms.PictureBox pb5;
        private System.Windows.Forms.PictureBox pb6;
        private System.Windows.Forms.PictureBox pb7;
        private System.Windows.Forms.PictureBox pb8;
        private System.Windows.Forms.PictureBox pb9;
        private System.Windows.Forms.PictureBox pb0;
        private System.Windows.Forms.PictureBox pbminus;
        private System.Windows.Forms.PictureBox pbequal;
        private System.Windows.Forms.PictureBox pbhookright;
        private System.Windows.Forms.PictureBox phookleft;
        private System.Windows.Forms.PictureBox pbbackslash;
        private System.Windows.Forms.PictureBox pbdotcomma;
        private System.Windows.Forms.PictureBox pbquote;
        private System.Windows.Forms.PictureBox pbcomma;
        private System.Windows.Forms.PictureBox pbdot;
        private System.Windows.Forms.PictureBox pbslash;
    }
}

