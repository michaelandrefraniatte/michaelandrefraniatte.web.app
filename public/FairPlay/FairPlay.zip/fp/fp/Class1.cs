﻿using System;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace fp
{
    public class Class1
    {
        [DllImport("kernel32.dll")]
        private unsafe static extern IntPtr OpenProcess(UInt32 dwDesiredAccess, Int32 bInheritHandle, UInt32 dwProcessId);
        [DllImport("kernel32.dll")]
        private unsafe static extern Int32 ReadProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, [In, Out] byte[] buffer, UInt64 size, out IntPtr lpNumberOfBytesRead);
        [DllImport("kernel32.dll")]
        private unsafe static extern Int32 WriteProcessMemory(IntPtr hProcess, IntPtr lpBaseAddress, [In, Out] byte[] buffer, UInt64 size, out IntPtr lpNumberOfBytesRead);
        [DllImport("kernel32.dll")]
        private unsafe static extern IntPtr VirtualAllocEx(IntPtr hProcess, IntPtr lpBaseAddress, IntPtr size, uint flAllocationType, uint lpflOldProtect);
        [DllImport("kernel32.dll")]
        private unsafe static extern bool VirtualProtectEx(IntPtr hProcess, IntPtr lpAddress, IntPtr size, uint flNewProtect, out uint lpflOldProtect);
        [DllImport("kernel32.dll")]
        private unsafe static extern int VirtualQueryEx(IntPtr hProcess, IntPtr lpAddress, out uint basicInformation, IntPtr dwSize);
        [DllImport("kernel32.dll", SetLastError = true, ExactSpelling = true)]
        private unsafe static extern bool VirtualFreeEx(IntPtr hProcess, IntPtr lpAddress, int dwSize, uint dwFreeType);
        [DllImport("kernel32.dll")]
        private unsafe static extern bool VirtualLock(IntPtr lpAddress, IntPtr dwSize);
        [DllImport("kernel32.dll")]
        private unsafe static extern bool VirtualUnlock(IntPtr lpAddress, IntPtr dwSize);
        [DllImport("kernel32.dll")]
        public static extern bool SetProcessWorkingSetSizeEx(IntPtr hProcess, int dwMinimumWorkingSetSize, int dwMaximumWorkingSetSize, int Flags);
        [DllImport("winmm.dll", EntryPoint = "timeBeginPeriod")]
        public static extern uint TimeBeginPeriod(uint ms);
        [DllImport("winmm.dll", EntryPoint = "timeEndPeriod")]
        public static extern uint TimeEndPeriod(uint ms);
        [DllImport("ntdll.dll", EntryPoint = "NtSetTimerResolution")]
        public static extern void NtSetTimerResolution(uint DesiredResolution, bool SetResolution, ref uint CurrentResolution);
        private static uint dwdesiredaccess = PROCESS_ALL_ACCESS;
        private static IntPtr pP;
        public static uint oP, lpOldProtect;
        public static Int64 bA;
        public static Int64 lA;
        public static IntPtr A, Ai, sizei;
        public static UInt64 sizeu;
        private static int effic; // (8587934592 - 140000000) / 2147483647 = 4;
        public static int size;
        public static byte[] fbytes;
        public static int processid = 0;
        private static IntPtr lpNumberOfBytesRead;
        public static uint CurrentResolution = 0;
        private static Random rnd = new Random();
        private static List<byte> list;
        public unsafe static string setIt(int processid)
        {
            try
            {
                TimeBeginPeriod(1);
                NtSetTimerResolution(1, true, ref CurrentResolution);
                pP = OpenProcess(dwdesiredaccess, 1, (uint)processid);
                bA = 140000000;
                lA = 8587934592;
            }
            catch (Exception e)
            {
                return e.ToString();
            }
            return "";
        }
        public unsafe static string useIt()
        {
            try
            {
                list = fbytes.ToList();
                Thread.Sleep(10);
                list.RemoveAt(rnd.Next(0, list.Count));
                Thread.Sleep(10);
                list.Add((byte)rnd.Next(0, 256));
                Thread.Sleep(10);
                fbytes = list.ToArray();
                Thread.Sleep(10);
                for (int i = (int)bA; i < (int)lA; i = i + size)
                {
                    Ai = (IntPtr)i;
                    A = VirtualAllocEx(pP, Ai, sizei, MEM_RESERVE | MEM_COMMIT, PAGE_READONLY | PAGE_GUARD);
                    VirtualQueryEx(pP, A, out oP, sizei);
                    VirtualProtectEx(pP, A, sizei, PAGE_GUARD | oP, out lpOldProtect);
                    WriteProcessMemory(pP, A, fbytes, sizeu, out lpNumberOfBytesRead);
                    VirtualQueryEx(pP, Ai, out oP, sizei);
                    VirtualProtectEx(pP, Ai, sizei, PAGE_GUARD | oP, out lpOldProtect);
                    WriteProcessMemory(pP, Ai, fbytes, sizeu, out lpNumberOfBytesRead);
                }
            }
            catch (Exception e)
            {
                return e.ToString();
            }
            return "";
        }
        public unsafe static string putIt()
        {
            try
            {
                effic = rnd.Next(200, 300);
                size = 2147483647 / effic;
                fbytes = new byte[size];
                sizei = (IntPtr)size;
                sizeu = (UInt64)size;
                for (int j = 0; j < size; j++)
                {
                    fbytes[j] = (byte)rnd.Next(0, 256);
                }
                return "filled";
            }
            catch (Exception e)
            {
                return e.ToString();
            }
        }
        const uint DELETE = 0x00010000;
        const uint READ_CONTROL = 0x00020000;
        const uint WRITE_DAC = 0x00040000;
        const uint WRITE_OWNER = 0x00080000;
        const uint SYNCHRONIZE = 0x00100000;
        const uint END = 0xFFF;
        const uint PROCESS_ALL_ACCESS = DELETE | READ_CONTROL | WRITE_DAC | WRITE_OWNER | SYNCHRONIZE | END;
        const uint PROCESS_VM_OPERATION = 0x0008;
        const uint PROCESS_VM_READ = 0x0010;
        const uint PROCESS_VM_WRITE = 0x0020;
        const uint PROCESS_CREATE_THREAD = 0x0002;
        const uint PROCESS_QUERY_INFORMATION = 0x0400;
        const uint PAGE_READWRITE = 0x04;
        const uint MEM_COMMIT = 0x00001000;
        const uint PAGE_EXECUTE_READWRITE = 0x40;
        const uint MEM_DECOMMIT = 0x00004000;
        const uint MEM_RESERVE = 0x00002000;
        const uint PAGE_READONLY = 0x02;
        const uint PAGE_GUARD = 0x100;
    }
}