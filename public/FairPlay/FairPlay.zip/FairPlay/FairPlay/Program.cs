﻿using System;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Security.Principal;
namespace FairPlay
{
    class Program
    {
        [DllImport("winmm.dll", EntryPoint = "timeBeginPeriod")]
        public static extern uint TimeBeginPeriod(uint ms);
        [DllImport("winmm.dll", EntryPoint = "timeEndPeriod")]
        public static extern uint TimeEndPeriod(uint ms);
        [DllImport("ntdll.dll", EntryPoint = "NtSetTimerResolution")]
        public static extern void NtSetTimerResolution(uint DesiredResolution, bool SetResolution, ref uint CurrentResolution);
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool SetConsoleCtrlHandler(ConsoleEventDelegate callback, bool add);
        [DllImport("Kernel32.dll", CallingConvention = CallingConvention.StdCall, SetLastError = true)]
        private static extern IntPtr GetConsoleWindow();
        [DllImport("User32.dll", CallingConvention = CallingConvention.StdCall, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool ShowWindow([In] IntPtr hWnd, [In] Int32 nCmdShow);
        const Int32 SW_MINIMIZE = 6;
        static ConsoleEventDelegate handler;
        private delegate bool ConsoleEventDelegate(int eventType);
        public static ThreadStart threadstart;
        public static Thread thread;
        public static uint CurrentResolution = 0;
        public static int processid = 0;
        private static List<string> procnames = new List<string>();
        private static string datasetit, datauseit, dataputit;
        private static bool closed = false;
        private static Action action;
        private static Task task;
        private static PerformanceCounter counter;
        static void Main()
        {
            MinimizeConsoleWindow();
            handler = new ConsoleEventDelegate(ConsoleEventCallback);
            SetConsoleCtrlHandler(handler, true);
            bool runelevated = false;
            bool oneinstanceonly = true;
            try
            {
                TimeBeginPeriod(1);
                NtSetTimerResolution(1, true, ref CurrentResolution);
                if (oneinstanceonly)
                {
                    if (AlreadyRunning())
                    {
                        return;
                    }
                }
                if (runelevated)
                {
                    if (!hasAdminRights())
                    {
                        RunElevated();
                        return;
                    }
                }
            }
            catch
            {
                return;
            }
            Task.Run(() => StartFlood());
            System.Threading.Thread.Sleep(60000);
            counter = new PerformanceCounter("Process", "% Processor Time", Process.GetCurrentProcess().ProcessName, true);
            Task.Run(() => StartTick());
            Console.ReadLine();
        }
        public static bool hasAdminRights()
        {
            WindowsPrincipal principal = new WindowsPrincipal(WindowsIdentity.GetCurrent());
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }
        public static void RunElevated()
        {
            try
            {
                ProcessStartInfo processInfo = new ProcessStartInfo();
                processInfo.Verb = "runas";
                processInfo.FileName = Application.ExecutablePath;
                Process.Start(processInfo);
            }
            catch { }
        }
        private static bool AlreadyRunning()
        {
            String thisprocessname = Process.GetCurrentProcess().ProcessName;
            Process[] processes = Process.GetProcessesByName(thisprocessname);
            if (processes.Length > 1)
                return true;
            else
                return false;
        }
        public static void StartFlood()
        {
            Put();
            try
            {
                using (System.IO.StreamReader file = new System.IO.StreamReader("fp.txt"))
                {
                    while (true)
                    {
                        string procName = file.ReadLine();
                        if (procName == "")
                        {
                            file.Close();
                            break;
                        }
                        else
                            procnames.Add(procName);
                    }
                }
                while (processid == 0)
                {
                    foreach (Process p in Process.GetProcesses())
                    {
                        string match = procnames.FirstOrDefault(stringToCheck => stringToCheck == p.ProcessName);
                        if (match != null)
                        {
                            processid = p.Id;
                            break;
                        }
                        Thread.Sleep(1);
                    }
                    Thread.Sleep(1);
                }
                datasetit = fp.Class1.setIt(processid);
                if (datasetit != "")
                {
                    Console.WriteLine(datasetit);
                }
                Console.WriteLine("executed");
                task = Task.Run(action = () => Flood());
            }
            catch (Exception e) 
            {
                Console.WriteLine(e.ToString());
            }
        }
        private static void Flood()
        {
            while (!closed)
            {
                try
                {
                    datauseit = fp.Class1.useIt();
                    if (datauseit != "")
                    {
                        Console.WriteLine(datauseit);
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.ToString());
                }
                Thread.Sleep(1);
            }
        }
        private static void Put()
        {
            try
            {
                dataputit = fp.Class1.putIt();
                if (dataputit != "")
                {
                    Console.WriteLine(dataputit);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }
        private static void StartTick()
        {
            while (true)
            {
                try
                {
                    if (counter.NextValue() / Environment.ProcessorCount <= 0.50000)
                    {
                        closed = true;
                        System.Threading.Thread.Sleep(1000);
                    }
                    if (task.IsCompleted)
                    {
                        closed = false;
                        Task.Run(() => StartFlood());
                    }
                }
                catch { }
                System.Threading.Thread.Sleep(60000);
            }
        }
        private static void MinimizeConsoleWindow()
        {
            IntPtr hWndConsole = GetConsoleWindow();
            ShowWindow(hWndConsole, SW_MINIMIZE);
        }
        static bool ConsoleEventCallback(int eventType)
        {
            if (eventType == 2)
            {
                threadstart = new ThreadStart(FormClose);
                thread = new Thread(threadstart);
                thread.Start();
            }
            return false;
        }
        private static void FormClose()
        {
            closed = true;
            TimeEndPeriod(1);
        }
    }
}