<?php

class index_model {

    //Function to get id
    public function get_id($val) {
        return $val;
    }

}
?>
