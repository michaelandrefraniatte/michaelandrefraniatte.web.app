<html>
    <head>
        <title>id</title>
    </head>
    <body>
        <?php foreach($ids as $id):?>
            <h1><?=$id?></h1>
        <?php endforeach; ?>
    </body>
</html>