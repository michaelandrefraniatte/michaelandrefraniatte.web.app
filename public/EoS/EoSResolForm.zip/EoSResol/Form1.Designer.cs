﻿namespace EoSResol
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.textBox75 = new System.Windows.Forms.TextBox();
            this.textBox76 = new System.Windows.Forms.TextBox();
            this.textBox77 = new System.Windows.Forms.TextBox();
            this.textBox78 = new System.Windows.Forms.TextBox();
            this.textBox79 = new System.Windows.Forms.TextBox();
            this.textBox80 = new System.Windows.Forms.TextBox();
            this.textBox81 = new System.Windows.Forms.TextBox();
            this.textBox82 = new System.Windows.Forms.TextBox();
            this.textBox83 = new System.Windows.Forms.TextBox();
            this.textBox84 = new System.Windows.Forms.TextBox();
            this.textBox85 = new System.Windows.Forms.TextBox();
            this.textBox86 = new System.Windows.Forms.TextBox();
            this.textBox87 = new System.Windows.Forms.TextBox();
            this.textBox88 = new System.Windows.Forms.TextBox();
            this.textBox89 = new System.Windows.Forms.TextBox();
            this.textBox90 = new System.Windows.Forms.TextBox();
            this.textBox91 = new System.Windows.Forms.TextBox();
            this.textBox92 = new System.Windows.Forms.TextBox();
            this.textBox93 = new System.Windows.Forms.TextBox();
            this.textBox94 = new System.Windows.Forms.TextBox();
            this.textBox95 = new System.Windows.Forms.TextBox();
            this.textBox96 = new System.Windows.Forms.TextBox();
            this.textBox97 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox98 = new System.Windows.Forms.TextBox();
            this.textBox99 = new System.Windows.Forms.TextBox();
            this.textBox100 = new System.Windows.Forms.TextBox();
            this.textBox101 = new System.Windows.Forms.TextBox();
            this.textBox102 = new System.Windows.Forms.TextBox();
            this.textBox103 = new System.Windows.Forms.TextBox();
            this.textBox104 = new System.Windows.Forms.TextBox();
            this.textBox105 = new System.Windows.Forms.TextBox();
            this.textBox106 = new System.Windows.Forms.TextBox();
            this.textBox107 = new System.Windows.Forms.TextBox();
            this.textBox108 = new System.Windows.Forms.TextBox();
            this.textBox109 = new System.Windows.Forms.TextBox();
            this.textBox110 = new System.Windows.Forms.TextBox();
            this.textBox111 = new System.Windows.Forms.TextBox();
            this.textBox112 = new System.Windows.Forms.TextBox();
            this.textBox113 = new System.Windows.Forms.TextBox();
            this.textBox114 = new System.Windows.Forms.TextBox();
            this.textBox115 = new System.Windows.Forms.TextBox();
            this.textBox116 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.textBox117 = new System.Windows.Forms.TextBox();
            this.textBox118 = new System.Windows.Forms.TextBox();
            this.textBox119 = new System.Windows.Forms.TextBox();
            this.textBox120 = new System.Windows.Forms.TextBox();
            this.textBox121 = new System.Windows.Forms.TextBox();
            this.textBox122 = new System.Windows.Forms.TextBox();
            this.textBox123 = new System.Windows.Forms.TextBox();
            this.textBox124 = new System.Windows.Forms.TextBox();
            this.textBox125 = new System.Windows.Forms.TextBox();
            this.textBox126 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(297, 183);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "volume";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox1.ForeColor = System.Drawing.Color.Green;
            this.textBox1.Location = new System.Drawing.Point(64, 5);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(61, 20);
            this.textBox1.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(4, 183);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "fill";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.ForeColor = System.Drawing.Color.Green;
            this.textBox2.Location = new System.Drawing.Point(64, 24);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(61, 20);
            this.textBox2.TabIndex = 3;
            // 
            // textBox3
            // 
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox3.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox3.Location = new System.Drawing.Point(124, 5);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(50, 20);
            this.textBox3.TabIndex = 4;
            // 
            // textBox4
            // 
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox4.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox4.Location = new System.Drawing.Point(173, 5);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(70, 20);
            this.textBox4.TabIndex = 5;
            // 
            // textBox5
            // 
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox5.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox5.Location = new System.Drawing.Point(242, 5);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(58, 20);
            this.textBox5.TabIndex = 6;
            // 
            // textBox6
            // 
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox6.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox6.Location = new System.Drawing.Point(299, 5);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(57, 20);
            this.textBox6.TabIndex = 7;
            // 
            // textBox7
            // 
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox7.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox7.Location = new System.Drawing.Point(355, 5);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(60, 20);
            this.textBox7.TabIndex = 8;
            // 
            // textBox8
            // 
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox8.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox8.Location = new System.Drawing.Point(414, 5);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(60, 20);
            this.textBox8.TabIndex = 9;
            // 
            // textBox9
            // 
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox9.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox9.Location = new System.Drawing.Point(473, 5);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(60, 20);
            this.textBox9.TabIndex = 10;
            // 
            // textBox10
            // 
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox10.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox10.Location = new System.Drawing.Point(532, 5);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(60, 20);
            this.textBox10.TabIndex = 11;
            // 
            // textBox11
            // 
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox11.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox11.Location = new System.Drawing.Point(591, 5);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(60, 20);
            this.textBox11.TabIndex = 12;
            // 
            // textBox12
            // 
            this.textBox12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox12.ForeColor = System.Drawing.Color.Maroon;
            this.textBox12.Location = new System.Drawing.Point(64, 43);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(61, 20);
            this.textBox12.TabIndex = 13;
            // 
            // textBox13
            // 
            this.textBox13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox13.ForeColor = System.Drawing.Color.Maroon;
            this.textBox13.Location = new System.Drawing.Point(64, 62);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(61, 20);
            this.textBox13.TabIndex = 14;
            // 
            // textBox14
            // 
            this.textBox14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox14.ForeColor = System.Drawing.Color.Maroon;
            this.textBox14.Location = new System.Drawing.Point(64, 81);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(61, 20);
            this.textBox14.TabIndex = 15;
            // 
            // textBox15
            // 
            this.textBox15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox15.ForeColor = System.Drawing.Color.Maroon;
            this.textBox15.Location = new System.Drawing.Point(64, 100);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(61, 20);
            this.textBox15.TabIndex = 16;
            // 
            // textBox16
            // 
            this.textBox16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox16.ForeColor = System.Drawing.Color.Maroon;
            this.textBox16.Location = new System.Drawing.Point(64, 119);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(61, 20);
            this.textBox16.TabIndex = 17;
            // 
            // textBox17
            // 
            this.textBox17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox17.ForeColor = System.Drawing.Color.Navy;
            this.textBox17.Location = new System.Drawing.Point(124, 24);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(50, 20);
            this.textBox17.TabIndex = 18;
            // 
            // textBox18
            // 
            this.textBox18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox18.ForeColor = System.Drawing.Color.Navy;
            this.textBox18.Location = new System.Drawing.Point(124, 43);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(50, 20);
            this.textBox18.TabIndex = 19;
            // 
            // textBox19
            // 
            this.textBox19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox19.ForeColor = System.Drawing.Color.Navy;
            this.textBox19.Location = new System.Drawing.Point(124, 62);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(50, 20);
            this.textBox19.TabIndex = 20;
            // 
            // textBox20
            // 
            this.textBox20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox20.ForeColor = System.Drawing.Color.Navy;
            this.textBox20.Location = new System.Drawing.Point(124, 81);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(50, 20);
            this.textBox20.TabIndex = 21;
            // 
            // textBox21
            // 
            this.textBox21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox21.ForeColor = System.Drawing.Color.Navy;
            this.textBox21.Location = new System.Drawing.Point(124, 100);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(50, 20);
            this.textBox21.TabIndex = 25;
            // 
            // textBox22
            // 
            this.textBox22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox22.ForeColor = System.Drawing.Color.Navy;
            this.textBox22.Location = new System.Drawing.Point(124, 119);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(50, 20);
            this.textBox22.TabIndex = 24;
            // 
            // textBox23
            // 
            this.textBox23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox23.ForeColor = System.Drawing.Color.Navy;
            this.textBox23.Location = new System.Drawing.Point(124, 138);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(50, 20);
            this.textBox23.TabIndex = 23;
            // 
            // textBox24
            // 
            this.textBox24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox24.ForeColor = System.Drawing.Color.Navy;
            this.textBox24.Location = new System.Drawing.Point(124, 157);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(50, 20);
            this.textBox24.TabIndex = 22;
            // 
            // textBox25
            // 
            this.textBox25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox25.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox25.Location = new System.Drawing.Point(173, 157);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(70, 20);
            this.textBox25.TabIndex = 33;
            // 
            // textBox26
            // 
            this.textBox26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox26.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox26.Location = new System.Drawing.Point(173, 138);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(70, 20);
            this.textBox26.TabIndex = 32;
            // 
            // textBox27
            // 
            this.textBox27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox27.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox27.Location = new System.Drawing.Point(173, 119);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(70, 20);
            this.textBox27.TabIndex = 31;
            // 
            // textBox28
            // 
            this.textBox28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox28.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox28.Location = new System.Drawing.Point(173, 100);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(70, 20);
            this.textBox28.TabIndex = 30;
            // 
            // textBox29
            // 
            this.textBox29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox29.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox29.Location = new System.Drawing.Point(173, 81);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(70, 20);
            this.textBox29.TabIndex = 29;
            // 
            // textBox30
            // 
            this.textBox30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox30.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox30.Location = new System.Drawing.Point(173, 62);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(70, 20);
            this.textBox30.TabIndex = 28;
            // 
            // textBox31
            // 
            this.textBox31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox31.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox31.Location = new System.Drawing.Point(173, 43);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(70, 20);
            this.textBox31.TabIndex = 27;
            // 
            // textBox32
            // 
            this.textBox32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox32.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox32.Location = new System.Drawing.Point(173, 24);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(70, 20);
            this.textBox32.TabIndex = 26;
            // 
            // textBox33
            // 
            this.textBox33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox33.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox33.Location = new System.Drawing.Point(242, 157);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(58, 20);
            this.textBox33.TabIndex = 41;
            // 
            // textBox34
            // 
            this.textBox34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox34.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox34.Location = new System.Drawing.Point(242, 138);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(58, 20);
            this.textBox34.TabIndex = 40;
            // 
            // textBox35
            // 
            this.textBox35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox35.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox35.Location = new System.Drawing.Point(242, 119);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(58, 20);
            this.textBox35.TabIndex = 39;
            // 
            // textBox36
            // 
            this.textBox36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox36.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox36.Location = new System.Drawing.Point(242, 100);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(58, 20);
            this.textBox36.TabIndex = 38;
            // 
            // textBox37
            // 
            this.textBox37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox37.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox37.Location = new System.Drawing.Point(242, 81);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(58, 20);
            this.textBox37.TabIndex = 37;
            // 
            // textBox38
            // 
            this.textBox38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox38.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox38.Location = new System.Drawing.Point(242, 62);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(58, 20);
            this.textBox38.TabIndex = 36;
            // 
            // textBox39
            // 
            this.textBox39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox39.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox39.Location = new System.Drawing.Point(242, 43);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(58, 20);
            this.textBox39.TabIndex = 35;
            // 
            // textBox40
            // 
            this.textBox40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox40.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox40.Location = new System.Drawing.Point(242, 24);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(58, 20);
            this.textBox40.TabIndex = 34;
            // 
            // textBox41
            // 
            this.textBox41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox41.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox41.Location = new System.Drawing.Point(299, 157);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(57, 20);
            this.textBox41.TabIndex = 49;
            // 
            // textBox42
            // 
            this.textBox42.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox42.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox42.Location = new System.Drawing.Point(299, 138);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(57, 20);
            this.textBox42.TabIndex = 48;
            // 
            // textBox43
            // 
            this.textBox43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox43.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox43.Location = new System.Drawing.Point(299, 119);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(57, 20);
            this.textBox43.TabIndex = 47;
            // 
            // textBox44
            // 
            this.textBox44.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox44.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox44.Location = new System.Drawing.Point(299, 100);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(57, 20);
            this.textBox44.TabIndex = 46;
            // 
            // textBox45
            // 
            this.textBox45.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox45.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox45.Location = new System.Drawing.Point(299, 81);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(57, 20);
            this.textBox45.TabIndex = 45;
            // 
            // textBox46
            // 
            this.textBox46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox46.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox46.Location = new System.Drawing.Point(299, 62);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(57, 20);
            this.textBox46.TabIndex = 44;
            // 
            // textBox47
            // 
            this.textBox47.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox47.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox47.Location = new System.Drawing.Point(299, 43);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(57, 20);
            this.textBox47.TabIndex = 43;
            // 
            // textBox48
            // 
            this.textBox48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox48.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox48.Location = new System.Drawing.Point(299, 24);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(57, 20);
            this.textBox48.TabIndex = 42;
            // 
            // textBox49
            // 
            this.textBox49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox49.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox49.Location = new System.Drawing.Point(355, 157);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(60, 20);
            this.textBox49.TabIndex = 57;
            // 
            // textBox50
            // 
            this.textBox50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox50.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox50.Location = new System.Drawing.Point(355, 138);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(60, 20);
            this.textBox50.TabIndex = 56;
            // 
            // textBox51
            // 
            this.textBox51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox51.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox51.Location = new System.Drawing.Point(355, 119);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(60, 20);
            this.textBox51.TabIndex = 55;
            // 
            // textBox52
            // 
            this.textBox52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox52.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox52.Location = new System.Drawing.Point(355, 100);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(60, 20);
            this.textBox52.TabIndex = 54;
            // 
            // textBox53
            // 
            this.textBox53.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox53.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox53.Location = new System.Drawing.Point(355, 81);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(60, 20);
            this.textBox53.TabIndex = 53;
            // 
            // textBox54
            // 
            this.textBox54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox54.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox54.Location = new System.Drawing.Point(355, 62);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(60, 20);
            this.textBox54.TabIndex = 52;
            // 
            // textBox55
            // 
            this.textBox55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox55.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox55.Location = new System.Drawing.Point(355, 43);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(60, 20);
            this.textBox55.TabIndex = 51;
            // 
            // textBox56
            // 
            this.textBox56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox56.ForeColor = System.Drawing.Color.Goldenrod;
            this.textBox56.Location = new System.Drawing.Point(355, 24);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(60, 20);
            this.textBox56.TabIndex = 50;
            // 
            // textBox57
            // 
            this.textBox57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox57.ForeColor = System.Drawing.Color.Indigo;
            this.textBox57.Location = new System.Drawing.Point(414, 157);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(60, 20);
            this.textBox57.TabIndex = 65;
            // 
            // textBox58
            // 
            this.textBox58.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox58.ForeColor = System.Drawing.Color.Indigo;
            this.textBox58.Location = new System.Drawing.Point(414, 138);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(60, 20);
            this.textBox58.TabIndex = 64;
            // 
            // textBox59
            // 
            this.textBox59.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox59.ForeColor = System.Drawing.Color.Indigo;
            this.textBox59.Location = new System.Drawing.Point(414, 119);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(60, 20);
            this.textBox59.TabIndex = 63;
            // 
            // textBox60
            // 
            this.textBox60.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox60.ForeColor = System.Drawing.Color.Indigo;
            this.textBox60.Location = new System.Drawing.Point(414, 100);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(60, 20);
            this.textBox60.TabIndex = 62;
            // 
            // textBox61
            // 
            this.textBox61.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox61.ForeColor = System.Drawing.Color.Indigo;
            this.textBox61.Location = new System.Drawing.Point(414, 81);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(60, 20);
            this.textBox61.TabIndex = 61;
            // 
            // textBox62
            // 
            this.textBox62.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox62.ForeColor = System.Drawing.Color.Indigo;
            this.textBox62.Location = new System.Drawing.Point(414, 62);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(60, 20);
            this.textBox62.TabIndex = 60;
            // 
            // textBox63
            // 
            this.textBox63.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox63.ForeColor = System.Drawing.Color.Indigo;
            this.textBox63.Location = new System.Drawing.Point(414, 43);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(60, 20);
            this.textBox63.TabIndex = 59;
            // 
            // textBox64
            // 
            this.textBox64.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox64.ForeColor = System.Drawing.Color.Indigo;
            this.textBox64.Location = new System.Drawing.Point(414, 24);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(60, 20);
            this.textBox64.TabIndex = 58;
            // 
            // textBox65
            // 
            this.textBox65.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox65.ForeColor = System.Drawing.Color.Indigo;
            this.textBox65.Location = new System.Drawing.Point(473, 157);
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(60, 20);
            this.textBox65.TabIndex = 73;
            // 
            // textBox66
            // 
            this.textBox66.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox66.ForeColor = System.Drawing.Color.Indigo;
            this.textBox66.Location = new System.Drawing.Point(473, 138);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(60, 20);
            this.textBox66.TabIndex = 72;
            // 
            // textBox67
            // 
            this.textBox67.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox67.ForeColor = System.Drawing.Color.Indigo;
            this.textBox67.Location = new System.Drawing.Point(473, 119);
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(60, 20);
            this.textBox67.TabIndex = 71;
            // 
            // textBox68
            // 
            this.textBox68.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox68.ForeColor = System.Drawing.Color.Indigo;
            this.textBox68.Location = new System.Drawing.Point(473, 100);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(60, 20);
            this.textBox68.TabIndex = 70;
            // 
            // textBox69
            // 
            this.textBox69.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox69.ForeColor = System.Drawing.Color.Indigo;
            this.textBox69.Location = new System.Drawing.Point(473, 81);
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(60, 20);
            this.textBox69.TabIndex = 69;
            // 
            // textBox70
            // 
            this.textBox70.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox70.ForeColor = System.Drawing.Color.Indigo;
            this.textBox70.Location = new System.Drawing.Point(473, 62);
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(60, 20);
            this.textBox70.TabIndex = 68;
            // 
            // textBox71
            // 
            this.textBox71.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox71.ForeColor = System.Drawing.Color.Indigo;
            this.textBox71.Location = new System.Drawing.Point(473, 43);
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(60, 20);
            this.textBox71.TabIndex = 67;
            // 
            // textBox72
            // 
            this.textBox72.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox72.ForeColor = System.Drawing.Color.Indigo;
            this.textBox72.Location = new System.Drawing.Point(473, 24);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(60, 20);
            this.textBox72.TabIndex = 66;
            // 
            // textBox73
            // 
            this.textBox73.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox73.ForeColor = System.Drawing.Color.Indigo;
            this.textBox73.Location = new System.Drawing.Point(532, 157);
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(60, 20);
            this.textBox73.TabIndex = 81;
            // 
            // textBox74
            // 
            this.textBox74.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox74.ForeColor = System.Drawing.Color.Indigo;
            this.textBox74.Location = new System.Drawing.Point(532, 138);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(60, 20);
            this.textBox74.TabIndex = 80;
            // 
            // textBox75
            // 
            this.textBox75.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox75.ForeColor = System.Drawing.Color.Indigo;
            this.textBox75.Location = new System.Drawing.Point(532, 119);
            this.textBox75.Name = "textBox75";
            this.textBox75.Size = new System.Drawing.Size(60, 20);
            this.textBox75.TabIndex = 79;
            // 
            // textBox76
            // 
            this.textBox76.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox76.ForeColor = System.Drawing.Color.Indigo;
            this.textBox76.Location = new System.Drawing.Point(532, 100);
            this.textBox76.Name = "textBox76";
            this.textBox76.Size = new System.Drawing.Size(60, 20);
            this.textBox76.TabIndex = 78;
            // 
            // textBox77
            // 
            this.textBox77.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox77.ForeColor = System.Drawing.Color.Indigo;
            this.textBox77.Location = new System.Drawing.Point(532, 81);
            this.textBox77.Name = "textBox77";
            this.textBox77.Size = new System.Drawing.Size(60, 20);
            this.textBox77.TabIndex = 77;
            // 
            // textBox78
            // 
            this.textBox78.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox78.ForeColor = System.Drawing.Color.Indigo;
            this.textBox78.Location = new System.Drawing.Point(532, 62);
            this.textBox78.Name = "textBox78";
            this.textBox78.Size = new System.Drawing.Size(60, 20);
            this.textBox78.TabIndex = 76;
            // 
            // textBox79
            // 
            this.textBox79.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox79.ForeColor = System.Drawing.Color.Indigo;
            this.textBox79.Location = new System.Drawing.Point(532, 43);
            this.textBox79.Name = "textBox79";
            this.textBox79.Size = new System.Drawing.Size(60, 20);
            this.textBox79.TabIndex = 75;
            // 
            // textBox80
            // 
            this.textBox80.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox80.ForeColor = System.Drawing.Color.Indigo;
            this.textBox80.Location = new System.Drawing.Point(532, 24);
            this.textBox80.Name = "textBox80";
            this.textBox80.Size = new System.Drawing.Size(60, 20);
            this.textBox80.TabIndex = 74;
            // 
            // textBox81
            // 
            this.textBox81.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox81.ForeColor = System.Drawing.Color.Indigo;
            this.textBox81.Location = new System.Drawing.Point(591, 157);
            this.textBox81.Name = "textBox81";
            this.textBox81.Size = new System.Drawing.Size(60, 20);
            this.textBox81.TabIndex = 89;
            // 
            // textBox82
            // 
            this.textBox82.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox82.ForeColor = System.Drawing.Color.Indigo;
            this.textBox82.Location = new System.Drawing.Point(591, 138);
            this.textBox82.Name = "textBox82";
            this.textBox82.Size = new System.Drawing.Size(60, 20);
            this.textBox82.TabIndex = 88;
            // 
            // textBox83
            // 
            this.textBox83.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox83.ForeColor = System.Drawing.Color.Indigo;
            this.textBox83.Location = new System.Drawing.Point(591, 119);
            this.textBox83.Name = "textBox83";
            this.textBox83.Size = new System.Drawing.Size(60, 20);
            this.textBox83.TabIndex = 87;
            // 
            // textBox84
            // 
            this.textBox84.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox84.ForeColor = System.Drawing.Color.Indigo;
            this.textBox84.Location = new System.Drawing.Point(591, 100);
            this.textBox84.Name = "textBox84";
            this.textBox84.Size = new System.Drawing.Size(60, 20);
            this.textBox84.TabIndex = 86;
            // 
            // textBox85
            // 
            this.textBox85.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox85.ForeColor = System.Drawing.Color.Indigo;
            this.textBox85.Location = new System.Drawing.Point(591, 81);
            this.textBox85.Name = "textBox85";
            this.textBox85.Size = new System.Drawing.Size(60, 20);
            this.textBox85.TabIndex = 85;
            // 
            // textBox86
            // 
            this.textBox86.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox86.ForeColor = System.Drawing.Color.Indigo;
            this.textBox86.Location = new System.Drawing.Point(591, 62);
            this.textBox86.Name = "textBox86";
            this.textBox86.Size = new System.Drawing.Size(60, 20);
            this.textBox86.TabIndex = 84;
            // 
            // textBox87
            // 
            this.textBox87.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox87.ForeColor = System.Drawing.Color.Indigo;
            this.textBox87.Location = new System.Drawing.Point(591, 43);
            this.textBox87.Name = "textBox87";
            this.textBox87.Size = new System.Drawing.Size(60, 20);
            this.textBox87.TabIndex = 83;
            // 
            // textBox88
            // 
            this.textBox88.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox88.ForeColor = System.Drawing.Color.Indigo;
            this.textBox88.Location = new System.Drawing.Point(591, 24);
            this.textBox88.Name = "textBox88";
            this.textBox88.Size = new System.Drawing.Size(60, 20);
            this.textBox88.TabIndex = 82;
            // 
            // textBox89
            // 
            this.textBox89.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox89.ForeColor = System.Drawing.Color.Indigo;
            this.textBox89.Location = new System.Drawing.Point(650, 157);
            this.textBox89.Name = "textBox89";
            this.textBox89.Size = new System.Drawing.Size(60, 20);
            this.textBox89.TabIndex = 98;
            // 
            // textBox90
            // 
            this.textBox90.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox90.ForeColor = System.Drawing.Color.Indigo;
            this.textBox90.Location = new System.Drawing.Point(650, 138);
            this.textBox90.Name = "textBox90";
            this.textBox90.Size = new System.Drawing.Size(60, 20);
            this.textBox90.TabIndex = 97;
            // 
            // textBox91
            // 
            this.textBox91.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox91.ForeColor = System.Drawing.Color.Indigo;
            this.textBox91.Location = new System.Drawing.Point(650, 119);
            this.textBox91.Name = "textBox91";
            this.textBox91.Size = new System.Drawing.Size(60, 20);
            this.textBox91.TabIndex = 96;
            // 
            // textBox92
            // 
            this.textBox92.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox92.ForeColor = System.Drawing.Color.Indigo;
            this.textBox92.Location = new System.Drawing.Point(650, 100);
            this.textBox92.Name = "textBox92";
            this.textBox92.Size = new System.Drawing.Size(60, 20);
            this.textBox92.TabIndex = 95;
            // 
            // textBox93
            // 
            this.textBox93.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox93.ForeColor = System.Drawing.Color.Indigo;
            this.textBox93.Location = new System.Drawing.Point(650, 81);
            this.textBox93.Name = "textBox93";
            this.textBox93.Size = new System.Drawing.Size(60, 20);
            this.textBox93.TabIndex = 94;
            // 
            // textBox94
            // 
            this.textBox94.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox94.ForeColor = System.Drawing.Color.Indigo;
            this.textBox94.Location = new System.Drawing.Point(650, 62);
            this.textBox94.Name = "textBox94";
            this.textBox94.Size = new System.Drawing.Size(60, 20);
            this.textBox94.TabIndex = 93;
            // 
            // textBox95
            // 
            this.textBox95.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox95.ForeColor = System.Drawing.Color.Indigo;
            this.textBox95.Location = new System.Drawing.Point(650, 43);
            this.textBox95.Name = "textBox95";
            this.textBox95.Size = new System.Drawing.Size(60, 20);
            this.textBox95.TabIndex = 92;
            // 
            // textBox96
            // 
            this.textBox96.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox96.ForeColor = System.Drawing.Color.Indigo;
            this.textBox96.Location = new System.Drawing.Point(650, 24);
            this.textBox96.Name = "textBox96";
            this.textBox96.Size = new System.Drawing.Size(60, 20);
            this.textBox96.TabIndex = 91;
            // 
            // textBox97
            // 
            this.textBox97.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox97.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox97.Location = new System.Drawing.Point(650, 5);
            this.textBox97.Name = "textBox97";
            this.textBox97.Size = new System.Drawing.Size(60, 20);
            this.textBox97.TabIndex = 90;
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(378, 183);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 99;
            this.button3.Text = "fugacity";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(459, 183);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 100;
            this.button4.Text = "reaction";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox98
            // 
            this.textBox98.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox98.Location = new System.Drawing.Point(709, 157);
            this.textBox98.Name = "textBox98";
            this.textBox98.Size = new System.Drawing.Size(60, 20);
            this.textBox98.TabIndex = 109;
            // 
            // textBox99
            // 
            this.textBox99.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox99.Location = new System.Drawing.Point(709, 138);
            this.textBox99.Name = "textBox99";
            this.textBox99.Size = new System.Drawing.Size(60, 20);
            this.textBox99.TabIndex = 108;
            // 
            // textBox100
            // 
            this.textBox100.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox100.Location = new System.Drawing.Point(709, 119);
            this.textBox100.Name = "textBox100";
            this.textBox100.Size = new System.Drawing.Size(60, 20);
            this.textBox100.TabIndex = 107;
            // 
            // textBox101
            // 
            this.textBox101.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox101.Location = new System.Drawing.Point(709, 100);
            this.textBox101.Name = "textBox101";
            this.textBox101.Size = new System.Drawing.Size(60, 20);
            this.textBox101.TabIndex = 106;
            // 
            // textBox102
            // 
            this.textBox102.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox102.Location = new System.Drawing.Point(709, 81);
            this.textBox102.Name = "textBox102";
            this.textBox102.Size = new System.Drawing.Size(60, 20);
            this.textBox102.TabIndex = 105;
            // 
            // textBox103
            // 
            this.textBox103.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox103.Location = new System.Drawing.Point(709, 62);
            this.textBox103.Name = "textBox103";
            this.textBox103.Size = new System.Drawing.Size(60, 20);
            this.textBox103.TabIndex = 104;
            // 
            // textBox104
            // 
            this.textBox104.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox104.Location = new System.Drawing.Point(709, 43);
            this.textBox104.Name = "textBox104";
            this.textBox104.Size = new System.Drawing.Size(60, 20);
            this.textBox104.TabIndex = 103;
            // 
            // textBox105
            // 
            this.textBox105.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox105.Location = new System.Drawing.Point(709, 24);
            this.textBox105.Name = "textBox105";
            this.textBox105.Size = new System.Drawing.Size(60, 20);
            this.textBox105.TabIndex = 102;
            // 
            // textBox106
            // 
            this.textBox106.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox106.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox106.Location = new System.Drawing.Point(709, 5);
            this.textBox106.Name = "textBox106";
            this.textBox106.Size = new System.Drawing.Size(60, 20);
            this.textBox106.TabIndex = 101;
            // 
            // textBox107
            // 
            this.textBox107.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox107.Location = new System.Drawing.Point(768, 157);
            this.textBox107.Name = "textBox107";
            this.textBox107.Size = new System.Drawing.Size(60, 20);
            this.textBox107.TabIndex = 118;
            // 
            // textBox108
            // 
            this.textBox108.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox108.Location = new System.Drawing.Point(768, 138);
            this.textBox108.Name = "textBox108";
            this.textBox108.Size = new System.Drawing.Size(60, 20);
            this.textBox108.TabIndex = 117;
            // 
            // textBox109
            // 
            this.textBox109.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox109.Location = new System.Drawing.Point(768, 119);
            this.textBox109.Name = "textBox109";
            this.textBox109.Size = new System.Drawing.Size(60, 20);
            this.textBox109.TabIndex = 116;
            // 
            // textBox110
            // 
            this.textBox110.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox110.Location = new System.Drawing.Point(768, 100);
            this.textBox110.Name = "textBox110";
            this.textBox110.Size = new System.Drawing.Size(60, 20);
            this.textBox110.TabIndex = 115;
            // 
            // textBox111
            // 
            this.textBox111.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox111.Location = new System.Drawing.Point(768, 81);
            this.textBox111.Name = "textBox111";
            this.textBox111.Size = new System.Drawing.Size(60, 20);
            this.textBox111.TabIndex = 114;
            // 
            // textBox112
            // 
            this.textBox112.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox112.Location = new System.Drawing.Point(768, 62);
            this.textBox112.Name = "textBox112";
            this.textBox112.Size = new System.Drawing.Size(60, 20);
            this.textBox112.TabIndex = 113;
            // 
            // textBox113
            // 
            this.textBox113.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox113.Location = new System.Drawing.Point(768, 43);
            this.textBox113.Name = "textBox113";
            this.textBox113.Size = new System.Drawing.Size(60, 20);
            this.textBox113.TabIndex = 112;
            // 
            // textBox114
            // 
            this.textBox114.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox114.Location = new System.Drawing.Point(768, 24);
            this.textBox114.Name = "textBox114";
            this.textBox114.Size = new System.Drawing.Size(60, 20);
            this.textBox114.TabIndex = 111;
            // 
            // textBox115
            // 
            this.textBox115.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox115.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox115.Location = new System.Drawing.Point(768, 5);
            this.textBox115.Name = "textBox115";
            this.textBox115.Size = new System.Drawing.Size(60, 20);
            this.textBox115.TabIndex = 110;
            // 
            // textBox116
            // 
            this.textBox116.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox116.ForeColor = System.Drawing.Color.Maroon;
            this.textBox116.Location = new System.Drawing.Point(64, 157);
            this.textBox116.Name = "textBox116";
            this.textBox116.Size = new System.Drawing.Size(61, 20);
            this.textBox116.TabIndex = 119;
            // 
            // button5
            // 
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(672, 183);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 120;
            this.button5.Text = "save";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(753, 183);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 121;
            this.button6.Text = "open";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // textBox117
            // 
            this.textBox117.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox117.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox117.Location = new System.Drawing.Point(4, 5);
            this.textBox117.Name = "textBox117";
            this.textBox117.Size = new System.Drawing.Size(61, 20);
            this.textBox117.TabIndex = 129;
            // 
            // textBox118
            // 
            this.textBox118.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox118.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox118.Location = new System.Drawing.Point(4, 24);
            this.textBox118.Name = "textBox118";
            this.textBox118.Size = new System.Drawing.Size(61, 20);
            this.textBox118.TabIndex = 128;
            // 
            // textBox119
            // 
            this.textBox119.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox119.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox119.Location = new System.Drawing.Point(4, 43);
            this.textBox119.Name = "textBox119";
            this.textBox119.Size = new System.Drawing.Size(61, 20);
            this.textBox119.TabIndex = 127;
            // 
            // textBox120
            // 
            this.textBox120.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox120.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox120.Location = new System.Drawing.Point(4, 62);
            this.textBox120.Name = "textBox120";
            this.textBox120.Size = new System.Drawing.Size(61, 20);
            this.textBox120.TabIndex = 126;
            // 
            // textBox121
            // 
            this.textBox121.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox121.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox121.Location = new System.Drawing.Point(4, 81);
            this.textBox121.Name = "textBox121";
            this.textBox121.Size = new System.Drawing.Size(61, 20);
            this.textBox121.TabIndex = 125;
            // 
            // textBox122
            // 
            this.textBox122.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox122.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox122.Location = new System.Drawing.Point(4, 100);
            this.textBox122.Name = "textBox122";
            this.textBox122.Size = new System.Drawing.Size(61, 20);
            this.textBox122.TabIndex = 124;
            // 
            // textBox123
            // 
            this.textBox123.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox123.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox123.Location = new System.Drawing.Point(4, 119);
            this.textBox123.Name = "textBox123";
            this.textBox123.Size = new System.Drawing.Size(61, 20);
            this.textBox123.TabIndex = 123;
            // 
            // textBox124
            // 
            this.textBox124.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox124.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox124.Location = new System.Drawing.Point(4, 157);
            this.textBox124.Name = "textBox124";
            this.textBox124.Size = new System.Drawing.Size(61, 20);
            this.textBox124.TabIndex = 122;
            // 
            // textBox125
            // 
            this.textBox125.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox125.ForeColor = System.Drawing.Color.Maroon;
            this.textBox125.Location = new System.Drawing.Point(64, 138);
            this.textBox125.Name = "textBox125";
            this.textBox125.Size = new System.Drawing.Size(61, 20);
            this.textBox125.TabIndex = 130;
            // 
            // textBox126
            // 
            this.textBox126.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox126.ForeColor = System.Drawing.Color.SaddleBrown;
            this.textBox126.Location = new System.Drawing.Point(4, 138);
            this.textBox126.Name = "textBox126";
            this.textBox126.Size = new System.Drawing.Size(61, 20);
            this.textBox126.TabIndex = 131;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(832, 210);
            this.Controls.Add(this.textBox126);
            this.Controls.Add(this.textBox125);
            this.Controls.Add(this.textBox117);
            this.Controls.Add(this.textBox118);
            this.Controls.Add(this.textBox119);
            this.Controls.Add(this.textBox120);
            this.Controls.Add(this.textBox121);
            this.Controls.Add(this.textBox122);
            this.Controls.Add(this.textBox123);
            this.Controls.Add(this.textBox124);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.textBox116);
            this.Controls.Add(this.textBox107);
            this.Controls.Add(this.textBox108);
            this.Controls.Add(this.textBox109);
            this.Controls.Add(this.textBox110);
            this.Controls.Add(this.textBox111);
            this.Controls.Add(this.textBox112);
            this.Controls.Add(this.textBox113);
            this.Controls.Add(this.textBox114);
            this.Controls.Add(this.textBox115);
            this.Controls.Add(this.textBox98);
            this.Controls.Add(this.textBox99);
            this.Controls.Add(this.textBox100);
            this.Controls.Add(this.textBox101);
            this.Controls.Add(this.textBox102);
            this.Controls.Add(this.textBox103);
            this.Controls.Add(this.textBox104);
            this.Controls.Add(this.textBox105);
            this.Controls.Add(this.textBox106);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.textBox89);
            this.Controls.Add(this.textBox90);
            this.Controls.Add(this.textBox91);
            this.Controls.Add(this.textBox92);
            this.Controls.Add(this.textBox93);
            this.Controls.Add(this.textBox94);
            this.Controls.Add(this.textBox95);
            this.Controls.Add(this.textBox96);
            this.Controls.Add(this.textBox97);
            this.Controls.Add(this.textBox81);
            this.Controls.Add(this.textBox82);
            this.Controls.Add(this.textBox83);
            this.Controls.Add(this.textBox84);
            this.Controls.Add(this.textBox85);
            this.Controls.Add(this.textBox86);
            this.Controls.Add(this.textBox87);
            this.Controls.Add(this.textBox88);
            this.Controls.Add(this.textBox73);
            this.Controls.Add(this.textBox74);
            this.Controls.Add(this.textBox75);
            this.Controls.Add(this.textBox76);
            this.Controls.Add(this.textBox77);
            this.Controls.Add(this.textBox78);
            this.Controls.Add(this.textBox79);
            this.Controls.Add(this.textBox80);
            this.Controls.Add(this.textBox65);
            this.Controls.Add(this.textBox66);
            this.Controls.Add(this.textBox67);
            this.Controls.Add(this.textBox68);
            this.Controls.Add(this.textBox69);
            this.Controls.Add(this.textBox70);
            this.Controls.Add(this.textBox71);
            this.Controls.Add(this.textBox72);
            this.Controls.Add(this.textBox57);
            this.Controls.Add(this.textBox58);
            this.Controls.Add(this.textBox59);
            this.Controls.Add(this.textBox60);
            this.Controls.Add(this.textBox61);
            this.Controls.Add(this.textBox62);
            this.Controls.Add(this.textBox63);
            this.Controls.Add(this.textBox64);
            this.Controls.Add(this.textBox49);
            this.Controls.Add(this.textBox50);
            this.Controls.Add(this.textBox51);
            this.Controls.Add(this.textBox52);
            this.Controls.Add(this.textBox53);
            this.Controls.Add(this.textBox54);
            this.Controls.Add(this.textBox55);
            this.Controls.Add(this.textBox56);
            this.Controls.Add(this.textBox41);
            this.Controls.Add(this.textBox42);
            this.Controls.Add(this.textBox43);
            this.Controls.Add(this.textBox44);
            this.Controls.Add(this.textBox45);
            this.Controls.Add(this.textBox46);
            this.Controls.Add(this.textBox47);
            this.Controls.Add(this.textBox48);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox34);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.textBox38);
            this.Controls.Add(this.textBox39);
            this.Controls.Add(this.textBox40);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "EoSResol By Michael Franiatte";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.TextBox textBox75;
        private System.Windows.Forms.TextBox textBox76;
        private System.Windows.Forms.TextBox textBox77;
        private System.Windows.Forms.TextBox textBox78;
        private System.Windows.Forms.TextBox textBox79;
        private System.Windows.Forms.TextBox textBox80;
        private System.Windows.Forms.TextBox textBox81;
        private System.Windows.Forms.TextBox textBox82;
        private System.Windows.Forms.TextBox textBox83;
        private System.Windows.Forms.TextBox textBox84;
        private System.Windows.Forms.TextBox textBox85;
        private System.Windows.Forms.TextBox textBox86;
        private System.Windows.Forms.TextBox textBox87;
        private System.Windows.Forms.TextBox textBox88;
        private System.Windows.Forms.TextBox textBox89;
        private System.Windows.Forms.TextBox textBox90;
        private System.Windows.Forms.TextBox textBox91;
        private System.Windows.Forms.TextBox textBox92;
        private System.Windows.Forms.TextBox textBox93;
        private System.Windows.Forms.TextBox textBox94;
        private System.Windows.Forms.TextBox textBox95;
        private System.Windows.Forms.TextBox textBox96;
        private System.Windows.Forms.TextBox textBox97;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox98;
        private System.Windows.Forms.TextBox textBox99;
        private System.Windows.Forms.TextBox textBox100;
        private System.Windows.Forms.TextBox textBox101;
        private System.Windows.Forms.TextBox textBox102;
        private System.Windows.Forms.TextBox textBox103;
        private System.Windows.Forms.TextBox textBox104;
        private System.Windows.Forms.TextBox textBox105;
        private System.Windows.Forms.TextBox textBox106;
        private System.Windows.Forms.TextBox textBox107;
        private System.Windows.Forms.TextBox textBox108;
        private System.Windows.Forms.TextBox textBox109;
        private System.Windows.Forms.TextBox textBox110;
        private System.Windows.Forms.TextBox textBox111;
        private System.Windows.Forms.TextBox textBox112;
        private System.Windows.Forms.TextBox textBox113;
        private System.Windows.Forms.TextBox textBox114;
        private System.Windows.Forms.TextBox textBox115;
        private System.Windows.Forms.TextBox textBox116;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox117;
        private System.Windows.Forms.TextBox textBox118;
        private System.Windows.Forms.TextBox textBox119;
        private System.Windows.Forms.TextBox textBox120;
        private System.Windows.Forms.TextBox textBox121;
        private System.Windows.Forms.TextBox textBox122;
        private System.Windows.Forms.TextBox textBox123;
        private System.Windows.Forms.TextBox textBox124;
        private System.Windows.Forms.TextBox textBox125;
        private System.Windows.Forms.TextBox textBox126;
    }
}

