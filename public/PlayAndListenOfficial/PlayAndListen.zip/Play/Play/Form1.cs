﻿using System;
using System.Windows.Forms;
using System.Net;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using CSCore.SoundIn;
using WebSocketSharp;
using WebSocketSharp.Server;
using System.Net.NetworkInformation;
using System.Linq;
using System.Diagnostics;
using System.Data;
using CSCore.Streams;
namespace Play
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        [DllImport("winmm.dll", EntryPoint = "timeBeginPeriod")]
        public static extern uint TimeBeginPeriod(uint ms);
        [DllImport("winmm.dll", EntryPoint = "timeEndPeriod")]
        public static extern uint TimeEndPeriod(uint ms);
        [DllImport("ntdll.dll", EntryPoint = "NtSetTimerResolution")]
        public static extern void NtSetTimerResolution(uint DesiredResolution, bool SetResolution, ref uint CurrentResolution);
        public static uint CurrentResolution = 0;
        public static bool running;
        public static WebSocketServer wsaudio;
        public static byte[] audiorawdataavailable;
        public static WasapiCapture soundIn = new CSCore.SoundIn.WasapiLoopbackCapture();
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            running = false;
            System.Threading.Thread.Sleep(100);
            try
            {
                using (Process p = Process.GetCurrentProcess())
                {
                    p.Kill();
                }
            }
            catch { }
        }
        private void Form1_Shown(object sender, EventArgs e)
        {
            TimeBeginPeriod(1);
            NtSetTimerResolution(1, true, ref CurrentResolution);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (!running)
            {
                running = true;
                button1.Text = "Playing";
                Task.Run(() => LocalServerAudio());
            }
            else if (running)
            {
                running = false;
                button1.Text = "Play";
                wsaudio.Stop();
                soundIn.Stop();
            }
        }
        private void LocalServerAudio()
        {
            string localip = GetLocalIP();
            int result = Convert.ToInt32(localip.Substring(localip.LastIndexOf('.') + 1)) + 62000;
            string port = result.ToString();
            wsaudio = new WebSocketServer("ws://" + localip + ":" + port);
            wsaudio.AddWebSocketService<Audio>("/Audio");
            wsaudio.Start();
            GetAudioByteArray();
        }
        public static void GetAudioByteArray()
        {
            soundIn.Initialize();
            SoundInSource soundInSource = new SoundInSource(soundIn) { FillWithZeros = false };
            soundInSource.DataAvailable += (sound, card) =>
            {
                byte[] rawdata = new byte[card.ByteCount];
                Array.Copy(card.Data, card.Offset, rawdata, 0, card.ByteCount);
                audiorawdataavailable = rawdata;
            };
            soundIn.Start();
        }
        public static string GetLocalIP()
        {
            string firstAddress = (from address in NetworkInterface.GetAllNetworkInterfaces().Select(x => x.GetIPProperties()).SelectMany(x => x.UnicastAddresses).Select(x => x.Address)
                                   where !IPAddress.IsLoopback(address) && address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork
                                   select address).FirstOrDefault().ToString();
            return firstAddress;
        }
    }
    public class Audio : WebSocketBehavior
    {
        protected override void OnMessage(MessageEventArgs e)
        {
            base.OnMessage(e);
            while (Form1.running)
            {
                if (Form1.audiorawdataavailable != null)
                {
                    try
                    {
                        Send(Form1.audiorawdataavailable);
                        Form1.audiorawdataavailable = null;
                    }
                    catch { }
                }
                System.Threading.Thread.Sleep(1);
            }
        }
    }
}