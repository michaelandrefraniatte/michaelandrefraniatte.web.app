﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using NAudio.Wave;
using NAudio.Extras;
using WebSocketSharp;
namespace Listen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        [DllImport("winmm.dll", EntryPoint = "timeBeginPeriod")]
        public static extern uint TimeBeginPeriod(uint ms);
        [DllImport("winmm.dll", EntryPoint = "timeEndPeriod")]
        public static extern uint TimeEndPeriod(uint ms);
        [DllImport("ntdll.dll", EntryPoint = "NtSetTimerResolution")]
        public static extern void NtSetTimerResolution(uint DesiredResolution, bool SetResolution, ref uint CurrentResolution);
        public static uint CurrentResolution = 0;
        public static bool listening = false;
        public static WebSocket wslisten1;
        public static string currentAudioBytes = null;
        public static BufferedWaveProvider src;
        public static WaveOut soundOut;
        public static EqualizerBand[] bands;
        public static float volumeleft, volumeright;
        private static NAudio.Extras.Equalizer equalizer;
        private static MediaFoundationReader audioFileReader;
        private static VolumeStereoSampleProvider stereo;
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            listening = false;
            System.Threading.Thread.Sleep(100);
            if (TextBoxServerIP.Text != "")
            {
                using (StreamWriter createdfile = new StreamWriter("tempsave"))
                {
                    createdfile.WriteLine(TextBoxServerIP.Text);
                    createdfile.WriteLine(trackBar1.Value);
                    createdfile.WriteLine(trackBar2.Value);
                    createdfile.WriteLine(trackBar3.Value);
                    createdfile.WriteLine(trackBar4.Value);
                    createdfile.WriteLine(trackBar5.Value);
                    createdfile.WriteLine(trackBar6.Value);
                    createdfile.WriteLine(trackBar7.Value);
                    createdfile.WriteLine(trackBar8.Value);
                    createdfile.WriteLine(trackBar9.Value);
                    createdfile.WriteLine(trackBar10.Value);
                }
            }
            try
            {
                using (Process p = Process.GetCurrentProcess())
                {
                    p.Kill();
                }
            }
            catch { }
        }
        private void Form1_Shown(object sender, EventArgs e)
        {
            TimeBeginPeriod(1);
            NtSetTimerResolution(1, true, ref CurrentResolution);
            InitSoundPlay();
            if (File.Exists("tempsave"))
            {
                using (StreamReader file = new StreamReader("tempsave"))
                {
                    TextBoxServerIP.Text = file.ReadLine();
                    trackBar1.Value = Convert.ToInt32(file.ReadLine());
                    trackBar2.Value = Convert.ToInt32(file.ReadLine());
                    trackBar3.Value = Convert.ToInt32(file.ReadLine());
                    trackBar4.Value = Convert.ToInt32(file.ReadLine());
                    trackBar5.Value = Convert.ToInt32(file.ReadLine());
                    trackBar6.Value = Convert.ToInt32(file.ReadLine());
                    trackBar7.Value = Convert.ToInt32(file.ReadLine());
                    trackBar8.Value = Convert.ToInt32(file.ReadLine());
                    trackBar9.Value = Convert.ToInt32(file.ReadLine());
                    trackBar10.Value = Convert.ToInt32(file.ReadLine());
                }
            }
        }
        private void InitSoundPlay()
        {
            SetEqualizer();
            audioFileReader = new MediaFoundationReader("silence.mp3");
            stereo = new VolumeStereoSampleProvider(audioFileReader.ToSampleProvider());
            equalizer = new NAudio.Extras.Equalizer(stereo, Form1.bands);
            soundOut = new WaveOut();
            soundOut.Init(equalizer);
            soundOut.Play();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (!listening)
            {
                listening = true;
                button1.Text = "Listening";
                string ip = TextBoxServerIP.Text;
                int result = Convert.ToInt32(ip.Substring(ip.LastIndexOf('.') + 1)) + 62000;
                string port = result.ToString();
                wslisten1 = new WebSocket("ws://" + ip + ":" + port + "/Audio");
                wslisten1.OnMessage += Ws_OnMessage;
                wslisten1.Connect();
                wslisten1.Send("Hello from client");
                SetEqualizer();
                src = new BufferedWaveProvider(WaveFormat.CreateIeeeFloatWaveFormat(48000, 2));
                stereo = new VolumeStereoSampleProvider(src.ToSampleProvider());
                equalizer = new NAudio.Extras.Equalizer(stereo, Form1.bands);
                soundOut = new WaveOut();
                soundOut.Init(equalizer);
                soundOut.Play();
            }
            else if (listening)
            {
                listening = false;
                button1.Text = "Listen";
                wslisten1.Close();
                soundOut.Stop();
            }
        }
        private static void Ws_OnMessage(object sender, MessageEventArgs e)
        {
            byte[] rawdata = e.RawData;
            src.AddSamples(rawdata, 0, rawdata.Length);
        }
        private void SetEqualizer()
        {
            bands = new EqualizerBand[]
                    {
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 100, Gain = trackBar1.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 200, Gain = trackBar2.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 400, Gain = trackBar3.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 800, Gain = trackBar4.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 1200, Gain = trackBar5.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 2400, Gain = trackBar6.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 4800, Gain = trackBar7.Value},
                        new EqualizerBand {Bandwidth = 0.8f, Frequency = 9600, Gain = trackBar8.Value},
                    };
            volumeleft = trackBar9.Value / 100f;
            volumeright = trackBar10.Value / 100f;
        }
    }
    /// <summary>
    /// Very simple sample provider supporting adjustable gain
    /// </summary>
    public class VolumeStereoSampleProvider : ISampleProvider
    {
        private readonly ISampleProvider source;

        /// <summary>
        /// Allows adjusting the volume left channel, 1.0f = full volume
        /// </summary>
        public float VolumeLeft { get; set; }

        /// <summary>
        /// Allows adjusting the volume right channel, 1.0f = full volume
        /// </summary>
        public float VolumeRight { get; set; }

        /// <summary>
        /// Initializes a new instance of VolumeStereoSampleProvider
        /// </summary>
        /// <param name="source">Source sample provider, must be stereo</param>
        public VolumeStereoSampleProvider(ISampleProvider source)
        {
            this.source = source;
            VolumeLeft = Form1.volumeleft;
            VolumeRight = Form1.volumeright;
        }

        /// <summary>
        /// WaveFormat
        /// </summary>
        public NAudio.Wave.WaveFormat WaveFormat => source.WaveFormat;

        /// <summary>
        /// Reads samples from this sample provider
        /// </summary>
        /// <param name="buffer">Sample buffer</param>
        /// <param name="offset">Offset into sample buffer</param>
        /// <param name="sampleCount">Number of samples desired</param>
        /// <returns>Number of samples read</returns>
        public int Read(float[] buffer, int offset, int sampleCount)
        {
            int samplesRead = source.Read(buffer, offset, sampleCount);

            for (int n = 0; n < sampleCount; n += 2)
            {
                buffer[offset + n] *= VolumeLeft;
                buffer[offset + n + 1] *= VolumeRight;
            }

            return samplesRead;
        }
    }
}