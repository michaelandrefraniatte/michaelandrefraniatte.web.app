﻿namespace Listen
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.LabelServerIP = new System.Windows.Forms.Label();
            this.TextBoxServerIP = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.trackBar10 = new System.Windows.Forms.TrackBar();
            this.trackBar9 = new System.Windows.Forms.TrackBar();
            this.trackBar8 = new System.Windows.Forms.TrackBar();
            this.trackBar7 = new System.Windows.Forms.TrackBar();
            this.trackBar6 = new System.Windows.Forms.TrackBar();
            this.trackBar5 = new System.Windows.Forms.TrackBar();
            this.trackBar4 = new System.Windows.Forms.TrackBar();
            this.trackBar3 = new System.Windows.Forms.TrackBar();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.SuspendLayout();
            // 
            // LabelServerIP
            // 
            this.LabelServerIP.AutoSize = true;
            this.LabelServerIP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelServerIP.Location = new System.Drawing.Point(9, 20);
            this.LabelServerIP.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LabelServerIP.Name = "LabelServerIP";
            this.LabelServerIP.Size = new System.Drawing.Size(58, 13);
            this.LabelServerIP.TabIndex = 78;
            this.LabelServerIP.Text = "IP Address";
            // 
            // TextBoxServerIP
            // 
            this.TextBoxServerIP.BackColor = System.Drawing.Color.White;
            this.TextBoxServerIP.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextBoxServerIP.ForeColor = System.Drawing.Color.DimGray;
            this.TextBoxServerIP.Location = new System.Drawing.Point(86, 17);
            this.TextBoxServerIP.Margin = new System.Windows.Forms.Padding(2);
            this.TextBoxServerIP.Name = "TextBoxServerIP";
            this.TextBoxServerIP.Size = new System.Drawing.Size(417, 20);
            this.TextBoxServerIP.TabIndex = 77;
            this.TextBoxServerIP.Text = "192.168.1.10";
            this.TextBoxServerIP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 55);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(491, 39);
            this.button1.TabIndex = 79;
            this.button1.Text = "Listen";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // trackBar10
            // 
            this.trackBar10.LargeChange = 10;
            this.trackBar10.Location = new System.Drawing.Point(458, 100);
            this.trackBar10.Maximum = 100;
            this.trackBar10.Name = "trackBar10";
            this.trackBar10.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar10.Size = new System.Drawing.Size(45, 180);
            this.trackBar10.TabIndex = 89;
            this.trackBar10.TickFrequency = 100;
            this.trackBar10.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.trackBar10.Value = 100;
            // 
            // trackBar9
            // 
            this.trackBar9.LargeChange = 10;
            this.trackBar9.Location = new System.Drawing.Point(12, 100);
            this.trackBar9.Maximum = 100;
            this.trackBar9.Name = "trackBar9";
            this.trackBar9.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar9.Size = new System.Drawing.Size(45, 180);
            this.trackBar9.TabIndex = 88;
            this.trackBar9.TickFrequency = 100;
            this.trackBar9.TickStyle = System.Windows.Forms.TickStyle.Both;
            this.trackBar9.Value = 100;
            // 
            // trackBar8
            // 
            this.trackBar8.Location = new System.Drawing.Point(419, 114);
            this.trackBar8.Maximum = 15;
            this.trackBar8.Minimum = -15;
            this.trackBar8.Name = "trackBar8";
            this.trackBar8.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar8.Size = new System.Drawing.Size(45, 166);
            this.trackBar8.TabIndex = 87;
            this.trackBar8.TickFrequency = 3;
            // 
            // trackBar7
            // 
            this.trackBar7.Location = new System.Drawing.Point(368, 114);
            this.trackBar7.Maximum = 15;
            this.trackBar7.Minimum = -15;
            this.trackBar7.Name = "trackBar7";
            this.trackBar7.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar7.Size = new System.Drawing.Size(45, 166);
            this.trackBar7.TabIndex = 86;
            this.trackBar7.TickFrequency = 3;
            // 
            // trackBar6
            // 
            this.trackBar6.Location = new System.Drawing.Point(317, 114);
            this.trackBar6.Maximum = 15;
            this.trackBar6.Minimum = -15;
            this.trackBar6.Name = "trackBar6";
            this.trackBar6.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar6.Size = new System.Drawing.Size(45, 166);
            this.trackBar6.TabIndex = 85;
            this.trackBar6.TickFrequency = 3;
            // 
            // trackBar5
            // 
            this.trackBar5.Location = new System.Drawing.Point(266, 114);
            this.trackBar5.Maximum = 15;
            this.trackBar5.Minimum = -15;
            this.trackBar5.Name = "trackBar5";
            this.trackBar5.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar5.Size = new System.Drawing.Size(45, 166);
            this.trackBar5.TabIndex = 84;
            this.trackBar5.TickFrequency = 3;
            // 
            // trackBar4
            // 
            this.trackBar4.Location = new System.Drawing.Point(215, 114);
            this.trackBar4.Maximum = 15;
            this.trackBar4.Minimum = -15;
            this.trackBar4.Name = "trackBar4";
            this.trackBar4.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar4.Size = new System.Drawing.Size(45, 166);
            this.trackBar4.TabIndex = 83;
            this.trackBar4.TickFrequency = 3;
            // 
            // trackBar3
            // 
            this.trackBar3.Location = new System.Drawing.Point(164, 114);
            this.trackBar3.Maximum = 15;
            this.trackBar3.Minimum = -15;
            this.trackBar3.Name = "trackBar3";
            this.trackBar3.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar3.Size = new System.Drawing.Size(45, 166);
            this.trackBar3.TabIndex = 82;
            this.trackBar3.TickFrequency = 3;
            // 
            // trackBar2
            // 
            this.trackBar2.Location = new System.Drawing.Point(113, 114);
            this.trackBar2.Maximum = 15;
            this.trackBar2.Minimum = -15;
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar2.Size = new System.Drawing.Size(45, 166);
            this.trackBar2.TabIndex = 81;
            this.trackBar2.TickFrequency = 3;
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(63, 114);
            this.trackBar1.Maximum = 15;
            this.trackBar1.Minimum = -15;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar1.Size = new System.Drawing.Size(45, 166);
            this.trackBar1.TabIndex = 80;
            this.trackBar1.TickFrequency = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(516, 289);
            this.Controls.Add(this.trackBar10);
            this.Controls.Add(this.trackBar9);
            this.Controls.Add(this.trackBar8);
            this.Controls.Add(this.trackBar7);
            this.Controls.Add(this.trackBar6);
            this.Controls.Add(this.trackBar5);
            this.Controls.Add(this.trackBar4);
            this.Controls.Add(this.trackBar3);
            this.Controls.Add(this.trackBar2);
            this.Controls.Add(this.trackBar1);
            this.Controls.Add(this.LabelServerIP);
            this.Controls.Add(this.TextBoxServerIP);
            this.Controls.Add(this.button1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Listen";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.trackBar10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LabelServerIP;
        private System.Windows.Forms.TextBox TextBoxServerIP;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TrackBar trackBar10;
        private System.Windows.Forms.TrackBar trackBar9;
        private System.Windows.Forms.TrackBar trackBar8;
        private System.Windows.Forms.TrackBar trackBar7;
        private System.Windows.Forms.TrackBar trackBar6;
        private System.Windows.Forms.TrackBar trackBar5;
        private System.Windows.Forms.TrackBar trackBar4;
        private System.Windows.Forms.TrackBar trackBar3;
        private System.Windows.Forms.TrackBar trackBar2;
        private System.Windows.Forms.TrackBar trackBar1;
    }
}

