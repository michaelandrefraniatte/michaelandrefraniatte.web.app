﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StopIt
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        [DllImport("winmm.dll", EntryPoint = "timeBeginPeriod")]
        public static extern uint TimeBeginPeriod(uint ms);
        [DllImport("winmm.dll", EntryPoint = "timeEndPeriod")]
        public static extern uint TimeEndPeriod(uint ms);
        [DllImport("ntdll.dll", EntryPoint = "NtSetTimerResolution")]
        public static extern void NtSetTimerResolution(uint DesiredResolution, bool SetResolution, ref uint CurrentResolution);
        private delegate bool ConsoleEventDelegate(int eventType);
        public static ThreadStart threadstart;
        public static Thread thread;
        public static uint CurrentResolution = 0;
        private static bool closed = false;
        private static List<string> procBLs = new List<string>();
        private void Form1_Load(object sender, EventArgs e)
        {
            TimeBeginPeriod(1);
            NtSetTimerResolution(1, true, ref CurrentResolution);
            using (System.IO.StreamReader file = new System.IO.StreamReader("siblacklist.txt"))
            {
                while (true)
                {
                    string procName = file.ReadLine();
                    if (procName == "")
                    {
                        file.Close();
                        break;
                    }
                    else
                        procBLs.Add(procName);
                }
            }
            Task.Run(() => StartStopIt());
        }
        public static void StartStopIt()
        {
            while (!closed)
            {
                try
                {
                    foreach (string procBL in procBLs)
                    {
                        Process[] ps = Process.GetProcessesByName(procBL);
                        foreach (Process p in ps)
                        {
                            p.Kill();
                            Thread.Sleep(1);
                        }
                        Thread.Sleep(1);
                    }
                }
                catch { }
                Thread.Sleep(1);
            }
        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            closed = true;
        }
    }
}
