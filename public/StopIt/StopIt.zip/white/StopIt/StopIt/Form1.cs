﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StopIt
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        [DllImport("winmm.dll", EntryPoint = "timeBeginPeriod")]
        public static extern uint TimeBeginPeriod(uint ms);
        [DllImport("winmm.dll", EntryPoint = "timeEndPeriod")]
        public static extern uint TimeEndPeriod(uint ms);
        [DllImport("ntdll.dll", EntryPoint = "NtSetTimerResolution")]
        public static extern void NtSetTimerResolution(uint DesiredResolution, bool SetResolution, ref uint CurrentResolution);
        private delegate bool ConsoleEventDelegate(int eventType);
        public static ThreadStart threadstart;
        public static Thread thread;
        public static uint CurrentResolution = 0;
        public static int processid = 0;
        private static bool closed = false;
        private static List<string> procWLs = new List<string>(), procFiles = new List<string>(), procSHA1s = new List<string>();
        private static bool checkingWL;
        private static string processfound;
        private void Form1_Load(object sender, EventArgs e)
        {
            TimeBeginPeriod(1);
            NtSetTimerResolution(1, true, ref CurrentResolution);
            using (System.IO.StreamReader file = new System.IO.StreamReader("siwhitelist.txt"))
            {
                while (true)
                {
                    string procName = file.ReadLine();
                    if (procName == "")
                    {
                        file.Close();
                        break;
                    }
                    else
                        procWLs.Add(procName);
                }
            }
            Task.Run(() => StartStopIt());
        }
        public static void StartStopIt()
        {
            while (!closed)
            {
                try
                {
                    foreach (Process p in Process.GetProcesses())
                    {
                        try
                        {
                            processfound = p.ProcessName;
                            checkingWL = false;
                            foreach (string procWL in procWLs)
                            {
                                if (processfound == procWL)
                                {
                                    checkingWL = true;
                                    break;
                                }
                            }
                            if (!checkingWL)
                            {
                                p.Kill();
                                procFiles.Add(processfound);
                            }
                            else
                            {
                                string exePath = p.MainModule.FileName;
                                SHA1 sha1 = SHA1.Create();
                                FileStream fs = new FileStream(exePath, FileMode.Open, FileAccess.Read);
                                string hash = BitConverter.ToString(sha1.ComputeHash(fs)).Replace("-", "");
                                fs.Close();
                                procSHA1s.Add(processfound + "-" + hash);
                                procSHA1s = procSHA1s.Distinct().ToList();
                                int count = procSHA1s.Where(stringToCheck => stringToCheck.StartsWith(processfound + "-")).Count();
                                if (count > 1)
                                {
                                    p.Kill();
                                    procFiles.Add(processfound + "-" + hash);
                                }
                            }
                        }
                        catch { }
                        Thread.Sleep(10);
                    }
                    if (procFiles.Count > 0)
                    {
                        using (StreamWriter createdfile = File.AppendText("sirecord.txt"))
                        {
                            foreach (string procFile in procFiles)
                            {
                                createdfile.WriteLine(procFile);
                            }
                            procFiles.Clear();
                            createdfile.Close();
                        }
                    }
                }
                catch { }
                Thread.Sleep(10);
            }
        }
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            closed = true;
        }
    }
}
