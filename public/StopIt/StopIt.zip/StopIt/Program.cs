﻿using System;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Security.Principal;
using System.IO;
using System.Security.Cryptography;
namespace StopIt
{
    class Program
    {
        [DllImport("winmm.dll", EntryPoint = "timeBeginPeriod")]
        public static extern uint TimeBeginPeriod(uint ms);
        [DllImport("winmm.dll", EntryPoint = "timeEndPeriod")]
        public static extern uint TimeEndPeriod(uint ms);
        [DllImport("ntdll.dll", EntryPoint = "NtSetTimerResolution")]
        public static extern void NtSetTimerResolution(uint DesiredResolution, bool SetResolution, ref uint CurrentResolution);
        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool SetConsoleCtrlHandler(ConsoleEventDelegate callback, bool add);
        [DllImport("Kernel32.dll", CallingConvention = CallingConvention.StdCall, SetLastError = true)]
        private static extern IntPtr GetConsoleWindow();
        [DllImport("User32.dll", CallingConvention = CallingConvention.StdCall, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool ShowWindow([In] IntPtr hWnd, [In] Int32 nCmdShow);
        const Int32 SW_MINIMIZE = 6;
        static ConsoleEventDelegate handler;
        private delegate bool ConsoleEventDelegate(int eventType);
        public static ThreadStart threadstart;
        public static Thread thread;
        public static uint CurrentResolution = 0;
        public static int processid = 0;
        private static bool closed = false;
        private static List<string> procWLs = new List<string>(),  procFiles = new List<string>(), procSHA1s = new List<string>();
        private static bool checkingWL;
        private static string processfound;
        static void Main(string[] args)
        {
            MinimizeConsoleWindow();
            handler = new ConsoleEventDelegate(ConsoleEventCallback);
            SetConsoleCtrlHandler(handler, true);
            bool runelevated = true;
            bool oneinstanceonly = true;
            try
            {
                TimeBeginPeriod(1);
                NtSetTimerResolution(1, true, ref CurrentResolution);
                if (oneinstanceonly)
                {
                    if (AlreadyRunning())
                    {
                        return;
                    }
                }
                if (runelevated)
                {
                    if (!hasAdminRights())
                    {
                        RunElevated();
                        return;
                    }
                }
            }
            catch
            {
                return;
            }
            using (System.IO.StreamReader file = new System.IO.StreamReader("siwhitelist.txt"))
            {
                while (true)
                {
                    string procName = file.ReadLine();
                    if (procName == "")
                    {
                        file.Close();
                        break;
                    }
                    else
                        procWLs.Add(procName);
                }
            }
            Task.Run(() => StartStopIt());
            Console.WriteLine("started");
            Console.ReadLine();
        }
        public static void StartStopIt()
        {
            while (!closed)
            {
                try
                {
                    foreach (Process p in Process.GetProcesses())
                    {
                        try
                        {
                            processfound = p.ProcessName;
                            checkingWL = false;
                            foreach (string procWL in procWLs)
                            {
                                if (processfound == procWL)
                                {
                                    checkingWL = true;
                                    break;
                                }
                            }
                            if (!checkingWL)
                            {
                                p.Kill();
                                procFiles.Add(processfound);
                            }
                            else
                            {
                                string exePath = p.MainModule.FileName;
                                SHA1 sha1 = SHA1.Create();
                                FileStream fs = new FileStream(exePath, FileMode.Open, FileAccess.Read);
                                string hash = BitConverter.ToString(sha1.ComputeHash(fs)).Replace("-", "");
                                fs.Close();
                                procSHA1s.Add(processfound + "-" + hash);
                                procSHA1s = procSHA1s.Distinct().ToList();
                                int count = procSHA1s.Where(stringToCheck => stringToCheck.StartsWith(processfound + "-")).Count();
                                if (count > 1)
                                {
                                    p.Kill();
                                    procFiles.Add(processfound + "-" + hash);
                                }
                            }
                        }
                        catch { }
                        Thread.Sleep(10);
                    }
                    if (procFiles.Count > 0)
                    {
                        using (StreamWriter createdfile = File.AppendText("sirecord.txt"))
                        {
                            foreach (string procFile in procFiles)
                            {
                                createdfile.WriteLine(procFile);
                            }
                            procFiles.Clear();
                            createdfile.Close();
                        }
                    }
                }
                catch { }
                Thread.Sleep(10);
            }
        }
        public static bool hasAdminRights()
        {
            WindowsPrincipal principal = new WindowsPrincipal(WindowsIdentity.GetCurrent());
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }
        public static void RunElevated()
        {
            try
            {
                ProcessStartInfo processInfo = new ProcessStartInfo();
                processInfo.Verb = "runas";
                processInfo.FileName = Application.ExecutablePath;
                Process.Start(processInfo);
            }
            catch { }
        }
        private static bool AlreadyRunning()
        {
            String thisprocessname = Process.GetCurrentProcess().ProcessName;
            Process[] processes = Process.GetProcessesByName(thisprocessname);
            if (processes.Length > 1)
                return true;
            else
                return false;
        }
        private static void MinimizeConsoleWindow()
        {
            IntPtr hWndConsole = GetConsoleWindow();
            ShowWindow(hWndConsole, SW_MINIMIZE);
        }
        static bool ConsoleEventCallback(int eventType)
        {
            if (eventType == 2)
            {
                threadstart = new ThreadStart(FormClose);
                thread = new Thread(threadstart);
                thread.Start();
            }
            return false;
        }
        private static void FormClose()
        {
            closed = true;
        }
    }
}